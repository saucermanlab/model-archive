% function doseResponse

%% Dose Response
load tempICs;
params = PKAparams;

params(4) = 0.02;       % VnucF - Bers Book
params(5) = 35.6-6;     % DPKIcn - Ubiquitin rate from Mohr D, EMBO J, 2009
params(6) = 0.22e-6/100;    % DPKACIIcn - MBP rate from Mohr D, EMBO J, 2009
params(7) = 3.415e-6;   % DPKACII_PKInc - CRM1-GFP rate from Daelemans D, Mol Cell Biol, 2005
% params(5:7) = params(5:7)*42; % 3.5087 um^2 nuclear SA Bers, 12 +/- 4 NPCs per um^2 - Bustamente JO, J Mem Biol 1995, Braz J Med Bio Res 1998
params(8) = 1000;       % PKIbias

% params([44])./params(42)
params(5:7) = params(5:7)/3; % 3.5087 um^2 nuclear SA Bers, 12 +/- 4 NPCs per um^2 - Bustamente JO, J Mem Biol 1995, Braz J Med Bio Res 1998

% params(9) = 0.015;      
% params(16) = 41.1311*params(9); % Gstot: 41.1311x GNAS over ADRB1 from Matkovich SJ, Circ Res 2010
% params(24) = 8.7715*params(9);  % ACtot: 8.7715x AC* over ADRB1 from Matkovich SJ, Circ Res 2010
% params(42) = 8.8586*params(9);  % PKAItot: 8.8586x PRKAC* over ADRB1 from Matkovich SJ, Circ Res 2010
% params(43) = 0.1581*params(42);   % PKAIItot: 0.1581x PKAII over PKAI from Matkovich SJ, Circ Res 2010

params(16) = 1.25*41.1311*params(9); % Gstot: 41.1311x GNAS over ADRB1 from Matkovich SJ, Circ Res 2010
params(24) = 1.25*8.7715*params(9);  % ACtot: 8.7715x AC* over ADRB1 from Matkovich SJ, Circ Res 2010
% params(42) = 20*params(9);  % PKAItot: 8.8586x PRKAC* over ADRB1 from Matkovich SJ, Circ Res 2010
% params(42) = params(43);  % PKAItot: 8.8586x PRKAC* over ADRB1 from Matkovich SJ, Circ Res 2010

% params(44)=params(42)*1.2;

% params(44) = 0.6732*params(42);   % PKItot: 0.1104x PKIA over PKA*; 0.6732 PKIG over over PKA* fom Matkovich SJ< Circ Res 2010
% params(44) = 0.1104*params(42);   % PKItot: 0.1104x PKIA over PKA*; 0.6732 PKIG over over PKA* fom Matkovich SJ< Circ Res 2010
params(44) = 1.25*(0.1104+0.6732)*params(42);   % PKItot: 0.1104x PKIA over PKA*; 0.6732 PKIG over over PKA* fom Matkovich SJ< Circ Res 2010

params(58) = 6e-3;      % Vmax_PP2A_I1 - Bhalla, Iyengar - DOCQS
params(59) = 7.82828;   % Km_PP2A_I1 - Bhalla, Iyengar - DOCQS

% params(52) = 0.4e-3;    % kr_PKA_PKI: PKIa - 0.2 nM, PKIb - 7.1 nM, PKIg - 0.4 nM - Dalton GD, Neuropeptides 2006
% params(63) = 0.4237*params(43); % PKACII_LCC: 0.4237x PKACII_LCC over PKACIItot in original model

params(92) = 6e-3;      % k_PP2A_CREB - Bhalla, Iyengar generic PP2A - DOCQS
params(93) = 7.82828;   % Km_PP2A_CREB - Bhalla, Iyengar generic PP2A - DOCQS

params(98) = 1e-3;      % k_PP2A_AKARnes - Ni Q, Nat Chem Biol 2011
% params(98) = 6e-3;       % k_PP2A_AKARnes - Bhalla, Iyengar generic PP2A - DOCQS
params(99) = 7.82828;       % Km_PP2A_AKARnes - Bhalla, Iyengar generic PP2A - DOCQS
params(104) = 1e-3;     % k_PP2A_AKARnls - Ni Q, Nat Chem Biol 2011
% params(104) = 6e-3;      % k_PP2A_AKARnls - Bhalla, Iyengar generic PP2A - DOCQS
params(105) = 7.82828;  % Km_PP2A_AKARnls - Bhalla, Iyengar generic PP2A - DOCQS

% Resting Initial Conditions
tspan = [0 1e10];
options = odeset('NonNegative',1:34,'RelTol',1e-3,'AbsTol',1e-4);
params(1) = 0;

[t,y] = ode15s(@PKAode,tspan,y0,options,params);
y0 = y(end,:)';
save tempICs y0;

% Start Simulation
tspan = [0 60*60e3];
options = odeset('NonNegative',1:34,'RelTol',1e-3,'AbsTol',1e-4);

% ISO = logspace(-6,2,50);
ISO = [1e-4 1e-3 1e-2 1e-1 1 10]
SS = zeros(length(ISO),6);

for i = 1:length(ISO);
  params(1) = ISO(i);
  [t,y] = ode15s(@PKAode,tspan,y0,options,params);

%   SS(i,1) = y(end,20);  % PKA CII
%   SS(i,2) = y(end,23);  % nPKA CII
%   SS(i,3) = y(end,29);  % PLBp
%   SS(i,4) = y(end,32);  % CREBp
%   SS(i,5) = y(end,33);  % AKAR-nes
%   SS(i,6) = y(end,34);  % AKAR-nls
%   ySS(i,:) = y(end,:);
  
  NES = y(:,33);
  NLS = y(:,34);
  
  NES = NES-NES(1); NES = NES./0.572954098420698;
  NLS = NLS-NLS(1); NLS = NLS./0.000610080873343;
  
  t = t./60e3;
  figure(1);
  subplot(2,2,1);hold on;plot(t,NES);
  subplot(2,2,2);hold on;plot(t,NLS);
end

% figure(2)
% subplot(2,4,5);semilogx(ISO,SS(:,1),'k.-');title('PKA CII');axis([1e-6 1e2 0.9*min(SS(:,1)) 1.1*max(SS(:,1))]);
% subplot(2,4,6);semilogx(ISO,SS(:,2),'r.-');title('nPKA CII');axis([1e-6 1e2 0.9*min(SS(:,2)) 1.1*max(SS(:,2))]);
% subplot(2,4,7);semilogx(ISO,SS(:,5),'k.-');title('AKAR nes');axis([1e-6 1e2 0.9*min(SS(:,5)) 1.1*max(SS(:,5))]);
% subplot(2,4,8);semilogx(ISO,SS(:,6),'r.-');title('AKAR nls');axis([1e-6 1e2 0.9*min(SS(:,6)) 1.1*max(SS(:,6))]);
% 
% for i = 1:6;
%   SS(:,i) = SS(:,i)-SS(1,i);
%   SS(:,i) = SS(:,i)./SS(end,i);
% end
% 
% figure(2)
% subplot(2,3,1);semilogx(ISO,SS(:,1),'k.-',ISO,SS(:,2),'r.-');axis([1e-6 1e2 -0.1 1.1]);title('PKA');
% subplot(2,3,2);semilogx(ISO,SS(:,3),'k.-',ISO,SS(:,4),'r.-');axis([1e-6 1e2 -0.1 1.1]);title('PLB/CREB');
% subplot(2,3,3);semilogx(ISO,SS(:,5),'k.-',ISO,SS(:,6),'r.-');axis([1e-6 1e2 -0.1 1.1]);title('AKAR');
% 
% figure(4);
% labels = {'LR' 'LRG' 'RG' 'b1AR S464' 'b1AR S301' ...
%   'GsaGTPtot' 'GsaGDP' 'Gsby' 'AC GsaGTP' 'cAMPtot' 'PDEp' ...
%   'RCcAMP I' 'RCcAMPcAMP I' 'RcAMPcAMP I' 'PKACI' 'PKACI PKI' ...
%   'RCcAMP II' 'RCcAMPcAMP II' 'RcAMPcAMP II' 'PKACII' 'PKACII PKI' ...
%   'nPKI' 'nPKACII' 'nPKACII PKI' ...
%   'I1p PP1' 'I1ptot' 'LCCap' 'LCCbp' 'PLBp' 'PLMp' 'TnIp' ...
%   'CREBp' 'AKARnesp' 'AKARnlsp'};
% 
% for i = 1:34
%     subplot(6,6,i);semilogx(ISO,ySS(:,i),'k.-');axis([1e-6 1e2 0.9*min(ySS(:,i)) 1.1*max(ySS(:,i))]);title(labels{i})
% end
% 
% PKItot = params(44);
% PKACI_PKI = ySS(:,16);
% PKACII_PKI = ySS(:,21);
% nPKI = ySS(:,22);
% nPKACII_PKI = ySS(:,24);
% VnucF = params(4);
% 
% PKI = PKItot - PKACI_PKI - PKACII_PKI - nPKI*VnucF - nPKACII_PKI*VnucF;
% 
% subplot(6,6,35);semilogx(ISO,PKI,'k.-');axis([1e-6 1e2 0.9*min(PKI) 1.1*max(PKI)]);title('PKI')
% 
% [linterp(SS(1:round(1.2*length(ISO)/2),1),ISO(1:round(1.2*length(ISO)/2)),0.5) linterp(SS(1:round(1.2*length(ISO)/2),2),ISO(1:round(1.2*length(ISO)/2)),0.5)
%  linterp(SS(1:round(1.2*length(ISO)/2),3),ISO(1:round(1.2*length(ISO)/2)),0.5) linterp(SS(1:round(1.2*length(ISO)/2),4),ISO(1:round(1.2*length(ISO)/2)),0.5)
%  linterp(SS(1:round(1.2*length(ISO)/2),5),ISO(1:round(1.2*length(ISO)/2)),0.5) linterp(SS(1:round(1.2*length(ISO)/2),6),ISO(1:round(1.2*length(ISO)/2)),0.5)]*1e3

%%
% load tempICs;
% 
% tspan = [0 30*60e3];
% options = odeset('NonNegative',1:34,'RelTol',1e-3,'AbsTol',1e-4);
% params(1) = 1; % (uM)
% 
% [t,y] = ode15s(@PKAode,tspan,y0,options,params);
% 
% t = t./60e3;
% nPKA = y(:,23);nPKA = nPKA-nPKA(1);nPKA = nPKA./nPKA(end);
% A3nls = y(:,34);A3nls = A3nls-A3nls(1);A3nls = A3nls./A3nls(end);
% 
% [linterp(nPKA,t,0.5) linterp(A3nls,t,0.5)]
% figure(3);plot(t,nPKA);
% 
% plotAll(t,y,params)