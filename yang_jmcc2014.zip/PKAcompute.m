%%

% Simulation Conditions
params = PKAparams;

% Run Simulation
load tempICs

% Resting Initial Conditions
tspan = [0 1e10];
options = odeset('NonNegative',1:36);
params(1) = 0;

[t,y] = ode15s(@PKAode,tspan,y0,options,params);
y0 = y(end,:)';
save tempICs y0;

% b-Adrenergic Stimulation
tspan = [0 30*60e3];
options = odeset('NonNegative',1:36);
params(1) = 0.012; % (uM)

[t,y] = ode15s(@PKAode,tspan,y0,options,params);
y0 = y(end,:)';
% save tempICs y0;

%% Plot Outputs

t = t/60e3;

plotPKI(t,y,params)
% plotAll(t,y)
% plotPKA(t,y)
% doseResponse;