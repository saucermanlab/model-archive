function plotPKI(t,y,params)

VnucF = params(4);
PKItot = params(44);
PKACI_PKI = y(:,16);
PKACII_PKI = y(:,21);
nPKI = y(:,22);
nPKACII_PKI = y(:,24);

PKI = PKItot - PKACI_PKI - PKACII_PKI - nPKI*VnucF - nPKACII_PKI*VnucF;

PKACI = y(:,15);
PKACII = y(:,20);
nPKACII = y(:,23);

AKARnes = y(:,33);
AKARnls = y(:,34);

figure(1);
subplot(4,2,1);hold on;plot(t,PKACII);title('PKA CII');
subplot(4,2,2);hold on;plot(t,nPKACII);title('nPKA CII');
subplot(4,2,3);hold on;plot(t,PKACII_PKI);title('PKA CII PKI')
subplot(4,2,4);hold on;plot(t,nPKACII_PKI);title('nPKA CII PKI');
subplot(4,2,5);hold on;plot(t,PKI);title('PKI')
subplot(4,2,6);hold on;plot(t,nPKI);title('nPKI')
subplot(4,2,7);hold on;plot(t,AKARnes);title('AKARnes')
subplot(4,2,8);hold on;plot(t,AKARnls);title('AKARnls')
