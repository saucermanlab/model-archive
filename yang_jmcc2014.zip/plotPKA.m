function plotPKA(t,y)

figure
subplot(4,3,1);
plot(t,y(:,10));
ylabel('[cAMP] (\muM)');
xlabel('time (min)');

subplot(4,3,2);
plot(t,y(:,16));
ylabel('[PKA C]_I (\muM)');
xlabel('time (min)');

subplot(4,3,3);
plot(t,y(:,22));
ylabel('[PKA C]_I_I (\muM)');
xlabel('time (min)');

subplot(4,3,6);
plot(t,y(:,24));
ylabel('[n-PKA C]_I_I (\muM)');
xlabel('time (min)');

subplot(4,3,7);
plot(t,y(:,28));
ylabel('[p-I-1] (\muM)');
xlabel('time (min)');

subplot(4,3,8);
plot(t,y(:,29),t,y(:,30));
ylabel('[p-LCC] (\muM)');
xlabel('time (min)');

subplot(4,3,4);
plot(t,y(:,31));
ylabel('[p-PLB] (\muM)');
xlabel('time (min)');

subplot(4,3,10);
plot(t,y(:,32));
ylabel('[p-PLM] (\muM)');
xlabel('time (min)');

subplot(4,3,11);
plot(t,y(:,33));
ylabel('[p-TnI] (\muM)');
xlabel('time (min)');

subplot(4,3,5);
plot(t,y(:,34));
ylabel('[p-CREB] (\muM)');
xlabel('time (min)');

subplot(4,3,9);
plot(t,y(:,35));
ylabel('[p-AKARnes] (\muM)');
xlabel('time (min)');

subplot(4,3,12);
plot(t,y(:,36));
ylabel('[p-AKARnls] (\muM)');
xlabel('time (min)');