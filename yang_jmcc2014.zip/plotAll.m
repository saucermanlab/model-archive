function plotAll(t,y,params)

VnucF = params(4);
PKItot = params(44);
PKACI_PKI = y(:,16);
PKACII_PKI = y(:,21);
nPKI = y(:,22);
nPKACII_PKI = y(:,24);

PKI = PKItot - PKACI_PKI - PKACII_PKI - nPKI*VnucF - nPKACII_PKI*VnucF;

figure(3);
labels = {'LR' 'LRG' 'RG' 'b1AR S464' 'b1AR S301' ...
  'GsaGTPtot' 'GsaGDP' 'Gsby' 'AC GsaGTP' 'cAMPtot' 'PDEp' ...
  'RCcAMP I' 'RCcAMPcAMP I' 'RcAMPcAMP I' 'PKACI' 'PKACI PKI' ...
  'RCcAMP II' 'RCcAMPcAMP II' 'RcAMPcAMP II' 'PKACII' 'PKACII PKI' ...
  'nPKI' 'nPKACII' 'nPKACII PKI' ...
  'I1p PP1' 'I1ptot' 'LCCap' 'LCCbp' 'PLBp' 'PLMp' 'TnIp' ...
  'CREBp' 'AKARnesp' 'AKARnlsp'};

for i = 1:34
    subplot(6,6,i);plot(t,y(:,i));title(labels{i});axis([0 60 0.9*min(y(:,i)) 1.1*max(y(:,i))]);
end

subplot(6,6,35);plot(t,PKI);title('PKI');axis([0 60 0.9*min(PKI) 1.1*max(PKI)]);