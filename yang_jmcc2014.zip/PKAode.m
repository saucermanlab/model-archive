function dydt = PKAode(t,y,params)

%% Assign Parameters and State Variables
pCell = num2cell(params);
[ISO FSK IBMX ...
  VnucF DPKIcn DPKACIIcn DPKACII_PKInc PKIbias ...
  b1ARtot kf_LR kf_LRG kf_RG kr_LR kr_LRG kr_RG ...
  Gstot k_G_act k_G_hyd k_G_reassoc ...
  kf_bARK kr_bARK kf_PKA kr_PKA ...
  ACtot ATP k_AC_basal Km_AC_basal ...
  kf_AC_Gsa kr_AC_Gsa k_AC_Gsa Km_AC_Gsa ...
  Kd_AC_FSK k_AC_FSK Km_AC_FSK ...
  PDEtot k_cAMP_PDE k_cAMP_PDEp Km_PDE_cAMP ...
  Kd_PDE_IBMX k_PKA_PDE k_PP_PDE ...
  PKAItot PKAIItot PKItot ...
  kf_RC_cAMP kf_RCcAMP_cAMP kf_RcAMPcAMP_C kf_PKA_PKI ...
  kr_RC_cAMP kr_RCcAMP_cAMP kr_RcAMPcAMP_C kr_PKA_PKI ...
  epsilon ...
  PP1tot I1tot k_PKA_I1 Km_PKA_I1 Vmax_PP2A_I1 Km_PP2A_I1 ...
  kf_PP1_I1 kr_PP1_I1 ...
  LCCtot PKACII_LCCtot PP1_LCC PP2A_LCC ...
  k_PKA_LCC Km_PKA_LCC k_PP1_LCC Km_PP1_LCC k_PP2A_LCC Km_PP2A_LCC ...
  PLBtot k_PKA_PLB Km_PKA_PLB k_PP1_PLB Km_PP1_PLB ...
  PLMtot k_PKA_PLM Km_PKA_PLM k_PP1_PLM Km_PP1_PLM ...
  TnItot PP2A_TnI k_PKA_TnI Km_PKA_TnI k_PP2A_TnI Km_PP2A_TnI ...
  CREBtot PP2A_CREB k_PKA_CREB Km_PKA_CREB k_PP2A_CREB Km_PP2A_CREB ...
  AKARnestot PP2A_AKARnes k_PKA_AKARnes Km_PKA_AKARnes k_PP2A_AKARnes Km_PP2A_AKARnes ...
  AKARnlstot PP2A_AKARnls k_PKA_AKARnls Km_PKA_AKARnls k_PP2A_AKARnls Km_PP2A_AKARnls ...
  ] = pCell{:};

yCell = num2cell(y);
[LR LRG RG b1AR_S464 b1AR_S301 ...
  GsaGTPtot GsaGDP Gsby AC_GsaGTP cAMPtot PDEp ...
  RCcAMP_I RCcAMPcAMP_I RcAMPcAMP_I PKACI PKACI_PKI ...
  RCcAMP_II RCcAMPcAMP_II RcAMPcAMP_II PKACII PKACII_PKI ...
  nPKI nPKACII nPKACII_PKI ...
  I1p_PP1 I1ptot LCCap LCCbp PLBp PLMp TnIp ...
  CREBp AKARnesp AKARnlsp ...
  ]=yCell{:};

%% Signaling Module

% b-AR/Gs module
b1ARact = b1ARtot - b1AR_S464 - b1AR_S301;
b1AR = b1ARact - LR - LRG - RG;
Gs = Gstot - LRG - RG - Gsby;

dLR = kf_LR*ISO*b1AR - kr_LR*LR;
dLRG = kf_LRG*LR*Gs - kr_LRG*LRG - k_G_act*LRG;
dRG = kf_RG*b1AR*Gs - kr_RG*RG - k_G_act*RG;

bARK_desens = kf_bARK*(LR+LRG);
bARK_resens = kr_bARK*b1AR_S464;
PKA_desens = kf_PKA*PKACI*b1ARact;
PKA_resens = kr_PKA*b1AR_S301;
db1AR_S464 = bARK_desens - bARK_resens;
db1AR_S301 = PKA_desens - PKA_resens;

G_act = k_G_act*(RG+LRG);
G_hyd = k_G_hyd*GsaGTPtot;
G_reassoc = k_G_reassoc*GsaGDP*Gsby;
dGsaGTPtot = G_act - G_hyd;
dGsaGDP = G_hyd - G_reassoc;
dGsby = G_act - G_reassoc;

% cAMP module
cAMP = cAMPtot - (RCcAMP_I+2*RCcAMPcAMP_I+2*RcAMPcAMP_I) - (RCcAMP_II+2*RCcAMPcAMP_II+2*RcAMPcAMP_II);
AC = ACtot-AC_GsaGTP;
GsaGTP = GsaGTPtot - AC_GsaGTP;
dAC_GsaGTP = kf_AC_Gsa*GsaGTP*AC - kr_AC_Gsa*AC_GsaGTP;

AC_FSK = FSK*AC/Kd_AC_FSK;
AC_ACT_BASAL = k_AC_basal*AC*ATP/(Km_AC_basal+ATP);
AC_ACT_GSA = k_AC_Gsa*AC_GsaGTP*ATP/(Km_AC_Gsa+ATP);
AC_ACT_FSK = k_AC_FSK*AC_FSK*ATP/(Km_AC_FSK+ATP);

PDE_IBMX = PDEtot*IBMX/Kd_PDE_IBMX;
PDE = PDEtot - PDE_IBMX - PDEp;
dPDEp = k_PKA_PDE*PKACII*PDE - k_PP_PDE*PDEp;
PDE_ACT = k_cAMP_PDE*PDE*cAMP/(Km_PDE_cAMP+cAMP) + k_cAMP_PDEp*PDEp*cAMP/(Km_PDE_cAMP+cAMP);

dcAMPtot = AC_ACT_BASAL + AC_ACT_GSA + AC_ACT_FSK - PDE_ACT;

%% PKA Activity

% PKA / PKI Transport
PKI = PKItot - PKACI_PKI - PKACII_PKI - nPKI*VnucF - nPKACII_PKI*VnucF;

JPKACIIcn = DPKACIIcn*(PKACII-nPKACII);
JPKIcn = DPKIcn*(PKI-nPKI/PKIbias);
JPKACII_PKIcn = -DPKACII_PKInc*nPKACII_PKI*VnucF;

% Cytosolic PKA module
RC_I = 2*PKAItot - RCcAMP_I - RCcAMPcAMP_I - RcAMPcAMP_I;
RC_II = 2*PKAIItot - RCcAMP_II - RCcAMPcAMP_II - RcAMPcAMP_II;

dRCcAMP_I = - kr_RC_cAMP*RCcAMP_I + kf_RC_cAMP*RC_I*cAMP - kf_RCcAMP_cAMP*RCcAMP_I*cAMP + kr_RCcAMP_cAMP*RCcAMPcAMP_I;
dRCcAMPcAMP_I = - kr_RCcAMP_cAMP*RCcAMPcAMP_I + kf_RCcAMP_cAMP*RCcAMP_I*cAMP - kf_RcAMPcAMP_C*RCcAMPcAMP_I + kr_RcAMPcAMP_C*RcAMPcAMP_I*PKACI;
dRcAMPcAMP_I = - kr_RcAMPcAMP_C*RcAMPcAMP_I*PKACI + kf_RcAMPcAMP_C*RCcAMPcAMP_I;
dPKACI = - kr_RcAMPcAMP_C*RcAMPcAMP_I*PKACI + kf_RcAMPcAMP_C*RCcAMPcAMP_I - kf_PKA_PKI*PKACI*PKI + kr_PKA_PKI*PKACI_PKI;
dPKACI_PKI = - kr_PKA_PKI*PKACI_PKI + kf_PKA_PKI*PKACI*PKI;

dRCcAMP_II = - kr_RC_cAMP*RCcAMP_II + kf_RC_cAMP*RC_II*cAMP - kf_RCcAMP_cAMP*RCcAMP_II*cAMP + kr_RCcAMP_cAMP*RCcAMPcAMP_II;
dRCcAMPcAMP_II = - kr_RCcAMP_cAMP*RCcAMPcAMP_II + kf_RCcAMP_cAMP*RCcAMP_II*cAMP - kf_RcAMPcAMP_C*RCcAMPcAMP_II + kr_RcAMPcAMP_C*RcAMPcAMP_II*PKACII;
dRcAMPcAMP_II = - kr_RcAMPcAMP_C*RcAMPcAMP_II*PKACII + kf_RcAMPcAMP_C*RCcAMPcAMP_II;
dPKACII = - kr_RcAMPcAMP_C*RcAMPcAMP_II*PKACII + kf_RcAMPcAMP_C*RCcAMPcAMP_II - kf_PKA_PKI*PKACII*PKI + kr_PKA_PKI*PKACII_PKI - JPKACIIcn;
dPKACII_PKI = - kr_PKA_PKI*PKACII_PKI + kf_PKA_PKI*PKACII*PKI - JPKACII_PKIcn;

% Nuclear PKA module
dnPKI = kr_PKA_PKI*nPKACII_PKI - kf_PKA_PKI*nPKACII*nPKI + JPKIcn/VnucF;
dnPKACII = kr_PKA_PKI*nPKACII_PKI - kf_PKA_PKI*nPKACII*nPKI + JPKACIIcn/VnucF;
dnPKACII_PKI = - kr_PKA_PKI*nPKACII_PKI + kf_PKA_PKI*nPKACII*nPKI + JPKACII_PKIcn/VnucF;

% I-1/PP1 module
I1 = I1tot - I1ptot;
PP1 = PP1tot - I1p_PP1;
I1p = I1ptot - I1p_PP1;
I1_phosph = k_PKA_I1*PKACI*I1/(Km_PKA_I1+I1);
I1_dephosph = Vmax_PP2A_I1*I1ptot/(Km_PP2A_I1+I1ptot);

dI1p_PP1 = kf_PP1_I1*PP1*I1p - kr_PP1_I1*I1p_PP1;
dI1ptot = I1_phosph - I1_dephosph;

%% PKA Substrate Phosphorylation

% LCC module
PKACII_LCC = (PKACII_LCCtot/PKAIItot)*PKACII;
LCCa = LCCtot - LCCap;
LCCa_phosph = epsilon*k_PKA_LCC*PKACII_LCC*LCCa/(Km_PKA_LCC+epsilon*LCCa);
LCCa_dephosph = epsilon*k_PP2A_LCC*PP2A_LCC*LCCap/(Km_PP2A_LCC+epsilon*LCCap);
dLCCap = LCCa_phosph - LCCa_dephosph;

LCCb = LCCtot - LCCbp;
LCCb_phosph = epsilon*k_PKA_LCC*PKACII_LCC*LCCb/(Km_PKA_LCC+epsilon*LCCb);
LCCb_dephosph = epsilon*k_PP1_LCC*PP1_LCC*LCCbp/(Km_PP1_LCC+epsilon*LCCbp);
dLCCbp = LCCb_phosph - LCCb_dephosph;

% PLB module
PLB = PLBtot - PLBp;
PLB_phosph = k_PKA_PLB*PKACI*PLB/(Km_PKA_PLB+PLB);
PLB_dephosph = k_PP1_PLB*PP1*PLBp/(Km_PP1_PLB+PLBp);
dPLBp = PLB_phosph - PLB_dephosph;

% PLM module
PLM = PLMtot - PLMp;
PLM_phosph = k_PKA_PLM*PKACI*PLM/(Km_PKA_PLM+PLM);
PLM_dephosph = k_PP1_PLM*PP1*PLMp/(Km_PP1_PLM+PLMp);
dPLMp = PLM_phosph - PLM_dephosph;

% TnI module
TnI = TnItot - TnIp;
TnI_phosph = k_PKA_TnI*PKACI*TnI/(Km_PKA_TnI+TnI);
TnI_dephosph = k_PP2A_TnI*PP2A_TnI*TnIp/(Km_PP2A_TnI+TnIp);
dTnIp = TnI_phosph - TnI_dephosph;

% CREB module
CREB = CREBtot - CREBp;
CREB_phosph = k_PKA_CREB*nPKACII*CREB/(Km_PKA_CREB+CREB);
CREB_dephosph = k_PP2A_CREB*PP2A_CREB*CREBp/(Km_PP2A_CREB+CREBp);
dCREBp = CREB_phosph - CREB_dephosph;

% AKARnes module
AKARnes = AKARnestot - AKARnesp;
AKARnes_phosph = k_PKA_AKARnes*PKACII*AKARnes/(Km_PKA_AKARnes+AKARnes);
AKARnes_dephosph = k_PP2A_AKARnes*PP2A_AKARnes*AKARnesp/(Km_PP2A_AKARnes+AKARnesp);
dAKARnesp = AKARnes_phosph - AKARnes_dephosph;

% AKARnls module
AKARnls = AKARnlstot - AKARnlsp;
AKARnls_phosph = k_PKA_AKARnls*nPKACII*AKARnls/(Km_PKA_AKARnls+AKARnls);
AKARnls_dephosph = k_PP2A_AKARnls*PP2A_AKARnls*AKARnlsp/(Km_PP2A_AKARnls+AKARnlsp);
dAKARnlsp = AKARnls_phosph - AKARnls_dephosph;

%% Reassemble dydt

dydt = [dLR dLRG dRG db1AR_S464 db1AR_S301 ...
  dGsaGTPtot dGsaGDP dGsby ...
  dAC_GsaGTP dcAMPtot dPDEp ...
  dRCcAMP_I dRCcAMPcAMP_I dRcAMPcAMP_I dPKACI dPKACI_PKI ...
  dRCcAMP_II dRCcAMPcAMP_II dRcAMPcAMP_II dPKACII dPKACII_PKI ...
  dnPKI dnPKACII dnPKACII_PKI ...
  dI1p_PP1 dI1ptot ...
  dLCCap dLCCbp dPLBp dPLMp dTnIp ...
  dCREBp dAKARnesp dAKARnlsp ...
  ]';

