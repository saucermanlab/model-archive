function params = PKAparams()

%% Global Parameters
% Physical Parameters
VnucF = 0.02;                     % (%) Nuclear fractional volume (Bers, p7)

% Transport Parameters
DPKIcn = 19.8-6;                  % (1/ms) PKI cyt->nuc diffusion rate
DPKACIIcn = 5.95238e-7/5;         % (1/ms) PKACII cyt->nuc diffusion rate
DPKACII_PKInc = 3.2e-6;             % (1/ms) PKACII_PKI nuc->cyt export rate

PKIbias = 50;                     % (-) PKI nuclear expression bias

%% Signaling Parameters

% Drug Concentrations
ISO             = 0;              % (uM) isoproterenol concentration
FSK             = 0;              % (uM) forskolin concentration
IBMX            = 0;              % (uM) IBMX concentration

% b-AR/Gs module
b1ARtot         = 0.0132;         % (uM)y0 total b1-AR protein
kf_LR           = 1;              % (1/[uM ms]) forward rate for ISO binding to b1AR
kr_LR           = 0.285;          % (1/ms) reverse rate for ISO binding to b1AR
kf_LRG          = 1;              % (1/[uM ms]) forward rate for ISO:b1AR association with Gs
kr_LRG          = 0.062;          % (1/ms) reverse rate for ISO:b1AR association with Gs
kf_RG           = 1;              % (1/[uM ms]) forward rate for b1AR association with Gs
kr_RG           = 33;             % (1/ms) reverse rate for b1AR association with Gs

Gstot           = 3.83;           % (uM) total Gs protein
k_G_act         = 16e-3;          % (1/ms) rate constant for Gs activation
k_G_hyd         = 0.8e-3;         % (1/ms) rate constant for G-protein hydrolysis
k_G_reassoc     = 1.21;           % (1/[uM us]) rate constant for G-protein reassociation

kf_bARK         = 1.1e-6;         % (1/[uM ms]) forward rate for b1AR phosphorylation by b1ARK
kr_bARK         = 2.2e-6;         % (1/ms) reverse rate for b1AR phosphorylation by b1ARK
kf_PKA          = 3.6e-6;         % (1/[uM ms]) forward rate for b1AR phosphorylation by PKA
kr_PKA          = 2.2e-6;         % (1/ms) reverse rate for b1AR phosphorylation by PKA

% AC module
ACtot           = 49.7e-3;       % (uM) total adenylyl cyclase
ATP             = 5e3;            % (uM) total ATP
k_AC_basal      = 0.2e-3;         % (1/ms) basal cAMP generation rate by AC
Km_AC_basal     = 1.03e3;         % (uM) basal AC affinity for ATP

Kd_AC_Gsa       = 0.4;            % (uM) Kd for AC association with Gsa
kf_AC_Gsa       = 1;              % (1/[uM ms]) forward rate for AC association with Gsa
kr_AC_Gsa       = Kd_AC_Gsa;      % (1/ms) reverse rate for AC association with Gsa

k_AC_Gsa        = 8.5e-3;         % (1/ms) basal cAMP generation rate by AC:Gsa
Km_AC_Gsa       = 315.0;          % (uM) AC:Gsa affinity for ATP

Kd_AC_FSK       = 44.0;           % (uM) Kd for FSK binding to AC
k_AC_FSK        = 7.3e-3;         % (1/ms) basal cAMP generation rate by AC:FSK
Km_AC_FSK       = 860.0;          % (uM) AC:FSK affinity for ATP

PDEtot          = 38.9e-3;       % (uM) total phosphodiesterase
k_cAMP_PDE      = 5e-3;           % (1/ms) cAMP hydrolysis rate by PDE
k_cAMP_PDEp     = 2*k_cAMP_PDE;   % (1/ms) cAMP hydrolysis rate by phosphorylated PDE
Km_PDE_cAMP     = 1.3;            % (uM) PDE affinity for cAMP

Kd_PDE_IBMX     = 30.0;           % (uM) Kd_R2cAMP_C for IBMX binding to PDE
k_PKA_PDE       = 7.5e-3;         % (1/ms) rate constant for PDE phosphorylation by type 1 PKA
k_PP_PDE        = 1.5e-3;         % (1/ms) rate constant for PDE dephosphorylation by phosphatases

% PKA module
PKAItot         = 0.59;           % (uM) total type 1 PKA
PKAIItot        = 0.059;          % (uM) total type 2 PKA
PKItot          = 0.18;           % (uM) total PKI
kf_RC_cAMP      = 1;              % (1/[uM ms]) Kd for PKA RC binding to cAMP
kf_RCcAMP_cAMP  = 1;              % (1/[uM ms]) Kd for PKA RC:cAMP binding to cAMP
kf_RcAMPcAMP_C  = 4.375;          % (1/[uM ms]) Kd for PKA R:cAMPcAMP binding to C
kf_PKA_PKI      = 1;              % (1/[uM ms]) Ki for PKA inhibition by PKI
kr_RC_cAMP      = 1.64;           % (1/ms) Kd for PKA RC binding to cAMP
kr_RCcAMP_cAMP  = 9.14;           % (1/ms) Kd for PKA RC:cAMP binding to cAMP
kr_RcAMPcAMP_C  = 1;              % (1/ms) Kd for PKA R:cAMPcAMP binding to C
kr_PKA_PKI      = 0.2e-3;         % (1/ms) Ki for PKA inhibition by PKI
epsilon         = 10;             % (-) AKAP-mediated scaling factor

% PP1 module
PP1tot          = 0.89;           % (uM) total phosphatase 1
I1tot           = 0.3;            % (uM) total inhibitor 1
k_PKA_I1        = 60e-3;          % (1/ms) rate constant for I-1 phosphorylation by type 1 PKA
Km_PKA_I1       = 1.0;            % (uM) Km for I-1 phosphorylation by type 1 PKA
Vmax_PP2A_I1    = 14.0e-3;        % (uM/ms) Vmax for I-1 dephosphorylation by PP2A
Km_PP2A_I1      = 1.0;          	% (uM) Km for I-1 dephosphorylation by PP2A

Ki_PP1_I1       = 1.0e-3;         % (uM) Ki for PP1 inhibition by I-1
kf_PP1_I1       = 1;              % (1/[uM ms]) Ki for PP1 inhibition by I-1
kr_PP1_I1       = Ki_PP1_I1;      % (1/ms) Ki for PP1 inhibition by I-1

% LCC module
LCCtot          = 0.025;          % (uM) total ISO-type Ca channels
PKACII_LCCtot   = 0.025;          % (uM) type 2 PKA available to phosphorylate LCC
PP1_LCC         = 0.025;          % (uM) PP1 available to dephosphorylate LCC
PP2A_LCC        = 0.025;          % (uM) PP2A available to dephosphorylate LCC
k_PKA_LCC       = 54e-3;          % (1/ms) rate constant for LCC phosphorylation by type 2 PKA
Km_PKA_LCC      = 21;             % (uM) Km for LCC phosphorylation by type 2 PKA
k_PP1_LCC       = 8.52e-3;        % (1/ms) rate constant for LCC dephosphorylation by PP1
Km_PP1_LCC      = 3;            	% (uM) Km for LCC dephosphorylation by PP1
k_PP2A_LCC      = 10.1e-3;      	% (1/ms) rate constant for LCC dephosphorylation by PP2A
Km_PP2A_LCC     = 3;              % (uM) Km for LCC dephosphorylation by PP2A

% PLB module
PLBtot          = 106;            % (uM) total phospholamban
k_PKA_PLB       = 54e-3;          % (1/ms) rate constant for PLB phosphorylation by type 1 PKA
Km_PKA_PLB      = 21;             % (uM) Km for PLB phosphorylation by type 1 PKA
k_PP1_PLB       = 8.5e-3;         % (1/ms) rate constant for PLB dephosphorylation by PP1
Km_PP1_PLB      = 7.0;            % (uM) Km for PLB dephosphorylation by PP1

% PLM module
PLMtot          = 48;             % (uM) total phospholemman
k_PKA_PLM       = 54e-3;          % (1/ms) rate constant for PLM phosphorylation by type 1 PKA
Km_PKA_PLM      = 21;             % (uM) Km for PLM phosphorylation by type 1 PKA
k_PP1_PLM       = 8.5e-3;         % (1/ms) rate constant for PLM dephosphorylation by PP1
Km_PP1_PLM      = 7;              % (uM) Km for PLM dephosphorylation by PP1

% TnI module
TnItot          = 70;             % (uM) total troponin I
PP2A_TnI        = 0.67;           % (uM) PP2A available to dephosphorylate TnI
k_PKA_TnI       = 54e-3;          % (1/ms) rate constant for TnI phosphorylation by type 1 PKA
Km_PKA_TnI      = 21;             % (uM) Km for TnI phosphorylation by type 1 PKA
k_PP2A_TnI      = 10.1e-3;        % (1/ms) rate constant for TnI dephosphorylation by PP2A
Km_PP2A_TnI     = 4.1;            % (uM) Km for TnI dephosphorylation by PP2A

% CREB module
CREBtot         = 0.9;            % (uM) total CREB
PP2A_CREB       = 0.12;           % (uM) PP2A available to dephosphorylate LCC
k_PKA_CREB      = 54e-3;          % (1/ms) rate constant for CREB phosphorylation by type 2 PKA
Km_PKA_CREB     = 10;             % (uM) Km for CREB phosphorylation by type 2 PKA
k_PP2A_CREB     = 8.5e-3;         % (1/ms) rate constant for CREB dephosphorylation by PP2A
Km_PP2A_CREB    = 2.46;           % (uM) Km for CREB dephosphorylation by PP2A

% AKAR module
AKARnestot      = 1.25;           % (uM) total AKARnes
PP2A_AKARnes    = 0.5;            % (uM) PP2A available to dephosphorylate LCC - Ni Q, Nat Chem Biol 2011
k_PKA_AKARnes   = 152e-3;         % (1/ms) rate constant for AKARnes phosphorylation by type 2 PKA - Ni Q, Nat Chem Biol 2011
Km_PKA_AKARnes  = 16;             % (uM) Km for AKARnes phosphorylation by type 2 PKA - Ni Q, Nat Chem Biol 2011
k_PP2A_AKARnes  = 8.5e-3;         % (1/ms) rate constant for AKARnes dephosphorylation by PP2A
Km_PP2A_AKARnes = 7;              % (uM) Km for AKARnes dephosphorylation by PP2A

AKARnlstot      = 3.48;           % (uM) total AKARnls
PP2A_AKARnls    = 0.5;            % (uM) PP2A available to dephosphorylate LCC - Ni Q, Nat Chem Biol 2011
k_PKA_AKARnls   = 152e-3;         % (1/ms) rate constant for AKARnls phosphorylation by type 2 PKA - Ni Q, Nat Chem Biol 2011
Km_PKA_AKARnls  = 16;             % (uM) Km for AKARnls phosphorylation by type 2 PKA - Ni Q, Nat Chem Biol 2011
k_PP2A_AKARnls  = 8.5e-3;         % (1/ms) rate constant for AKARnls dephosphorylation by PP2A
Km_PP2A_AKARnls = 7;              % (uM) Km for AKARnls dephosphorylation by PP2A

%% Assemble Parameters Array
params = [ISO FSK IBMX ...
  VnucF DPKIcn DPKACIIcn DPKACII_PKInc PKIbias ...
  b1ARtot kf_LR kf_LRG kf_RG kr_LR kr_LRG kr_RG ...
  Gstot k_G_act k_G_hyd k_G_reassoc ...
  kf_bARK kr_bARK kf_PKA kr_PKA ...
  ACtot ATP k_AC_basal Km_AC_basal ...
  kf_AC_Gsa kr_AC_Gsa k_AC_Gsa Km_AC_Gsa ...
  Kd_AC_FSK k_AC_FSK Km_AC_FSK ...
  PDEtot k_cAMP_PDE k_cAMP_PDEp Km_PDE_cAMP ...
  Kd_PDE_IBMX k_PKA_PDE k_PP_PDE ...
  PKAItot PKAIItot PKItot ...
  kf_RC_cAMP kf_RCcAMP_cAMP kf_RcAMPcAMP_C kf_PKA_PKI ...
  kr_RC_cAMP kr_RCcAMP_cAMP kr_RcAMPcAMP_C kr_PKA_PKI ...
  epsilon ...
  PP1tot I1tot k_PKA_I1 Km_PKA_I1 Vmax_PP2A_I1 Km_PP2A_I1 ...
  kf_PP1_I1 kr_PP1_I1 ...
  LCCtot PKACII_LCCtot PP1_LCC PP2A_LCC ...
  k_PKA_LCC Km_PKA_LCC k_PP1_LCC Km_PP1_LCC k_PP2A_LCC Km_PP2A_LCC ...
  PLBtot k_PKA_PLB Km_PKA_PLB k_PP1_PLB Km_PP1_PLB ...
  PLMtot k_PKA_PLM Km_PKA_PLM k_PP1_PLM Km_PP1_PLM ...
  TnItot PP2A_TnI k_PKA_TnI Km_PKA_TnI k_PP2A_TnI Km_PP2A_TnI ...
  CREBtot PP2A_CREB k_PKA_CREB Km_PKA_CREB k_PP2A_CREB Km_PP2A_CREB ...
  AKARnestot PP2A_AKARnes k_PKA_AKARnes Km_PKA_AKARnes k_PP2A_AKARnes Km_PP2A_AKARnes ...
  AKARnlstot PP2A_AKARnls k_PKA_AKARnls Km_PKA_AKARnls k_PP2A_AKARnls Km_PP2A_AKARnls ...
  ];
