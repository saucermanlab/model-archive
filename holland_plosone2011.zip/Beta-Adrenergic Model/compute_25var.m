%%
%Compute.m
%Will run a simulation of the 25-variable model
%Calls function computeSignaling_25var.m

clear p;
global p; 

global Counter T_array Var_matrix;

Counter=1;
T_array=zeros(1,800);
Var_matrix=zeros(800,5);

tspan = [0 4e5]; 

tic
parameters_script = 'signaling_parameters';     %name of script to load parameters
initial_conditions = 'signaling_ICs.dat'; %file name with initial conditions
[t,y,t2,y2] =  computeSignaling_25var(parameters_script, initial_conditions, tspan);
toc


