function ydot = mouse_signalingODEfile_25var(t,y,Ltotmax)
% 20060907 (JSS)
% based on saucerman_pbmb2004_20060907a.m

global p;
global Counter T_array Var_matrix
ydot = zeros(size(y));

%y(1)=Ligand
%y(2)=Receptor
%y(3)=Gs
%y(4)=B1ARtot
%y(5)=B1ARd
%y(6)=B1ARp
%y(7)=Gsa_gtp_tot
%y(8)=Gsa_gdp
%y(9)=GsBy
%y(10)=Gsa_gtp
%y(11)=Fsk
%y(12)=AC
%y(13)=PDE
%y(14)=IBMX
%y(15)=cAMPtot
%y(16)=cAMP
%y(17)=PKACi or PKA1
%y(18)=PKACii or PKA2
%y(19)=PLBp
%y(20)=Inhib1ptot
%y(21)=Inhib1p
%y(22)=PP1
%y(23)=LCCap
%y(24)=LCCbp
%y(25)=Tnlp

% -------- SIGNALING MODEL -----------
% b-AR module
LR = y(1)*y(2)/p(4);
LRG = LR*y(3)/p(5);
RG = y(2)*y(3)/p(6);
BARKDESENS = p(7)*(LR+LRG);
BARKRESENS = p(8)*y(5);
PKADESENS = p(9)*y(17)*y(4);  
PKARESENS = p(10)*y(6);
GACT = p(11)*(RG+LRG);
HYD = p(12)*y(7);
REASSOC = p(13)*y(8)*y(9);
ydot(1) = p(1)-LR-LRG-y(1);
ydot(2) = y(4)-LR-LRG-RG-y(2);
ydot(3) = p(3)-LRG-RG-y(3);
ydot(4) = 1e-3*( (BARKRESENS-BARKDESENS)+(PKARESENS-PKADESENS) );
ydot(5) = 1e-3*( BARKDESENS-BARKRESENS );
ydot(6) = 1e-3*( PKADESENS-PKARESENS );
ydot(7) = 1e-3*( GACT-HYD);
ydot(8) = 1e-3*( HYD-REASSOC );
ydot(9) = 1e-3*( GACT-REASSOC );
% end b-AR module

% cAMP module
Gsa_gtp_AC = y(10)*y(12)/p(27);
Fsk_AC = y(11)*y(12)/p(28);
AC_ACT_BASAL = p(19)*y(12)*p(15)/(p(23)+p(15))	 ;   
AC_ACT_GSA = p(20)*Gsa_gtp_AC*p(15)/(p(24)+p(15));
AC_ACT_FSK = p(21)*Fsk_AC*p(15)/(p(25)+p(15));	   
PDE_ACT = p(22)*y(13)*y(16)/(p(26)+y(16));	
PDE_IBMX = y(13)*y(14)/p(29);
ydot(10) = y(7)-Gsa_gtp_AC-y(10);
ydot(11) = p(18)-Fsk_AC-y(11);
Fsk=p(18)-Fsk_AC;
AC=.0497-Fsk_AC;
ydot(12) = p(14)-Fsk_AC-Gsa_gtp_AC-y(12);  % note: assumes Fsk = 0.  Change Gsa_gtp_AC to Fsk_AC for Forskolin.
ydot(13) = p(16)-PDE_IBMX-y(13);
ydot(14) = p(17)-PDE_IBMX-y(14);
ydot(15) = 1e-3*( AC_ACT_BASAL+AC_ACT_GSA+AC_ACT_FSK-PDE_ACT );
% end cAMP module

% PKA module
PKI = p(32)*p(36)/(p(36)+y(17)+y(18));
A2RC_I = (y(17)/p(35))*y(17)*(1+PKI/p(36));
A2R_I = y(17)*(1+PKI/p(36));
A2RC_II = (y(18)/p(35))*y(18)*(1+PKI/p(36));
A2R_II = y(18)*(1+PKI/p(36));
ARC_I = (p(33)/y(16))*A2RC_I;
ARC_II = (p(33)/y(16))*A2RC_II;
ydot(16) = y(15)-(ARC_I+2*A2RC_I+2*A2R_I)-(ARC_II+2*A2RC_II+2*A2R_II)-y(16);
PKAtemp = p(33)*p(34)/p(35)+p(33)*y(16)/p(35)+y(16)^2/p(35);
ydot(17) = 2*p(30)*y(16)^2-y(17)*(1+PKI/p(36))*(PKAtemp*y(17)+y(16)^2);
ydot(18) = 2*p(31)*y(16)^2-y(18)*(1+PKI/p(36))*(PKAtemp*y(18)+y(16)^2);
% end PKA module

% PLB module
PLB = p(38)-y(19);
PLB_PHOSPH = p(41)*y(17)*PLB/(p(42)+PLB);
PLB_DEPHOSPH = p(43)*y(22)*y(19)/(p(44)+y(19));
ydot(19) = 1e-3*( PLB_PHOSPH-PLB_DEPHOSPH );
 
Inhib1 = p(40)-y(20);
Inhib1p_PP1 = y(21)*y(22)/p(49);
Inhib1_PHOSPH = p(45)*y(17)*Inhib1/(p(46)+Inhib1); 
Inhib1_DEPHOSPH = p(47)*y(20)/(p(48)+y(20));
ydot(20) = 1e-3*( Inhib1_PHOSPH-Inhib1_DEPHOSPH );
ydot(21) = y(20)-Inhib1p_PP1-y(21);
ydot(22) = p(39)-Inhib1p_PP1-y(22);

fracPLBp = y(19)/p(38);
fracPLB = PLB/p(38);
fracPLBo = 0.9571;
% end PLB module

% LCC module
PKAClcc = (p(51)/p(31))*y(18);
LCCa = p(50)-y(23);
LCCa_PHOSPH = p(37)*p(54)*PKAClcc*LCCa/(p(55) + p(37)*LCCa);
LCCa_DEPHOSPH = p(37)*p(58)*p(53)*y(23)/(p(59)+p(37)*y(23));
ydot(23) = 1e-3*( LCCa_PHOSPH - LCCa_DEPHOSPH );
fracLCCap = y(23)/p(50);
fracLCCapo = 0.1733;
 
LCCb = p(50)-y(24);
LCCb_PHOSPH = p(37)*p(54)*PKAClcc*LCCb/(p(55)+p(37)*LCCb);   
LCCb_DEPHOSPH = p(37)*p(56)*p(52)*y(24)/(p(57)+p(37)*y(24));
ydot(24) = 1e-3*( LCCb_PHOSPH-LCCb_DEPHOSPH );
fracLCCbp = y(24)/p(50);
fracLCCbpo = 0.1994;
% end LCC module

% TnI module
TnI = p(70)-y(25);
TnIPHOSPH = p(72)*y(17)*TnI/(p(73)+TnI);
TnIDEPHOSPH = p(74)*p(71)*y(25)/(p(75)+y(25));
ydot(25) = 1e-3*( TnIPHOSPH-TnIDEPHOSPH );
fracTnIp = y(25)/p(70);
fracTnIpo = 0.0358;
%end TnI module

% -------- END SIGNALING MODEL ---------

if t>T_array(Counter)
    Counter = Counter+1;
    T_array(Counter) = t;
end

%disp(Counter);

%T_array(Counter) = t;
Var_matrix(Counter,1) = Fsk_AC;
Var_matrix(Counter,2) = AC;
Var_matrix(Counter,3) = Fsk;
Var_matrix(Counter,4) = Gsa_gtp_AC;
Var_matrix(Counter,5) = y(1);
