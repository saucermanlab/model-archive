function [tfinal, yfinal, tfinal2, yfinal2] = computeSignaling_6var(params, y0_signaling, tspan)
global p;
global Counter T_array T_array2 Var_matrix Vars Vars2;


% Load parameters from data file (runs a script)
eval(params);
% External parameter- Ligand input
p(1) = 1; % Ltotmax

% Initial conditions
y0 = load(y0_signaling);
%y0 = y0_signaling;


% Mass matrix
M = eye(size(y0,1));

% Simulation parameters
options = odeset('Mass',M,'RelTol',1e-5,'MaxStep',1e3*0.5,'Stats','on'); 

%Calculate for ligand application
[t,y] = ode15s(@signalingODEfile_6var,tspan,y0,options);

%Calculate for ligand absence
p(1) = 0; % Ltotmax
% Initial conditions
y0n = y(end,:);  %ICs for removal of signal

Vars=Var_matrix(1:end-3,:);
Counter=1;

[t2,y2] = ode15s(@signalingODEfile_6var,tspan,y0n,options);  
tfinal = t;
yfinal = y;
tfinal2 = t2;
yfinal2 = y2;

T_array2=T_array(1:end-3);
Vars2=Var_matrix(1:end-3,:);
T_array=T_array(1:length(Vars));


