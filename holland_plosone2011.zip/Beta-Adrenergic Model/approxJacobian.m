function Jac = approxJacobian(ODEfunc,epsilon,t0,y0,p)
% approxJacobian.m
% Approximates Jacobian of ODEfunc by finite differencing. ODEfunc should
% be of the form ODEfunc(t,y,p)
%
% Author: Jeff Saucerman <jsaucerman@virginia.edu>
% Date: 8/14/2008
%
% Parameters
% ODEfunc: handle of ODE function to be called
% epsilon: % change in y to be tested (suggestion sqrt(eps))
% t0: time at which ODEfunc is evaluated (important for nonautonomous systems, otherwise set to 0)
% y0: value of y at which ODEfunc is evaluated
% p: parameter vector called by ODEfunc
%
% Example:
% >>y0 = [0;0;0];
% >>p = ones(1,11);
% >>Jac = approxJacobian(@toymodelODEfunc,sqrt(eps),0,[0;0;0],p);
% >>eigenValues = eig(Jac);     % used to evaluate stability of equilibrium point
% Suggestion for epsilon: sqrt(eps)

dy = epsilon*y0;                % amount to perturb y, using relative epsilon
numVars = length(y0);
Jac = zeros(numVars);           % initializes Jacobian matrix
func0 = ODEfunc(t0,y0,p);       % evaluate ODEfunc at baseline

for i=1:numVars
    y1 = y0;
    dy = max(epsilon*y0(i),sqrt(eps));  % minimum value of 1.49e-8
    y1(i) = y0(i) + dy;                 % perturb y(i) by dy
    func1 = ODEfunc(t0,y1,p);           % evaluate ODEfunc with perturbed y
    Jac(:,i) = (func1-func0)/dy;        % update Jacobian matrix
end

% Plot Jacobian matrix
figure();
colormap(redgreencmap)
imagesc(Jac)
colorbar
title('Jacobian Matrix')
yNames = {'y1','y2','y3','y4','y5','y6','y7','y8','y9','y10','y11','y12','y13','y14','y15','y16','y17','y18','y19','y20','y21','y22','y23','y24','y25'};
set(gca,'YTick',1:1:numVars,'YTickLabel',yNames)
