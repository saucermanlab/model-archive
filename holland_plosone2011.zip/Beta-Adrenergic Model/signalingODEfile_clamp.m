function ydot = mouse_signalingODEfile_clamp(t,y)
% Modified 25-variable model so that one variable may be held constant

global p;
ydot = zeros(size(y));

z=y;
y(p(end-1))=p(end);

% -------- SIGNALING MODEL -----------
% b-AR module
LR = y(1)*y(2)/p(4);
LRG = LR*y(3)/p(5);
RG = y(2)*y(3)/p(6);
BARKDESENS = p(7)*(LR+LRG);
BARKRESENS = p(8)*y(5);
PKADESENS = p(9)*y(17)*y(4);  
PKARESENS = p(10)*y(6);
GACT = p(11)*(RG+LRG);
HYD = p(12)*y(7);
REASSOC = p(13)*y(8)*y(9);
ydot(1) = p(1)-LR-LRG-y(1);
ydot(2) = y(4)-LR-LRG-RG-z(2);
ydot(3) = p(3)-LRG-RG-y(3);
ydot(4) = p(2)-y(4)-y(5)-y(6);
%ydot(4) = 1e-3*( (BARKRESENS-BARKDESENS)+(PKARESENS-PKADESENS) );
ydot(5) = 1e-3*( BARKDESENS-BARKRESENS );
ydot(6) = 1e-3*( PKADESENS-PKARESENS );
%ydot(7) = y(9)-y(8)-y(7) + 0.4700e-005;
ydot(7) = 1e-3*( GACT-HYD);
ydot(8) = 1e-3*( HYD-REASSOC );
ydot(9) = 1e-3*( GACT-REASSOC );
% end b-AR module

%cAMP module
if p(end-1)==10 || p(end-1)==11 || p(end-1)==12 ||p(end-1)==13 || p(end-1)==14
    y(p(end-1))=z(p(end-1));
    disp('yup');
end
Gsa_gtp_AC = y(10)*y(12)/p(27);
Fsk_AC = y(11)*y(12)/p(28);
AC_ACT_BASAL = p(19)*y(12)*p(15)/(p(23)+p(15))	 ;   
AC_ACT_GSA = p(20)*Gsa_gtp_AC*p(15)/(p(24)+p(15));
AC_ACT_FSK = p(21)*Fsk_AC*p(15)/(p(25)+p(15));	   
PDE_ACT = p(22)*y(13)*y(16)/(p(26)+y(16));	
PDE_IBMX = y(13)*y(14)/p(29);
ydot(10) = y(7)-Gsa_gtp_AC-y(10);
ydot(11) = p(18)-Fsk_AC-y(11);
ydot(12) = p(14)-Gsa_gtp_AC-y(12);  % note: assumes Fsk = 0.  Change Gsa_gtp_AC to Fsk_AC for Forskolin.
ydot(13) = p(16)-PDE_IBMX-y(13);
ydot(14) = p(17)-PDE_IBMX-y(14);
ydot(15) = 1e-3*( AC_ACT_BASAL+AC_ACT_GSA+AC_ACT_FSK-PDE_ACT );

y(p(end-1))=p(end);

%ydot(26) = 1e-3*p(19)*p(15)/(p(23)+p(15));%p(19)*y(12)*p(15)/(p(23)+p(15)); %AC_ACT_BASAL
%ydot(27) = 1e-3*p(20)*p(15)/(p(24)+p(15));%p(20)*Gsa_gtp_AC*p(15)/(p(24)+p(15)); %AC_ACT_GSA
%ydot(28) = 1e-3*p(22)*y(16)/(p(26)+y(16));%p(22)*y(13)*y(16)/(p(26)+y(16));	 %PDE_ACT


% end cAMP module

%PKA module
if p(end-1)==16 || p(end-1)==17 || p(end-1)==18
    y(p(end-1))=z(p(end-1));
end
    
% PKI = p(32)*p(36)/(p(36)+y(17)+y(18));
% A2RC_I = (y(17)/p(35))*y(17)*(1+PKI/p(36));
% A2R_I = y(17)*(1+PKI/p(36));
% A2RC_II = (y(18)/p(35))*y(18)*(1+PKI/p(36));
% A2R_II = y(18)*(1+PKI/p(36));
% ARC_I = (p(33)/y(16))*A2RC_I;
% ARC_II = (p(33)/y(16))*A2RC_II;
PKI = p(32)*p(36)/(p(36)+y(17)+y(18));
A2RC_I = (y(17)/p(35))*y(17)*(1+PKI/p(36));
A2R_I = y(17)*(1+PKI/p(36));
A2RC_II = (y(18)/p(35))*y(18)*(1+PKI/p(36));
A2R_II = y(18)*(1+PKI/p(36));
ARC_I = (p(33)/y(16))*A2RC_I;
ARC_II = (p(33)/y(16))*A2RC_II;
ydot(16) = y(15)-(ARC_I+2*A2RC_I+2*A2R_I)-(ARC_II+2*A2RC_II+2*A2R_II)-y(16);
PKAtemp = p(33)*p(34)/p(35)+p(33)*y(16)/p(35)+y(16)^2/p(35);
ydot(17) = 2*p(30)*y(16)^2-y(17)*(1+PKI/p(36))*(PKAtemp*y(17)+y(16)^2);
ydot(18) = 2*p(31)*y(16)^2-y(18)*(1+PKI/p(36))*(PKAtemp*y(18)+y(16)^2);
% PKAtemp = p(33)*p(34)/p(35)+p(33)*p(end)/p(35)+p(end)^2/p(35);
% ydot(17) = 2*p(30)*p(end)^2-y(17)*(1+PKI/p(36))*(PKAtemp*y(17)+p(end)^2);
% ydot(18) = 2*p(31)*p(end)^2-y(18)*(1+PKI/p(36))*(PKAtemp*y(18)+p(end)^2);
% end PKA module

y(p(end-1))=p(end);

% PLB module
PLB = p(38)-y(19);
PLB_PHOSPH = p(41)*y(17)*PLB/(p(42)+PLB);
PLB_DEPHOSPH = p(43)*y(22)*y(19)/(p(44)+y(19));
ydot(19) = 1e-3*( PLB_PHOSPH-PLB_DEPHOSPH );

if p(end-1)==22
    y(p(end-1))=z(p(end-1));
end
Inhib1 = p(40)-y(20);
Inhib1p_PP1 = y(21)*y(22)/p(49);
Inhib1_PHOSPH = p(45)*y(17)*Inhib1/(p(46)+Inhib1); 
Inhib1_DEPHOSPH = p(47)*y(20)/(p(48)+y(20));
ydot(20) = 1e-3*( Inhib1_PHOSPH-Inhib1_DEPHOSPH );
if p(end-1)==21
    ydot(21) = y(20)-z(21)*y(22)/p(49)-z(21);
else
    ydot(21) = y(20)-Inhib1p_PP1-y(21);
end
%y(p(end-1))=p(end);
ydot(22) = p(39)-Inhib1p_PP1-y(22);

fracPLBp = y(19)/p(38);
fracPLB = PLB/p(38);
fracPLBo = 0.9571;
% end PLB module

y(p(end-1))=p(end);

% LCC module
PKAClcc = (p(51)/p(31))*y(18);
LCCa = p(50)-y(23);
LCCa_PHOSPH = p(37)*p(54)*PKAClcc*LCCa/(p(55) + p(37)*LCCa);
LCCa_DEPHOSPH = p(37)*p(58)*p(53)*y(23)/(p(59)+p(37)*y(23));
ydot(23) = 1e-3*( LCCa_PHOSPH - LCCa_DEPHOSPH );
fracLCCap = y(23)/p(50);
fracLCCapo = 0.1733;
 
LCCb = p(50)-y(24);
LCCb_PHOSPH = p(37)*p(54)*PKAClcc*LCCb/(p(55)+p(37)*LCCb);   
LCCb_DEPHOSPH = p(37)*p(56)*p(52)*y(24)/(p(57)+p(37)*y(24));
ydot(24) = 1e-3*( LCCb_PHOSPH-LCCb_DEPHOSPH );
fracLCCbp = y(24)/p(50);
fracLCCbpo = 0.1994;
% end LCC module

% TnI module
TnI = p(70)-y(25);
TnIPHOSPH = p(72)*y(17)*TnI/(p(73)+TnI);
TnIDEPHOSPH = p(74)*p(71)*y(25)/(p(75)+y(25));
ydot(25) = 1e-3*( TnIPHOSPH-TnIDEPHOSPH );
fracTnIp = y(25)/p(70);
fracTnIpo = 0.0358;
% end TnI module
% -------- END SIGNALING MODEL ---------

% flcc = p(89)*(0.375*fracLCCap/fracLCCapo+0.625); % PHOSPHOREGULATION
% favail = 0.5*(0.4*fracLCCbp/fracLCCbpo+0.60);   % PHOSPHOREGULATION
% Km_up = p(112)*(2/3*fracPLB/fracPLBo+1/3);      % PHOSPHOREGULATION
% kmtrpn = p(126)*(1.45-0.45*(1-fracTnIp)/(1-fracTnIpo));
% btrpn = p(123)*kmtrpn/(kmtrpn+y(44))^2;