% Parameters
% ----- Signaling model parameters -------
% b-AR/Gs module
global p;
p(1) = 1.0;     % Ltotmax   [uM]
p(2) = 0.0132;  % sumb1AR   [uM]
p(3) = 3.83;    % Gstot     [uM]
p(4) = 0.285;   % Kl        [uM]
p(5) = 0.062;   % Kr        [uM]
p(6) = 33.0;    % Kc        [uM]
p(7) = 1.1e-3;  % k_barkp   [1/sec]
p(8) = 2.2e-3;  % k_barkm   [1/sec]
p(9) = 3.6e-3;  % k_pkap    [1/sec/uM]
p(10) = 2.2e-3; % k_pkam    [1/sec]
p(11) = 16.0;   % k_gact    [1/sec]
p(12) = 0.8;    % k_hyd     [1/sec]
p(13) = 1.21e3; % k_reassoc [1/sec/uM]
% cAMP module
p(14) = 49.7e-3;% AC_tot    [uM]
p(15) = 5.0e3;  % ATP       [uM]
p(16) = 38.9e-3;% PDEtot    [uM]
p(17) = 0.0;    % IBMXtot   [uM]
p(18) = 0.0;    % Fsktot    [uM] (10 uM when used)
p(19) = 0.2;    % k_ac_basal[1/sec]
p(20) = 8.5;    % k_ac_gsa  [1/sec]
p(21) = 7.3;    % k_ac_fsk  [1/sec]
p(22) = 5.0;    % k_pde     [1/sec]
p(23) = 1.03e3; % Km_basal  [uM]
p(24) = 315.0;  % Km_gsa    [uM]
p(25) = 860.0;  % Km_fsk    [uM]
p(26) = 1.3;    % Km_pde    [uM]
p(27) = 0.4;    % Kgsa      [uM]
p(28) = 44.0;   % Kfsk      [uM]
p(29) = 30.0;   % Ki_ibmx   [uM]
% PKA module
p(30) = 0.59;   % PKAItot   [uM]
p(31) = 0.059;  % PKAIItot  [uM]
p(32) = 0.18;   % PKItot    [uM]
p(33) = 9.14;   % Ka        [uM]
p(34) = 1.64;   % Kb        [uM]
p(35) = 4.375;  % Kd        [uM]
p(36) = 0.2e-3; % Ki_pki    [uM]
% PLB module
p(37) = 10;     % epsilon   [none]
p(38) = 106;    % PLBtot    [uM]
p(39) = 0.89;   % PP1tot    [uM]
p(40) = 0.3;    % Inhib1tot [uM]
p(41) = 54;     % k_pka_plb     [1/sec]
p(42) = 21;     % Km_pka_plb    [uM]
p(43) = 8.5;    % k_pp1_plb     [1/sec]
p(44) = 7.0;    % Km_pp1_plb    [uM]
p(45) = 60;     % k_pka_i1      [1/sec]
p(46) = 1.0;    % Km_pka_i1     [uM]
p(47) = 14.0;   % Vmax_pp2a_i1  [uM/sec]
p(48) = 1.0;    % Km_pp2a_i1    [uM]
p(49) = 1.0e-3; % Ki_inhib1     [uM]
% LCC module
p(50) = 0.025;  % LCCtot        [uM]
p(51) = 0.025;  % PKAIIlcctot   [uM]
p(52) = 0.025;  % PP1lcctot     [uM]
p(53) = 0.025;  % PP2Alcctot    [uM]
p(54) = 54;     % k_pka_lcc     [1/sec]
p(55) = 21;     % Km_pka_lcc    [uM]
p(56) = 8.52;   % k_pp1_lcc     [1/sec]
p(57) = 3;      % Km_pp1_lcc    [uM]
p(58) = 10.1;   % k_pp2a_lcc    [1/sec]
p(59) = 3;      % Km_pp2a_lcc   [uM]
% RyR module
p(60) = 0.135;  % RyRtot        [uM]
p(61) = 0.034;  % PKAIIryrtot   [uM]
p(62) = 0.034;  % PP1ryr        [uM]
p(63) = 0.034;  % PP2Aryr       [uM]
p(64) = 54;     % kcat_pka_ryr  [1/sec]
p(65) = 21;     % Km_pka_ryr    [uM]
p(66) = 8.52;   % kcat_pp1_ryr  [1/sec]
p(67) = 7;      % Km_pp1_ryr    [uM]
p(68) = 10.1;   % kcat_pp2a_ryr [1/sec]
p(69) = 4.1;    % Km_pp2a_ryr   [uM]
% TnI module
p(70) = 70;     % TnItot        [uM]
p(71) = 0.67;   % PP2Atni       [uM]
p(72) = 54;     % kcat_pka_tni  [1/sec]
p(73) = 21;     % Km_pka_tni    [uM]
p(74) = 10.1;   % kcat_pp2a_tni [1/sec]
p(75) = 4.1;    % Km_pp2a_tni   [uM]

%Reduced Model extra parameters
p(76)=0.80425;  %PKA1max        [uM]
p(77)=-0.02605; %PKA1min/offset [uM]
p(78)=1.6368;   %n_pka1
p(79)=3.2068;   %Km_pka1        [uM]
p(80)=0.095375;  %PKA2max        [uM]
p(81)=-0.006425; %PKA2min/offset[uM]
p(82)=1.8235;   %n_pka2
p(83)=1.7547;   %Km_pka2        [uM]

p(84)=0.2715;   %a_cAMP         [1/(m_cAMP-1) uM]
p(85)=1.48854;  %m_cAMP
p(86)=0.9187242;%k_Gsagtp

p(87)=1.1113;   %n_inhibptot
p(88)=0.23345;  %Km_inhibptot   [uM]
p(89)=5.0717e-4;%Inhib1pmax     [uM]
p(90)=1.1105;   %n_inhib1p 
p(91)=0.3370;   %Km_inhib1p     [uM]

p(92)=0.0746;   %Km_lccap       [uM]
p(93)=0.063;    %Km_lccbp       [uM]

p(94)=3;        %n_plbp
p(95)=0.1555;   %Km_plbp        [uM]
p(96)=3.1770;   %n_tnip
p(97)=0.1891;    %Km_tnip        [uM]


