% Normalizes two timecourses (y and y2) which represent ligand application and absence.

function [up down] = normalize_01(y, y2)

n = size(y,2);

minValt = zeros(size(y,2));
minValt2 = zeros(size(y,2));
maxValt = zeros(size(y,2));
maxValt2 = zeros(size(y,2));

for i=1:n
    minValt(i) = min(y(:,i));
    minValt2(i) = min(y2(:,i));
    maxValt(i) = max(y(:,i));
    maxValt2(i)=max(y2(:,i));
    if  maxValt(i) > maxValt2(i)
        maxVal(i) = maxValt(i);
    else
        maxVal(i) = maxValt2(i);
    end
    if  minValt(i) < minValt2(i)
        minVal(i) = minValt(i);
    else
        minVal(i) = minValt2(i);
    end
    diff(i) = maxVal(i) - minVal(i);
    ytemp(:,i) = (y(:,i)-minVal(i))./diff(i);
    y2temp(:,i) = (y2(:,i)-minVal(i))./diff(i);
end
up=ytemp;
down=y2temp;