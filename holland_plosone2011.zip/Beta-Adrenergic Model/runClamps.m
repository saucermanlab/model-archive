%Script to collect steady-state dose response for various concentration
%clamps

%Written by David Holland, May 2010

parameters_script = 'mouse_signaling_parameters';     %name of script to load parameters
initial_conditions = 'mouse_signaling_ICs.dat'; %file name with initial conditions

%Choose range of clamps
%clamps=linspace(0,0.75,40);
clamps=logspace(-3,3,100);
ym1=zeros(size(clamps));
ym2=zeros(size(clamps));
ym1_2=ym1;
ym2_2=ym2;

%Choose variable to be clamped
clamped_var=20;

%Choose two variables to measure the dose response of
measured_var=21;
measured_var2=25;

%Run clamps
for i=1:length(clamps)
    [t3,y3,t4,y4] =  mouse_computeSignaling3(parameters_script, initial_conditions, [0 4e5], clamped_var, clamps(i));
    ym1(i)=y3(end,measured_var);
    ym2(i)=y3(end,measured_var2);
    %ym1_2(i)=y4(end,measured_var);
    %ym2_2(i)=y4(end,measured_var);
    i
end

%Attempt difference axis types (plot, semilogx, semilogy, or loglog) for
%each set of data to see which curve is appropriate.