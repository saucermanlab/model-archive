function [tfinal, yfinal, tfinal2, yfinal2] = computeSignaling_25var(params, y0_signaling, tspan)
global p;
global algVarsMatrix;
global Counter T_array Var_matrix;


% Load parameters from data file (runs a script)
eval(params);
% External parameter- input Ligand
p(1) = 1.0; % Ltotmax

% Initial conditions
y0 = load(y0_signaling);


% Mass matrix
M = eye(size(y0,1));
algVars = [1:3,10:14,16:18,21:22];  % Indices of algebraic state variables
for i=1:size(algVars,2), M(algVars(i),algVars(i)) = 0; end

% Simulation parameters
options = odeset('Mass',M,'RelTol',1e-5,'MaxStep',1e3*0.5,'Stats','on'); 

% Simulate Ligand Application
[t,y] = ode15s(@signalingODEfile_25var,tspan,y0,options);

% Simulate Ligand Absence
p(1) = 0; % Ltotmax
% Initial conditions
y0n = y(end,:);  %ICs for removal of signal
y0n(1) = 0;  %removal of signal
[t2,y2] = ode15s(@signalingODEfile_25var,tspan,y0n,options);  
tfinal = t;
yfinal = y;
tfinal2 = t2;
yfinal2 = y2;


