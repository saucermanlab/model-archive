%%
%Nicholas Krainak
%Saucerman Lab
%Segmentation area method for creating global phase portrait

%Modified by David Holland, 5-20-2010
%Inputs: down, up, 1, names

%given y1 (m x n), y2 (p x n)
function y = globalPhasePortrait(y1, y2, fig, names, indvplot)
if nargin ==4
    indvplot=[];
end

values = [2:10 12 15:25 0];
%values=[7 10 15 17 19 23 25 0];

fntsize=9;

[r1, c1] = size(y1);
[r2] = size(y2,1);
areaArr = zeros(length(values));


y = zeros(r1+r2+1,c1);
y(1:r1,:) = y1;
y((1+r1):(r1+r2),:) = y2;
y(r1+r2+1,:) = y1(1,:);


sect=length(values)-1;

fig1 = figure(fig); 
for k = 1:length(values)-1;
   h = subplot(sect,sect,k);
   set(h,'Visible','off');
   if values(k+1)~=0
        text(0.5,0.5,names(values(k+1),:),'HorizontalAlignment','left','Rotation',45,'Fontsize',fntsize);
   end
   if k~=length(values)-1
        h = subplot(sect,sect,(k+1)*sect);
        set(h,'Visible','off');
        text(0.5,0.5,names(values(k),:),'HorizontalAlignment','left','Fontsize',fntsize);
   end
end

for i=1:size(values,2)-1
    set(fig1,'color',[1 1 1]);
    for k=1:size(values,2)-1
        if(i < k)
            subplot(sect,sect,sect*(i)+k-1);
            plot(y(:,values(k)),y(:,values(i)),':k','LineWidth',1)%Drug on
            hold on
            plot(y1(:,values(k)), y1(:,values(i)),'Color',[0.5 0.5 0.5],'LineWidth',1);%Drug Off
            axis([0 1 0 1]);
            axis tight;
            axis off;
            %compute area
            oppDir = 0;
            counter = 1;
            clear dx;
            dx = zeros(size(y,1),1);
            dx(1) =  y(2,values(i)) - y(1,values(i));
            curVal = y(2,values(i))>=y(1,values(i));
            for m=2:size(y,1)-1
                dx(m) = y(m+1,values(i))-y(m,values(i));
                if dx(m)>=0 ~= curVal
                    curVal = 1-curVal; %0->1; 1->0;
                    oppDir(counter) = m;
                    counter = counter+1;
                end
            end
            oppDir(counter) = size(y,1);
          
            cumArea = 0;
            for m=1:size(oppDir,2)
                if m == 1
                    start = 1;
                else
                    start = oppDir(m-1);
                end
               % start
               % oppDir(m)
                for xvar = start:oppDir(m)-1
                   avgInter1 = (y(xvar+1,values(k)) + y(xvar,values(k)))/2;
                %   dx(xvar)
                %   avgInter1
                   dxdy = abs(dx(xvar)*avgInter1);
                   if mod(m,2)
                       cumArea = cumArea + dxdy;
                   else
                       cumArea = cumArea - dxdy;
                   end     
                end
            end
        abs(cumArea);
        areaArr(values(i),values(k)) = abs(cumArea);
        set(h,'Visible','off');
        if areaArr(values(i),values(k)) <= 0.05
            %title(num2str(abs(cumArea),'%3.2f'),'FontWeight','bold','Fontsize',fntsize-2);
            text(0.1,1.15,num2str(abs(cumArea),'%3.2f'),'FontWeight','bold','Fontsize',fntsize-2);
        else
            %title(num2str(abs(cumArea),'%3.2f'),'Fontsize',fntsize-2);
            text(0.1,1.15,num2str(abs(cumArea),'%3.2f'),'Fontsize',fntsize-2);
        end
        end
        k
    end
    i
end

for i=1:2:length(indvplot)
    k = i+1;
    fig = fig+1;
    figure(fig);
    plot(y(:,indvplot(k)),y(:,indvplot(i)),'blue',y1(:,indvplot(k)), y1(:,indvplot(i)),'red');
    axis([0 1 0 1]);
    axis tight;
    title(strcat(num2str(indvplot(k)), ' vs ', num2str(indvplot(i))));
    text(.1,.9,strcat('area = ',num2str(areaArr(indvplot(k),indvplot(i)))),'HorizontalAlignment','left')
    legend('Drug Application','Drug Withdrawal','Location','NorthEastOutside');
end

