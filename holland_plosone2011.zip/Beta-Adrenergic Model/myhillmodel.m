% Calculates outputs for a Hill-function based on inputs (x) and parameters (beta)

function yhat=myhillmodel(beta, x)
bottom=beta(1);
top=beta(2);
n=beta(3); %Hill coefficient
K=beta(4); %The halfpoint
yhat=zeros(size(x));
for i=1:length(x);
    yhat(i)=(top-bottom)*x(i)^n/(K^n+x(i)^n) +bottom;
end
%semilogx(x,yhat,'r');