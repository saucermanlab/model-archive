%%
%Compute_4var.m
%Will run a simulation of the reduced 4-variable model
clear p;
global p; 
global Counter T_array T_array2 Var_matrix Vars Vars2;

Counter=1;
T_array=zeros(1,800);
Var_matrix=zeros(800,25);

tspan = [0 4e5];

tic
parameters_script = 'signaling_parameters_reduced';     %name of script to load parameters
initial_conditions = 'signaling_ICs_reduced.dat'; %file name with initial conditions
[t,y,t2,y2] =  computeSignaling_4var(parameters_script, initial_conditions, tspan);
toc
