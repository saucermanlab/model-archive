function ydot = signalingODEfile_4var(t,y,Ltotmax)

global p;
global Counter T_array Var_matrix
ydot = zeros(size(y));

%y(1)=B1ARd, formerly y(5)
%y(2)=B1ARp, formerly y(6)
%y(3)=Gsagtptot, formerly y(7)
%y(4)=cAMPtot, formerly y(15)

% -------- SIGNALING MODEL -----------
%PKA module
PKACi=(p(76)-p(77))*y(4)^p(78) / (y(4)^p(78) + p(79)^p(78))+p(77); %formerly y(17)
PKACii=(p(80)-p(81))*y(4)^p(82) / (y(4)^p(82)+p(83)^p(82))+p(81); %formerly y(18)


% b-AR module
Rtot=p(2)-y(1)-y(2); % formerly y(4)
LR=Rtot*p(1)/(p(4)+p(1)+p(1)*p(3)/.062+p(4)*p(3)/p(6));
LRG=Rtot*p(1)*p(3)/(p(5)*p(4)+p(1)*p(5)+p(1)*p(3)+p(3)*p(4)*p(5)/p(6));
RG=Rtot*p(3)/(p(6)+p(6)*p(1)/p(4)+p(1)*p(3)*p(6)/(p(4)*p(5))+p(3));
Rfree=Rtot-LR-LRG-RG;
BARKDESENS = p(7)*(LR+LRG);
BARKRESENS = p(8)*y(1);
PKADESENS = p(9)*PKACi*Rtot;  
PKARESENS = p(10)*y(2);
GACT = p(11)*(RG+LRG);
HYD = p(12)*y(3);
ydot(1) = 1e-3*( BARKDESENS-BARKRESENS );
ydot(2) = 1e-3*( PKADESENS-PKARESENS );
ydot(3) = 1e-3*( GACT-HYD);
% end b-AR module

% cAMP module
cAMPfree = p(84)*y(4)^p(85); %formerly y(16)

Gsa_gtp=p(86)*y(3);%formerly y(10)
Fsk=p(18); %formerly y(11);

Gsa_gtp_AC = p(14)*Gsa_gtp/(p(27)+Gsa_gtp+p(27)*Fsk/p(28));
Fsk_AC = p(14)*Fsk/(p(28)+Fsk+Gsa_gtp*p(28)/p(27));
AC=p(14)-Gsa_gtp_AC-Fsk_AC; %Formerly y(12)

AC_ACT_BASAL = p(19)*AC*p(15)/(p(23)+p(15))	 ;   
AC_ACT_GSA = p(20)*Gsa_gtp_AC*p(15)/(p(24)+p(15));
AC_ACT_FSK = p(21)*Fsk_AC*p(15)/(p(25)+p(15));	
IBMX=p(17); %Formerly y(14)
PDE_IBMX=p(16)*IBMX/(p(29)+IBMX);
PDE = p(16)-PDE_IBMX; %formerly y(13)
PDE_ACT = p(22)*PDE*cAMPfree/(p(26)+cAMPfree);
ydot(4) = 1e-3*( AC_ACT_BASAL+AC_ACT_GSA+AC_ACT_FSK-PDE_ACT );

% end cAMP module

% PLB module
Inhib1ptot = p(40)*(PKACi^p(87))/(PKACi^p(87) + p(88)^p(87)); %Formerly y(20)
Inhib1p=p(89)*(PKACi^p(90))/(p(91)^p(90) + PKACi^p(90)); %Inhib1p formerly y(21)

PP1=p(39)*p(49)/(p(49)+Inhib1p);%formerly y(22)

PLBs=p(38)*PKACi^p(94) /(p(95)^p(94) + PKACi^p(94));%formerly y(19)
PLB = p(38)-PLBs;
PLB_PHOSPH = p(41)*PKACi*PLB/(p(42)+PLB);
PLB_DEPHOSPH = p(43)*PP1*PLBs/(p(44)+PLBs);
 
Inhib1p_PP1 = Inhib1ptot*PP1/p(49);

fracPLBp = PLBs/p(38);
fracPLB = PLB/p(38);
fracPLBo = 0.9571;
% end PLB module

% LCC module
%LCCap = .025*PKACii/(PKACii+0.0746);
LCCap = p(50)*PKACii/(PKACii+p(92));%formerly y(23)
LCCa=p(50)-LCCap;
fracLCCap = LCCap/p(50);
fracLCCapo = 0.1733;
 
%LCCbp=.025*PKACii/(.063+PKACii);
LCCbp=p(50)*PKACii/(PKACii+p(93)); %formerly y(24)
LCCb=p(50)-LCCbp;
fracLCCbp = LCCbp/p(50);
fracLCCbpo = 0.1994;
% end LCC module

% TnI module
TnIp=p(70)*PKACi^p(96) /(p(97)^p(96) + PKACi^p(96)); %Formerly y(25)
TnI = p(70)-TnIp;
TnIPHOSPH = p(72)*PKACi*TnI/(p(73)+TnI);
TnIDEPHOSPH = p(74)*p(71)*TnIp/(p(75)+TnIp);
fracTnIp = TnIp/p(70);
fracTnIpo = 0.0358;
% end TnI module

if t>T_array(Counter)
    Counter = Counter+1;
    T_array(Counter) = t;
end

Var_matrix(Counter,1) = p(1);
Var_matrix(Counter,2) = Rfree;
Var_matrix(Counter,3) = 3.83;
Var_matrix(Counter,4) = Rtot;
Var_matrix(Counter,5) = y(1);
Var_matrix(Counter,6) = y(2);
Var_matrix(Counter,7) = y(3);
Var_matrix(Counter,8) = 1;
Var_matrix(Counter,9) = 1;
Var_matrix(Counter,10) = Gsa_gtp;
Var_matrix(Counter,11) = Fsk;
Var_matrix(Counter,12) = AC;
Var_matrix(Counter,13) = 1;
Var_matrix(Counter,14) = 1;
Var_matrix(Counter,15) = y(4);
Var_matrix(Counter,16) = cAMPfree;
Var_matrix(Counter,17) = PKACi;
Var_matrix(Counter,18) = PKACii;
Var_matrix(Counter,19) = PLBs;
Var_matrix(Counter,20) = Inhib1ptot;
Var_matrix(Counter,21) = Inhib1p;
Var_matrix(Counter,22) = PP1;
Var_matrix(Counter,23) = LCCap;
Var_matrix(Counter,24) = LCCbp;
Var_matrix(Counter,25) = TnIp;
% -------- END SIGNALING MODEL ---------