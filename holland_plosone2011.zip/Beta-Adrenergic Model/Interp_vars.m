% Script for interpolating timecourse data so that percent error between timecourses for the original model and a reduced model can be calculated

load Values;

%Choose one
load simpvalues2;
%load supersimpvalues;

ti=linspace(0,4e5,850);
Varsi=interp1(T_array,Vars,ti);
t2i=linspace(0,4e5,850);
Vars2i=interp1(T_array2,Vars2,t2i);
yi=interp1(t,y,ti);
y2i=interp1(t2,y2,t2i);

abs_errors=zeros(1,25);
rel_errors=zeros(1,25);

abs_errors(1)=(sum(1-yi(:,1))+sum(0-y2i(:,1)))/1693;
rel_errors(1)=(sum((1-yi(:,1))./yi(:,1))+sum(0-y2i(:,1)))/1693;
abs_errors(3)=(sum(3.83-yi(:,3))+sum(3.83-y2i(:,3)))/1693;
rel_errors(3)=(sum((3.83-yi(:,3))./yi(:,3))+sum((3.83-y2i(:,3))./y2i(:,3)))/1693;

for i=[4 5 6 7 10 12 15 16 17 18 19 20 21 22 23 24 25]
    abs_errors(i)=(sum(abs(Varsi(:,i)-yi(:,i)))+sum(abs(Vars2i(:,i)-y2i(:,i))))/1693;
    rel_errors(i)=(sum(abs(Varsi(:,i)-yi(:,i))./yi(:,i))+sum(abs(Vars2i(:,i)-y2i(:,i))./y2i(:,i)))/1693;
end
abs_errors=abs_errors(find(abs_errors));
rel_errors=rel_errors(find(rel_errors));