function dy=clamp_Toy(t,y)

%A toy ODE model which "clamps" one variable by holding it constant

global Input clamped_var clamp
dy=zeros(size(y));

%Clamping code
y(clamped_var)=clamp;

%ODE code
k(1)=Input;
k(2)=1;
k(3)=10;
k(4)=1;

dy(1)=k(1)-k(2)*y(1);
dy(2)=k(2)*y(1)-k(3)*y(2);
dy(3)=k(3)*y(2)-k(4)*y(3);