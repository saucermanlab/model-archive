%Compute_Toy.m
%Runs the toy model, then graphs the hysteresis plots

global k

%Drug Application
Input=100;
k(1)=Input
k(2)=1;
k(3)=10;
k(3)=1;
tspan=[0 10];
y0=[0 0 0];
[t y]=ode15s(@myToyModel,tspan,y0);

%Drug Withdrawal
Input=0;
k(1)=Input;
y0n=y(end,:);
[t2 y2]=ode15s(@myToyModel,tspan,y0n);

%Normalize Data
[up down]=normalize_01(y,y2);

%Graph timecourses of A, B, and C
figure(1); hold on;
time=[t;t2+t(end)];
A=[y(:,1);y2(:,1)];
B=[y(:,2);y2(:,2)];
C=[y(:,3);y2(:,3)];
[AX H1 H2]=plotyy(time,A,time,B);
alf=plot(time,C,'r');
legend([H1,H2,alf],'A','B','C');
ylabel(AX(1),'Concentration of A or C');
ylabel(AX(2),'Concentration of B');
xlabel('Time (sec)');

%Graph normalized hysteresis plot for A vs B
figure(2); 
plot(up(:,1),up(:,2),'color',[0.5 0.5 0.5],'LineWidth',2);
hold on;
plot(down(:,1),down(:,2),'color',[0.3 0.3 0.3],'LineWidth',2);
xlabel('A')
ylabel('B')
plot([0:.05:1],[0:.05:1],'--','color','k','LineWidth',1.0);

%Graph normalized hysteresis plot for B vs C
figure(3);
plot(up(:,2),up(:,3),'color',[0.5 0.5 0.5],'LineWidth',2);
hold on;
plot(down(:,2),down(:,3),'color',[0.3 0.3 0.3],'LineWidth',2)
xlabel('B')
ylabel('C')
plot([0:.05:1],[0:.05:1],'--','color','k','LineWidth',1.0);

%Calculate hysteresis values
AreaAB=abs(trapz(up(:,1),up(:,2))+trapz(down(:,1),down(:,2)))
AreaBC=abs(trapz(up(:,2),up(:,3))+trapz(down(:,2),down(:,3)))