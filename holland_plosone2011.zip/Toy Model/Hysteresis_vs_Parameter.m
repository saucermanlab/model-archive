%Computes the toy model over a range of values for one of three parameters for the toy model (chosen in the code)
%Then calculates the hysteresis of the curve for each value
%Plots hysteresis versus parameter values

global k

AreaAB=zeros(1,201);
AreaBC=zeros(1,201);

for j=0:.1:20;
%Choose parameter
    k(2)=1;%1
    k(3)=j;%10
    k(4)=1;%1
Input=100;
k(1)=Input;
tspan=[0 10];
y0=[0 0 0];
[t y]=ode15s(@myToyModel,tspan,y0);

Input=0;
k(1)=Input;
y0n=y(end,:);
[t2 y2]=ode15s(@myToyModel,tspan,y0n);

[up down]=normalize_01(y,y2);

%Calculate hysteresis for each value of the parameter
m=round(j*10+1);
AreaAB(m)=abs(trapz(up(:,1),up(:,2))+trapz(down(:,1),down(:,2)));
AreaBC(m)=abs(trapz(up(:,2),up(:,3))+trapz(down(:,2),down(:,3)));
end

%Plot hysteresis versus parameter value
f=0:.1:20;
plot(f,AreaAB);
xlabel('k3');
ylabel('Area');
hold on;
plot(f,AreaBC,'red');
legend('AreaAB','AreaBC');