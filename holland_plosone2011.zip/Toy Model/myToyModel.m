function dy=myToyModel(t,y)

global k
dy=zeros(size(y));

dy(1)=k(1)-k(2)*y(1);
dy(2)=k(2)*y(1)-k(3)*y(2);
dy(3)=k(3)*y(2)-k(4)*y(3);