clamps=linspace(0,120,120);
clamped_var=2;
measured_var=3;
ym1=zeros(size(clamps));
for i=1:length(clamps)
    clamp=clamps(i);
    [u p]=ode15s(@clamp_Toy,[0 10],[0 0 0]);
    ym1(i)=p(end,measured_var);
    i
end