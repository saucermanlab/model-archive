function params = mousePARAMS()

% Parameters for mouse excitation-contraction coupling model
% params = mousePARAMS()
%
% Copyright 2011, Cardiac Systems Biology Lab, University of Virginia
%   JS: Jeff Saucerman  <jsaucerman@virginia.edu>
%   JY: Jason Yang      <jhyang@virginia.edu>
%
% Jason Yang
% 09/28/11

%% Global Parameters
% Physical Parameters
F = 96.5;                         % (C/mmol) Faraday's constant
T = 298;                          % (K) Temperature
R = 8.314;                        % (J/[mol K]) Universal gas constant
RT_over_F = R*T/F;

% Stimulus Current
Istimmax = -20;                   % (pA/pF) Stimulus amplitude
bcl = 1000;                       % (ms) Stimulus period

% Spatial Parameters
Cm = 1;                           % (uF/cm^2) Membrane capacitance
Acap = 1.387e-4;                  % (cm^2) Capacitive membrane area
Csa = Acap*Cm;                    % (uF) Cell surface acre capacitance

NCaRU = 50000;                    % Number Ca release units
Vmyo = 25.84e-6;                  % (uL) Cytosolic volume
VSR = Vmyo * 0.0538;              % (uL) Sarcoplasmic reticulum volume
VSS = Vmyo * 0.001 / NCaRU;       % (uL) Dyadic subspace volume

% Ion Concentrations
Ko = 5.4e3;                       % (uM) Extracellular potassium
Mgi = 0.5e3;                      % (uM) Intracellular magnesium
Cao = 1.8e3;                      % (uM) Extracellular calcium
Nao = 140e3;                      % (uM) Extracellular sodium

%% Signaling Parameters

% Drug Concentrations
ISO             = 0;              % (uM) isoproterenol concentration
FSK             = 0;              % (uM) forskolin concentration
IBMX            = 0;              % (uM) IBMX concentration

% b-AR/Gs module
b1ARtot         = 0.00528;        % (uM) total b1-AR protein
kf_LR           = 1;              % (1/[uM ms]) forward rate for ISO binding to b1AR
kr_LR           = 0.285;          % (1/ms) reverse rate for ISO binding to b1AR
kf_LRG          = 1;              % (1/[uM ms]) forward rate for ISO:b1AR association with Gs
kr_LRG          = 0.062;          % (1/ms) reverse rate for ISO:b1AR association with Gs
kf_RG           = 1;              % (1/[uM ms]) forward rate for b1AR association with Gs
kr_RG           = 33;             % (1/ms) reverse rate for b1AR association with Gs

Gstot           = 3.83;           % (uM) total Gs protein
k_G_act         = 16e-3;          % (1/ms) rate constant for Gs activation
k_G_hyd         = 0.8e-3;         % (1/ms) rate constant for G-protein hydrolysis
k_G_reassoc     = 1.21;           % (1/[uM us]) rate constant for G-protein reassociation

kf_bARK         = 1.1e-6;         % (1/[uM ms]) forward rate for b1AR phosphorylation by b1ARK
kr_bARK         = 2.2e-6;         % (1/ms) reverse rate for b1AR phosphorylation by b1ARK
kf_PKA          = 3.6e-6;         % (1/[uM ms]) forward rate for b1AR phosphorylation by PKA
kr_PKA          = 2.2e-6;         % (1/ms) reverse rate for b1AR phosphorylation by PKA

% AC module
ACtot           = 70.57e-3;       % (uM) total adenylyl cyclase
ATP             = 5e3;            % (uM) total ATP
k_AC_basal      = 0.2e-3;         % (1/ms) basal cAMP generation rate by AC
Km_AC_basal     = 1.03e3;         % (uM) basal AC affinity for ATP

Kd_AC_Gsa       = 0.4;            % (uM) Kd for AC association with Gsa
kf_AC_Gsa       = 1;              % (1/[uM ms]) forward rate for AC association with Gsa
kr_AC_Gsa       = Kd_AC_Gsa;      % (1/ms) reverse rate for AC association with Gsa

k_AC_Gsa        = 8.5e-3;         % (1/ms) basal cAMP generation rate by AC:Gsa
Km_AC_Gsa       = 315.0;          % (uM) AC:Gsa affinity for ATP

Kd_AC_FSK       = 44.0;           % (uM) Kd for FSK binding to AC
k_AC_FSK        = 7.3e-3;         % (1/ms) basal cAMP generation rate by AC:FSK
Km_AC_FSK       = 860.0;          % (uM) AC:FSK affinity for ATP

PDEtot          = 22.85e-3;       % (uM) total phosphodiesterase
k_cAMP_PDE      = 5e-3;           % (1/ms) cAMP hydrolysis rate by PDE
k_cAMP_PDEp     = 2*k_cAMP_PDE;   % (1/ms) cAMP hydrolysis rate by phosphorylated PDE
Km_PDE_cAMP     = 1.3;            % (uM) PDE affinity for cAMP

Kd_PDE_IBMX     = 30.0;           % (uM) Kd_R2cAMP_C for IBMX binding to PDE
k_PKA_PDE       = 7.5e-3;         % (1/ms) rate constant for PDE phosphorylation by type 1 PKA
k_PP_PDE        = 1.5e-3;         % (1/ms) rate constant for PDE dephosphorylation by phosphatases

% PKA module
PKAItot         = 0.59;           % (uM) total type 1 PKA
PKAIItot        = 0.059;          % (uM) total type 2 PKA
PKItot          = 0.18;           % (uM) total PKI
kf_RC_cAMP      = 1;              % (1/[uM ms]) Kd for PKA RC binding to cAMP
kf_RCcAMP_cAMP  = 1;              % (1/[uM ms]) Kd for PKA RC:cAMP binding to cAMP
kf_RcAMPcAMP_C  = 4.375;          % (1/[uM ms]) Kd for PKA R:cAMPcAMP binding to C
kf_PKA_PKI      = 1;              % (1/[uM ms]) Ki for PKA inhibition by PKI
kr_RC_cAMP      = 1.64;           % (1/ms) Kd for PKA RC binding to cAMP
kr_RCcAMP_cAMP  = 9.14;           % (1/ms) Kd for PKA RC:cAMP binding to cAMP
kr_RcAMPcAMP_C  = 1;              % (1/ms) Kd for PKA R:cAMPcAMP binding to C
kr_PKA_PKI      = 2e-4;           % (1/ms) Ki for PKA inhibition by PKI
epsilon         = 10;             % (-) AKAP-mediated scaling factor

% PP1 module
PP1tot          = 0.89;           % (uM) total phosphatase 1
I1tot           = 0.3;            % (uM) total inhibitor 1
k_PKA_I1        = 60e-3;          % (1/ms) rate constant for I-1 phosphorylation by type 1 PKA
Km_PKA_I1       = 1.0;            % (uM) Km for I-1 phosphorylation by type 1 PKA
Vmax_PP2A_I1    = 14.0e-3;        % (uM/ms) Vmax for I-1 dephosphorylation by PP2A
Km_PP2A_I1      = 1.0;          	% (uM) Km for I-1 dephosphorylation by PP2A

Ki_PP1_I1       = 1.0e-3;         % (uM) Ki for PP1 inhibition by I-1
kf_PP1_I1       = 1;              % (uM) Ki for PP1 inhibition by I-1
kr_PP1_I1       = Ki_PP1_I1;      % (uM) Ki for PP1 inhibition by I-1

% LCC module
LCCtot          = 0.025;          % (uM) total ISO-type Ca channels
PKACII_LCCtot   = 0.025;          % (uM) type 2 PKA available to phosphorylate LCC
PP1_LCC         = 0.025;          % (uM) PP1 available to dephosphorylate LCC
PP2A_LCC        = 0.025;          % (uM) PP2A available to dephosphorylate LCC
k_PKA_LCC       = 54e-3;          % (1/ms) rate constant for LCC phosphorylation by type 2 PKA
Km_PKA_LCC      = 21;             % (uM) Km for LCC phosphorylation by type 2 PKA
k_PP1_LCC       = 8.52e-3;        % (1/ms) rate constant for LCC dephosphorylation by PP1
Km_PP1_LCC      = 3;            	% (uM) Km for LCC dephosphorylation by PP1
k_PP2A_LCC      = 10.1e-3;      	% (1/ms) rate constant for LCC dephosphorylation by PP2A
Km_PP2A_LCC     = 3;              % (uM) Km for LCC dephosphorylation by PP2A

% PLB module
PLBtot          = 106;            % (uM) total phospholamban
k_PKA_PLB       = 54e-3;          % (1/ms) rate constant for PLB phosphorylation by type 1 PKA
Km_PKA_PLB      = 21;             % (uM) Km for PLB phosphorylation by type 1 PKA
k_PP1_PLB       = 8.5e-3;         % (1/ms) rate constant for PLB dephosphorylation by PP1
Km_PP1_PLB      = 7.0;            % (uM) Km for PLB dephosphorylation by PP1

% PLM module
PLMtot          = 48;             % (uM) total phospholemman
k_PKA_PLM       = 54e-3;          % (1/ms) rate constant for PLM phosphorylation by type 1 PKA
Km_PKA_PLM      = 21;             % (uM) Km for PLM phosphorylation by type 1 PKA
k_PP1_PLM       = 8.5e-3;         % (1/ms) rate constant for PLM dephosphorylation by PP1
Km_PP1_PLM      = 7;              % (uM) Km for PLM dephosphorylation by PP1

% TnI module
TnItot          = 70;             % (uM) total troponin I
PP2A_TnI        = 0.67;           % (uM) PP2A available to dephosphorylate TnI
k_PKA_TnI       = 54e-3;          % (1/ms) rate constant for TnI phosphorylation by type 1 PKA
Km_PKA_TnI      = 21;             % (uM) Km for TnI phosphorylation by type 1 PKA
k_PP2A_TnI      = 10.1e-3;        % (1/ms) rate constant for TnI dephosphorylation by PP2A
Km_PP2A_TnI     = 4.1;            % (uM) Km for TnI dephosphorylation by PP2A

%% Ca-Induced Ca Release Parameters

% Ca Buffering
CaMtot = 24;                      % (uM) total cytosolic calmodulin
TnCLtot = 70;                     % (uM) total low-affinity troponin sites
TnCHtot = 140;                    % (uM) total high-affinity troponin sites
Myosintot = 140;                  % (uM) total myosin
CSQNtot = 2.6e3;                  % (uM) total SR calsequestrin
CaSRbtot = 47;                    % (uM) total SR membrane for buffering
CaSLtot = 42;                     % (uM) total inner sarcolemma for buffering
CaSLhtot = 15;                    % (uM) total high-affinity sarcolemma for buffering
CaATPtot = 5000;                  % (uM) total ATP for buffering
CaPCrtot = 12000;                 % (uM) total phosphocreatine for buffering

kon_CaM = 45e-3;                  % (1/[uM ms]) Ca binding to calmodulin
koff_CaM = 238e-3;                % (1/ms) Ca binding to calmodulin
kon_TnCL = 32.7e-3;               % (1/[uM ms]) Ca binding to low-affinity troponin C
koff_TnCL = 19.6e-3;              % (1/ms) Ca binding to low-affinity troponin C
kon_TnCHCa = 2.37e-3;             % (1/[uM ms]) Ca binding to high-affinity troponin C
koff_TnCHCa = 0.032e-3;           % (1/ms) Ca binding to high-affinity troponin C
kon_TnCHMg = 0.003e-3;            % (1/[uM ms]) Mg binding to high-affinity troponin C
koff_TnCHMg = 3.33e-3;            % (1/ms) Mg binding to high-affinity troponin C
kon_MyosinCa = 13.8e-3;           % (1/[uM ms]) Ca binding to myosin
koff_MyosinCa = 0.46e-3;          % (1/ms) Ca binding to myosin
kon_MyosinMg = 0.0157e-3;         % (1/[uM ms]) Mg binding to myosin
koff_MyosinMg = 0.057e-3;         % (1/ms) Mg binding to myosin
kon_CaSRb = 60e-3;                % (1/[uM ms]) Ca binding to SR membrane
koff_CaSRb = 100e-3;              % (1/ms) Ca binding to SR membrane
kon_CaSL = 100e-3;                % (1/[uM ms]) Ca binding to sarcolemmal membrane
koff_CaSL = 1300e-3;              % (1/ms) Ca binding to sarcolemmal membrane
kon_CaSLh = 100e-3;               % (1/[uM ms]) Ca binding to high-affinity sarcolemma
koff_CaSLh = 30e-3;               % (1/ms) Ca binding to high-affinity sarcolemma
kon_CaATP = 100e-3;               % (1/[uM ms]) Ca binding to ATP
koff_CaATP = 20000e-3;            % (1/ms) Ca binding to ATP
kon_CaPCr = 100e-3;               % (1/[uM ms]) Ca binding to phosphocreatine
koff_CaPCr = 7107300e-3;          % (1/ms) Ca binding to phosphocreatine

Ki_MgATP = 83.3;                  % (uM) Mg binding to ATP
Km_CSQN = 650;                    % (uM) SR calsequestrin affinity

% Coupled Model Parameters
r_xfer = 220;                     % (1/ms) Ca flux rate from SS to cytosol
PCaL = 9.13e-13*3;                % (cm^3/s) Unitary LCC Ca permeability
JRyRmax = 3.92*8;                 % (1/ms) Unitary Ca flux rate through RyR

% LCC Rate Constants
fL = 0.85;                        % (1/ms) L-type Ca channel rate constant
aL = 12.88782;                    % (-) L-type Ca channel rate constant
bL = 32.1948;                     % (-) L-type Ca channel rate constant
gammaL = 4.170162e-3;             % (1/[uM ms]) L-type Ca channel rate constant
omegaL = 0.0269659;               % (1/ms) L-type Ca channel rate constant

% RyR Rate Constants
k12 = 87.75e-6*5/3.5;             % (1/[uM^2 ms]) ryanodine receptor rate constant
k21 = 1250;                       % (1/ms) ryanodine receptor rate constant
k23 = 235.8;                      % (1/[uM^2 ms]) ryanodine receptor rate constant
k32 = 9.6;                        % (1/ms) ryanodine receptor rate constant
k34 = 1.415;                      % (1/[uM^2 ms]) ryanodine receptor rate constant
k43 = 13.65;                      % (1/ms) ryanodine receptor rate constant
k45 = 0.07;                       % (1/ms) ryanodine receptor rate constant
k54 = 93.385e-6;                  % (1/[uM^2 ms]) ryanodine receptor rate constant
k56 = 18.87;                      % (1/[uM^2 ms]) ryanodine receptor rate constant
k65 = 30;                         % (1/ms) ryanodine receptor rate constant
k25 = 2.358;                      % (1/[uM^2 ms]) ryanodine receptor rate constant
k52 = 0.001235;                   % (1/ms) ryanodine receptor rate constant

% Luminal Ca Sensitivity
SRmax = 0.3;                      % (-) luminal Ca sensitivity parameter
SRmin = 2;                        % (-) luminal Ca sensitivity parameter
SREC50 = 0.75;                    % (-) luminal Ca sensitivity parameter
SRH = 1;                          % (-) luminal Ca sensitivity parameter

% SR Leak
r_leak = 5.348e-6/NCaRU*Vmyo/VSS; % (1/ms) passive SR leak rate

%% Ca Handling Parameters

% ICab: Ca background current
g_ICab = 0.000035;                % (mS/uF) Ca leak conductance

% NCX: Na/Ca exchanger
Vmax_NaCa = 0.65;                 % (pA/pF) NCX exchange rate
KmNai_NaCa = 12e3;                % (uM) NCX Na affinity
KmCai_NaCa = 0.0036e3;            % (uM) NCX Ca affinity
KmCao_NaCa = 1.4e3;               % (uM) NCX Ca affinity
ksat_NaCa = 0.27;                 % (-) NCX rate constant
eta_NaCa = 0.35;                  % (-) NCX rate constant

% IpCa: Sarcolemnal Ca pump
Km_IpCa = 0.289;                  % (uM) Ca pump Ca affinity
IpCamax = 0.006;                  % (pA/pF) maximum Ca pump current

% SERCA: Sarcoplasmic reticulum Ca pump
Kfb = 0.3;                        % (uM) SERCA forward-mode Ca affinity (check units)
Krb = 2.1e3;                      % (uM) SERCA reverse-mode Ca affinity
N = 1.787;                        % (-) SERCA Hill coefficient
vmax = 286e-3*1.15;               % (uM/ms) SERCA pump max rate

%% Na Channel Parameters

% INa: Fast Na channel
g_INa = 13;                       % (mS/uF) INa conductance

% INab: Na background current
g_INab = 0.002;                   % (mS/uF) Na leak conductance

% INaK: Na/K pump
INaKmax = 2;                      % (pA/pF) Maximum exchanger current
Km_Nai = 18.8e3;                  % (uM) Na/K pump sodium affinity
Km_Ko = 1.5e3;                    % (uM) Na/K pump potassium affinity


%% K Channel Parameters

% IKtof: Fast transient outward
g_IKtof = 0.26;                   % (mS/uF) IKtof conductance

% IKss: Non-inactivating steady-state current
g_IKss = 0.047;                   % (mS/uF) IKss conductance

% IKs: Slow delayed rectifier
g_IKs = 0.00575;                  % (mS/uF) IKs conductance

% IKr: Rapid delayed rectifier
IKr_kb = 0.036778;                % (1/ms) IKr rate constant
IKr_kf = 0.023761;                % (1/ms) IKr rate constant
g_IKr = 0.078;                    % (mS/uF) IKr conductance

% IKur: Ultra-rapid delayed rectifier
g_IKur = 0.2;                     % (mS/uF) IKur conductance

%% Transgenic Mouse Parameterization

% PLB-KO
% JRyRmax = 3.92*6;               % (1/ms) Unitary Ca flux rate through RyR

% PLM-KO
% g_INab = 0.0048;                % (mS/uF) Na leak conductance
% INaKmax = 1.6;                  % (pA/pF) Maximum exchanger current

%% Assemble Parameters Array
params = [F RT_over_F Istimmax bcl Cm Csa Vmyo VSR VSS ...
  Cao Ko Nao Mgi ...
  ISO FSK IBMX ...
  b1ARtot kf_LR kf_LRG kf_RG kr_LR kr_LRG kr_RG ...
  Gstot k_G_act k_G_hyd k_G_reassoc ...
  kf_bARK kr_bARK kf_PKA kr_PKA ...
  ACtot ATP k_AC_basal Km_AC_basal ...
  kf_AC_Gsa kr_AC_Gsa k_AC_Gsa Km_AC_Gsa ...
  Kd_AC_FSK k_AC_FSK Km_AC_FSK ...
  PDEtot k_cAMP_PDE k_cAMP_PDEp Km_PDE_cAMP ...
  Kd_PDE_IBMX k_PKA_PDE k_PP_PDE ...
  PKAIItot PKItot ...
  kf_RC_cAMP kf_RCcAMP_cAMP kf_RcAMPcAMP_C kf_PKA_PKI ...
  kr_RC_cAMP kr_RCcAMP_cAMP kr_RcAMPcAMP_C kr_PKA_PKI ...
  epsilon ...
  PP1tot I1tot k_PKA_I1 Km_PKA_I1 Vmax_PP2A_I1 Km_PP2A_I1 ...
  kf_PP1_I1 kr_PP1_I1 ...
  LCCtot PKACII_LCCtot PP1_LCC PP2A_LCC ...
  k_PKA_LCC Km_PKA_LCC k_PP1_LCC Km_PP1_LCC k_PP2A_LCC Km_PP2A_LCC ...
  PLBtot k_PKA_PLB Km_PKA_PLB k_PP1_PLB Km_PP1_PLB ...
  PLMtot k_PKA_PLM Km_PKA_PLM k_PP1_PLM Km_PP1_PLM ...
  TnItot PP2A_TnI k_PKA_TnI Km_PKA_TnI k_PP2A_TnI Km_PP2A_TnI ...
  CaMtot TnCLtot TnCHtot Myosintot CSQNtot ...
  CaSRbtot CaSLtot CaSLhtot CaATPtot CaPCrtot ...
  kon_CaM koff_CaM kon_TnCL koff_TnCL kon_TnCHCa koff_TnCHCa ...
  kon_TnCHMg koff_TnCHMg kon_MyosinCa koff_MyosinCa ...
  kon_MyosinMg koff_MyosinMg ...
  kon_CaSRb koff_CaSRb kon_CaSL koff_CaSL kon_CaSLh koff_CaSLh ...
  kon_CaATP koff_CaATP kon_CaPCr koff_CaPCr ...
  Ki_MgATP Km_CSQN ...
  NCaRU PCaL r_xfer JRyRmax fL aL bL gammaL omegaL ...
  k12 k21 k23 k32 k34 k43 k45 k54 k56 k65 k25 k52 ...
  SRmax SRmin SREC50 SRH r_leak ...
  g_ICab Vmax_NaCa KmNai_NaCa KmCai_NaCa KmCao_NaCa ksat_NaCa eta_NaCa ...
  IpCamax Km_IpCa Kfb Krb N vmax ...
  g_INa g_INab INaKmax Km_Nai Km_Ko ...
  g_IKtof g_IKss g_IKs IKr_kb IKr_kf g_IKr g_IKur ...
  ];


