function ec_coupling
% EC coupling model for adult rat ventricular myocytes, LRd style
%
% Reference:
% Jeffrey J. Saucerman, Laurence L. Brunton, Anushka P. Michailova, and Andrew D. McCulloch
% "Modeling beta-adrenergic control of cardiac myocyte contractility in silico", J. Biol. Chem., Vol 278: 47977-48003
%
% Copyright (2004) The Regents of the University of California
% All Rights Reserved
%
% Last modified: 3/25/2004
% Implemented by: Jeffrey Saucerman <jsaucer@ucsd.edu>
%
% Notes

% Parameters
% universal parameters
p(1) = 20.8e-6;     % Vmyo  [uL]
p(2) = 9.88e-7;     % Vnsr  [uL]
p(3) = 9.3e-8;      % Vjsr  [uL]
p(4) = 1.534e-4;    % ACap  [cm^2] with C = 1 uF/cm^2
p(5) = 310;         % Temp  [K]
% extracellular concentrations     
p(6) = 140;     % Extracellular Na  [mM]
p(7) = 5.4;     % Extracellular K   [mM]
p(8) = 1.8;     % Extracellular Ca  [mM]
% current conductances
p(9) = 8.0;     % G_Na      [mS/uF]
p(10) = 0.35;   % G_to      [mS/uF] 
p(11) = 0.07;   % G_ss      [mS/uF]
p(12) = 0.24;   % G_kibar   [mS/uF] 
p(13) = 0.008;  % G_kp      [mS/uF]
% I_Ca parameters
p(14) = 2.8e-4;     % P_Ca  [cm/sec] was 5.4e-4, scale to match Q_CaL = 16 pC
p(15) = 6.75e-7;    % P_Na  [cm/sec]
p(16) = 1.93e-7;    % P_K   [cm/sec]
p(17) = 0.6e-3;     % Km_Ca [mM]
% pumps and background currents
p(18) = 1483;   % k_NaCa    [uA/uF]
p(19) = 87.5;   % Km_Na     [mM]
p(20) = 1.38;   % Km_Ca     [mM]
p(21) = 0.1;    % k_sat     [none]  
p(22) = 0.35;   % eta       [none]
p(23) = 0.974;  % ibarnak   [uA/uF]
p(24) = 10;     % Km_Nai    [mM]
p(25) = 1.5;    % Km_Ko     [mM]
p(26) = 1.15;   % ibarpca   [uA/uF]
p(27) = 0.5e-3; % Km_pca    [mM]
p(28) = 2.8e-3; % G_Cab     [uA/uF] 
p(29) = 1e-3;   % G_Nab     [uA/uF] 
p(30) = 0;      % Pns 
p(31) = 1.2e-3; % Km_ns     [mM]
% Calcium handling parameters
p(32) = 4.7;    % I_upbar   [mM/sec]
p(33) = 3e-4;   % Km_up     [mM]
p(34) = 15;     % nsrbar    [mM]
p(35) = 2e-3;   % tauon     [sec]
p(36) = 2e-3;   % tauoff    [sec]
p(37) = 60e3;     % gmaxrel   [mM/sec]
p(38) = 0.18e-3;% dcaith    [mM]
p(39) = 0.8e-3; % Km_rel    [mM]
p(40) = 8.75;   % CSQNth    [mM]
p(41) = 15;     % CSQNbar   [mM]
p(42) = 0.8;    % Km_csqn   [mM]
p(43) = 5.7e-4; % tau_tr    [sec]
p(44) = 0.07;   % TRPNbar   [mM]
p(45) = 0.05;   % CMDNbar   [mM]
p(46) = 0.07;   % INDObar   [mM]
p(47) = 0.5128e-3;  % Km_trpn   [mM]
p(48) = 2.38e-3;    % Km_cmdn   [mM]
p(49) = 8.44e-4;    % Km_indo   [mM]

% Initial conditions and mass matrix
% Na and K currents
%   1       2       3       4       5       6       7       8       9       10
%   m       h       j       d       f       rto     sto     ssto    rss     sss   
y10=[1.4e-3;0.99;   0.99;   0.0;    1.0;    1.4e-3; 1.0;    0.69;   1.8e-3; 0.43];
m1 =[1,     1,      1,      1,      1,      1,      1,      1,      1,      1];
%   Intracellular concentrations/ Membrane voltage
%   11       12      13     14     15      16      17       
%   Ca_nsr  Ca_jsr  Nai     Ki      Cai    Vm      trel
y20=[1.74;   1.74;  16;    145;    1.52e-4;-85.61; 0.9];
m2 =[1,     1,      1,     1,      1,      1,       1];

% Put everything together
y0  = [y10;y20];    
M = diag([m1,m2]); 

% Options
tspan = [0;10];
options = odeset('Mass',M,'RelTol',1e-4,'MaxStep',2e-3,'Stats','on'); 

% Run simulation
[t,y] = ode15s(@f,tspan,y0,options,p);

yfinal = y(end,:)

Nai = y(:,13); Ki = y(:,14); Cai = y(:,15); Vm = y(:,16);
Ca_nsr = y(:,11); Ca_jsr = y(:,12);

global evars;
evars = remove_repeats(evars);
Q_CaL = -1e3/10*trapz(evars(:,1),evars(:,2))   % Q_CaL [pC] should be 16.2+/-3
%te = evars(:,1); I_rel = evars(:,2); grel = evars(:,3); ca_grad = evars(:,4);
clear global evars;

subplot(2,2,1);
plot(t,Vm);
title('V_m');

subplot(2,2,2);
plot(t,Cai);
title('Cai');

subplot(2,2,3);
plot(t,Nai);

subplot(2,2,4);
% plot(t,[Ca_nsr,Ca_jsr]);
% title('SR nsr and jsr');
plot(t,Ki);

function ydot = f(t,y,p)

ydot = zeros(size(y));

% -------- EC COUPLING MODEL -----------

% Constants
R = 8314;   % R     [J/kmol*K]
Frdy = 96485;  % Frdy     [C/mol]
FoRT = Frdy/R/p(5);
zna = 1;    % Na valence
zk = 1;     % K valence
zca = 2;    % Ca valence
% Nernst Potentials
ena = (1/FoRT/zna)*log(p(6)/y(13));       % should be 70.54 mV
ek = (1/FoRT/zk)*log(p(7)/y(14));		 % should be -87.94 mV
eca = (1/FoRT/zca)*log(p(8)/y(15));  % should be 120 mV
%eks = (1/FoRT)*logn((ko+prnak*nao)/(ki+prnak*nai))	% should be -77.54
ecl = -40.0;

% I_Na: Fast Na Current
am = 0.32*(y(16)+47.13)/(1-exp(-0.1*(y(16)+47.13)));
bm = 0.08*exp(-y(16)/11);
if y(16) >= -40
    ah = 0; aj = 0;
    bh = 1/(0.13*(1+exp(-(y(16)+10.66)/11.1)));
    bj = 0.3*exp(-2.535e-7*y(16))/(1+exp(-0.1*(y(16)+32)));
else
    ah = 0.135*exp((80+y(16))/-6.8);
    bh = 3.56*exp(0.079*y(16))+3.1e5*exp(0.35*y(16));
    aj = (-1.2714e5*exp(0.2444*y(16))-3.474e-5*exp(-0.04391*y(16)))*(y(16)+37.78)/(1+exp(0.311*(y(16)+79.23)));
    bj = 0.1212*exp(-0.01052*y(16))/(1+exp(-0.1378*(y(16)+40.14)));
end
ydot(1) = 1e3*(am*(1-y(1))-bm*y(1));
ydot(2) = 1e3*(ah*(1-y(2))-bh*y(2));
ydot(3) = 1e3*(aj*(1-y(3))-bj*y(3));
I_Na = p(9)*y(1)^3*y(2)*y(3)*(y(16)-ena);

% I_Ca: L-type Calcium Current
% Note: not currently modeling permeation of Na and K through I_Ca
% Need to scale this current for rat
gacai = 1; gacao = 0.341;   % Activity coefficients of Ca
ganai = 0.75; ganao = 0.75; % Activity coefficients of Na
gaki = 0.75; gako = 0.75;   % Activity coefficients of K
ibarca = p(14)*zca*zca*(y(16)*Frdy*FoRT) * (gacai*y(15)*exp(zca*y(16)*FoRT)-gacao*p(8)) /(exp(zca*y(16)*FoRT)-1);
dss = 1/(1+exp(-(y(16)+10)/6.24));
taud = dss*(1-exp(-(y(16)+10)/6.24))/(0.035*(y(16)+10));%   [msec]
fss = 1/(1+exp((y(16)+35.06)/8.6))+0.6/(1+exp((50-y(16))/20));
tauf = 1/(0.0197*exp( -(0.0337*(y(16)+10))^2 )+0.02);   %   [msec]
ydot(4) = 1e3*(dss-y(4))/taud;                          %   [sec]
ydot(5) = 1e3*(fss-y(5))/tauf;                          %   [sec]
fca = 1/(1+y(15)/p(17));
I_Ca = y(4)*y(5)*fca*ibarca;

% I_to: Transient Outward K Current
rtoss = 1/(1+exp((y(16)+10.6)/-11.42));
stoss = 1/(1+exp((y(16)+45.3)/6.8841));
taurto = 1.0/(45.16*exp(0.03577*(y(16)+50))+98.9*exp(-0.1*(y(16)+38))); % [sec]
tausto = 0.35*exp(-((y(16)+70)/15)^2)+0.035;	    % [sec]		 
taussto = 3.7*exp(-((y(16)+70)/30)^2)+0.035;        % [sec]			 
ydot(6) = (rtoss-y(6))/taurto;
ydot(7) = (stoss-y(7))/tausto;
ydot(8) = (stoss-y(8))/taussto;
I_to = p(10)*y(6)*(0.886*y(7)+0.114*y(8))*(y(16)-ek);   % [uA/uF]

% I_ss: Steady-state K Current
rssinf = 1/(1+exp(-(y(16)+11.5)/11.82));
taurss = 10/(45.16*exp(0.03577*(y(16)+50))+98.9*exp(-0.1*(y(16)+38)));
sssinf = 1/(1+exp((y(16)+87.5)/10.3));
tausss = 2.1;
ydot(9) = (rssinf-y(9))/taurss;
ydot(10) = (sssinf-y(10))/tausss;
I_ss = p(11)*y(9)*y(10)*(y(16)-ek);

% I_ki: Time-Independent K Current
aki = 1.02/(1+exp(0.2385*(y(16)-ek-59.215)));
bki =(0.49124*exp(0.08032*(y(16)+5.476-ek)) + exp(0.06175*(y(16)-ek-594.31))) /(1 + exp(-0.5143*(y(16)-ek+4.753)));
kiss = aki/(aki+bki);
I_ki = p(12)*sqrt(p(7)/5.4)*kiss*(y(16)-ek) ;

% I_kp: Plateau K Current
kp = 1/(1+exp((7.488-y(16))/5.98));
I_kp = p(13)*kp*(y(16)-ek);

% I_ncx: Na/Ca Exchanger Current
s4 = exp(p(22)*y(16)*FoRT)*y(13)^3*p(8);
s5 = exp((p(22)-1)*y(16)*FoRT)*p(6)^3*y(15);
I_ncx = p(18)/(p(19)^3+p(6)^3) /(p(20)+p(8)) /(1+p(21)*exp((p(22)-1)*y(16)*FoRT)) *(s4-s5);

% I_nak: Na/K Pump Current
sigma = (exp(p(6)/67.3)-1)/7;
fnak = 1/(1+0.1245*exp(-0.1*y(16)*FoRT)+0.0365*sigma*exp(-y(16)*FoRT));
I_nak = p(23) *fnak /(1+(p(24)/y(13))^1.5) *(p(7)/(p(7)+p(25)));

% I_pca: Sarcolemmal Ca Pump Current
I_pca = p(26)*y(15)/(p(27)+y(15));
 
% I_cab: Ca Background Current
I_cab = p(28)*(y(16)-eca);
 
% I_nab: Na Background Current
I_nab = p(29)*(y(16)-ena);

% I_nsca: Nonspecific Ca-Activated Current: not used

% Total Membrane Currents
I_Na_tot = I_Na+I_nab+3*I_ncx+3*I_nak;          % [uA/uF]
I_K_tot = I_to+I_ss+I_ki+I_kp-2*I_nak;          % [uA/uF]
I_Ca_tot = I_Ca+I_cab+I_pca-2*I_ncx;            % [uA/uF]

% Calcium Induced Calcium Release (CICR)
trel = y(17)+2e-3;
ryron = 1-exp(-trel/p(35));  
ryroff = exp(-trel/p(36));
grel = p(37)/(1+exp((I_Ca_tot+5)/0.9)); 
I_rel = grel*ryron*ryroff*(y(12)-y(15));

% Other SR fluxes and concentrations
I_up = p(32)*y(15)^2/(p(33)^2+y(15)^2);         %   [mM/sec]
I_leak = p(32)*y(11)/p(34);                     %   [mM/sec]
I_tr = (y(11)-y(12))/p(43);                     %   [mM/sec]
Bjsr = 1/( 1+p(41)*p(42)/(p(42)+y(12))^2 );
ydot(11) = I_up-I_leak-I_tr*p(3)/p(2);          %   [mM/sec]
ydot(12) = Bjsr*(I_tr-I_rel);                   %   [mM/sec]
SRcontent = 1e3*((y(12)+y(12)/Bjsr)*p(3)/p(1)+y(11)*p(2)/p(1));    % [umol/L cytosol]

% Cytoplasmic Calcium Buffering
btrpn = p(44)*p(47)/(p(47)+y(15))^2;
bcmdn = p(45)*p(48)/(p(48)+y(15))^2;
bindo = p(46)*p(49)/(p(49)+y(15))^2;
Bmyo = 1/( 1+ bcmdn + btrpn + btrpn + bindo);

% Ion Concentrations and Membrane Potential
ydot(13) = -1e3*I_Na_tot*p(4)/(p(1)*zna*Frdy);          % [mM/sec] 
ydot(14) = -1e3*I_K_tot*p(4)/(p(1)*zk*Frdy);            % [mM/sec]
ydot(15) = -Bmyo*(1e3*I_Ca_tot*p(4)/(p(1)*zca*Frdy) ...
    +((I_up-I_leak)*p(2)/p(1))-(I_rel*p(3)/p(1)));      % [mM/sec]

% Simulation type
protocol = 'pace';

switch lower(protocol)
    case {'none',''},
        I_app = 0;
    case 'pace',        % pace w/ current injection at rate 'rate'
		rate = 1;
		if mod(t+0.9,1/rate) <= 5e-3
            I_app = 10.0;
		else
            I_app = 0.0;
		end
    case 'vclamp',      
		V_hold = -80;
        V_test = -80;
		if (t > 0.1 & t < 0.5)
		    V_clamp = V_test;
		else
		    V_clamp = V_hold;
		end
		R_clamp = 0.02;
		I_app = (V_clamp-y(16))/R_clamp;
end  

ydot(16) = -1e3*(I_Ca_tot+I_K_tot+I_Na_tot-I_app);

% CICR timing: y(17) tracks the last time when Vdot > 30 mV/msec
if (ydot(16) > 30e3) 
    ydot(17) = 1-1e4*y(17); 
else
    ydot(17) = 1;
end

% Export intermediate variables (comment out for general usage)
global evars;
ca_grad = y(12) - y(15);
evars = [evars;t,I_Ca];