function bar_signaling
% beta-adrenergic signaling model for adult rat ventricular myocytes
%
% Reference:
% Jeffrey J. Saucerman, Laurence L. Brunton, Anushka P. Michailova, and Andrew D. McCulloch
% "Modeling beta-adrenergic control of cardiac myocyte contractility in silico", J. Biol. Chem., Vol 278: 47977-48003
%
% Copyright (2003) The Regents of the University of California
% All Rights Reserved
%
% Last modified: 3/18/2004
% Implemented by: Jeffrey Saucerman <jsaucer@ucsd.edu>
%
% Notes
% 3/16/2004: several of the algebraic equations seem highly dependent on a
% good choice of IC's.  However, so far I have been able to find good IC's
% by running out simulations to steady state.
% Initial conditions are close, but need to be tweaked slightly

% Parameters
% b-AR/Gs module
p(1) = 0.0;     % Ltotmax   [uM]
p(2) = 0.0132;  % sumb1AR   [uM]
p(3) = 3.83;    % Gstot     [uM]
p(4) = 0.285;   % Kl        [uM]
p(5) = 0.062;   % Kr        [uM]
p(6) = 33.0;    % Kc        [uM]
p(7) = 1.1e-3;  % k_barkp   [1/sec]
p(8) = 2.2e-3;  % k_barkm   [1/sec]
p(9) = 3.6e-3;  % k_pkap    [1/sec/uM]
p(10) = 2.2e-3; % k_pkam    [1/sec]
p(11) = 16.0;   % k_gact    [1/sec]
p(12) = 0.8;    % k_hyd     [1/sec]
p(13) = 1.21e3; % k_reassoc [1/sec/uM]
% cAMP module
p(14) = 49.7e-3;% AC_tot    [uM]
p(15) = 5.0e3;  % ATP       [uM]
p(16) = 38.9e-3;% PDEtot    [uM]
p(17) = 0.0;    % IBMXtot   [uM]
p(18) = 0.0;    % Fsktot    [uM] (10 uM when used)
p(19) = 0.2;    % k_ac_basal[1/sec]
p(20) = 8.5;    % k_ac_gsa  [1/sec]
p(21) = 7.3;    % k_ac_fsk  [1/sec]
p(22) = 5.0;    % k_pde     [1/sec]
p(23) = 1.03e3; % Km_basal  [uM]
p(24) = 315.0;  % Km_gsa    [uM]
p(25) = 860.0;  % Km_fsk    [uM]
p(26) = 1.3;    % Km_pde    [uM]
p(27) = 0.4;    % Kgsa      [uM]
p(28) = 44.0;   % Kfsk      [uM]
p(29) = 30.0;   % Ki_ibmx   [uM]
% PKA module
p(30) = 0.59;   % PKAItot   [uM]
p(31) = 0.025;  % PKAIItot  [uM]
p(32) = 0.18;   % PKItot    [uM]
p(33) = 9.14;   % Ka        [uM]
p(34) = 1.64;   % Kb        [uM]
p(35) = 4.375;  % Kd        [uM]
p(36) = 0.2e-3; % Ki_pki    [uM]
% PLB module
p(37) = 10;     % epsilon   [none]
p(38) = 106;    % PLBtot    [uM]
p(39) = 0.89;   % PP1tot    [uM]
p(40) = 0.3;    % Inhib1tot [uM]
p(41) = 54;     % k_pka_plb     [1/sec]
p(42) = 21;     % Km_pka_plb    [uM]
p(43) = 8.5;    % k_pp1_plb     [1/sec]
p(44) = 7.0;    % Km_pp1_plb    [uM]
p(45) = 60;     % k_pka_i1      [1/sec]
p(46) = 1.0;    % Km_pka_i1     [uM]
p(47) = 14.0;   % Vmax_pp2a_i1  [uM/sec]
p(48) = 1.0;    % Km_pp2a_i1    [uM]
p(49) = 1.0e-3; % Ki_inhib1     [uM]
% LCC module
p(50) = 25e-3;  % LCCtot        [uM]
p(51) = 25e-3;  % PP1lcctot     [uM]
p(52) = 25e-3;  % PP2Alcctot    [uM]
p(53) = 54;     % k_pka_lcc     [1/sec]
p(54) = 21;     % Km_pka_lcc    [uM]
p(55) = 8.52;   % k_pp1_lcc     [1/sec]
p(56) = 3;      % Km_pp1_lcc    [uM]
p(57) = 10.1;   % k_pp2a_lcc    [1/sec]
p(58) = 3;      % Km_pp2a_lcc   [uM]

% Initial conditions and mass matrix
% b-AR/Gsa module
%   1       2       3       4       5       6       7           8       9
%   L       R       Gs      b1ARtot b1ARd   b1ARp   Gsagtptot   Gsagdp  Gsbg
y10=[1;     0.01079;3.829;  0.01205;0.0;    1.154e-3;0.02505;   6.446e-4;0.02569];
m1 =[0,     0,      0,      1,      1,      1,      1,          1,      1];
% cAMP module and PKA module
%   10      11      12      13      14      15      
%   Gsa_gtp Fsk     AC      PDE     IBMX    cAMPtot 
y20=[0.02241;0;     0.04706;0.0389; 0;      0.8453];
m2 =[0,     0,      0,      0,      0,      1];
% PKA module
%   16      17      18
%   cAMP    PKACI   PKACII
y30=[0.2268;0.05868;8.278e-3];
m3 =[0,     0,      0];
% PLB module
%   19      20          21      22
%   PLBs    Inhib1ptot  Inhib1p PP1
y40=[4.095; 0.05252;    6e-5;   0.8375];
m4 =[1,     1,          0,      0];
% LCC module
%   23          24
%   LCCap       LCCbp
y50=[5.076e-3;  5.812e-3];
m5 =[1,     1];
% Put everything together
y0  = [y10;y20;y30;y40;y50];    
M = diag([m1,m2,m3,m4,m5]); 

% Options
tspan = [0;1];
options = odeset('Mass',M,'RelTol',1e-5); 
%options = odeset('Mass',M,'RelTol',1e-5,'MaxStep',2e-4); % for EC coupling

% Run simulation
[t,y] = ode15s(@f,tspan,y0,options,p);
y

plot(t,y(:,7),t,y(:,15));
legend('Gsa_g_t_ptot','cAMP_t_o_t');
%plot(t,y(:,23),t,y(:,24))

function ydot = f(t,y,p)

ydot = zeros(size(y));

% -------- SIGNALING MODEL -----------

% b-AR module
LR = y(1)*y(2)/p(4);
LRG = LR*y(3)/p(5);
RG = y(2)*y(3)/p(6);
BARKDESENS = p(7)*(LR+LRG);
BARKRESENS = p(8)*y(5);
PKADESENS = p(9)*y(17)*y(4);  
PKARESENS = p(10)*y(6);
GACT = p(11)*(RG+LRG);
HYD = p(12)*y(7);
REASSOC = p(13)*y(8)*y(9);
ydot(1) = p(1)-LR-LRG-y(1);
ydot(2) = y(4)-LR-LRG-RG-y(2);
ydot(3) = p(3)-LRG-RG-y(3);
ydot(4) = (BARKRESENS-BARKDESENS)+(PKARESENS-PKADESENS);
ydot(5) = BARKDESENS-BARKRESENS;
ydot(6) = PKADESENS-PKARESENS;
ydot(7) = GACT-HYD;
ydot(8) = HYD-REASSOC;
ydot(9) = GACT-REASSOC;
% end b-AR module

% cAMP module
Gsa_gtp_AC = y(10)*y(12)/p(27);
Fsk_AC = y(11)*y(12)/p(28);
AC_ACT_BASAL = p(19)*y(12)*p(15)/(p(23)+p(15));	    
AC_ACT_GSA = p(20)*Gsa_gtp_AC*p(15)/(p(24)+p(15)); 
AC_ACT_FSK = p(21)*Fsk_AC*p(15)/(p(25)+p(15));	   
PDE_ACT = p(22)*y(13)*y(16)/(p(26)+y(16));	% FIXME: change 0.3*y(15) to cAMPfree   
PDE_IBMX = y(13)*y(14)/p(29);
ydot(10) = y(7)-Gsa_gtp_AC-y(10);
ydot(11) = p(18)-Fsk_AC-y(11);
ydot(12) = p(14)-Gsa_gtp_AC-y(12);  % note: assumes Fsk = 0.  Change Gsa_gtp_AC to Fsk_AC for Forskolin.
ydot(13) = p(16)-PDE_IBMX-y(13);
ydot(14) = p(17)-PDE_IBMX-y(14);
ydot(15) = AC_ACT_BASAL+AC_ACT_GSA+AC_ACT_FSK-PDE_ACT;
% end cAMP module

% PKA module
% PKA module
% 4/13/04 note: 
% I am currently using an analytical solution for cAMPfree.
PKI = p(32)*p(36)/(p(36)+y(17)+y(18));
A2RC_I = (y(17)/p(35))*y(17)*(1+PKI/p(36));
A2R_I = y(17)*(1+PKI/p(36));
A2RC_II = (y(18)/p(35))*y(18)*(1+PKI/p(36));
A2R_II = y(18)*(1+PKI/p(36));
cAMPtemp = y(15)-(2*A2RC_I+2*A2R_I)-(2*A2RC_II+2*A2R_II);
ydot(16) = cAMPtemp-sqrt(cAMPtemp^2-4*p(33)*(A2RC_I+A2RC_II))-y(16);
PKAtemp = p(33)*p(34)/p(35)+p(33)*y(16)/p(35)+y(16)^2/p(35);
ydot(17) = 2*p(30)*y(16)^2-y(17)*(1+PKI/p(36))*(PKAtemp*y(17)+y(16)^2);
ydot(18) = 2*p(31)*y(16)^2-y(18)*(1+PKI/p(36))*(PKAtemp*y(18)+y(16)^2);
% original version
% ydot(16) = y(15)-(ARC_I+2*A2RC_I+2*A2R_I)-(ARC_II+2*A2RC_II+2*A2R_II)-y(16);
% ydot(17) = 2*p(30)-(RC_I+ARC_I+A2RC_I+PKACI_PKI)-y(17);   
% ydot(18) = 2*p(31)-(RC_II+ARC_II+A2RC_II+PKACII_PKI)-y(18); 
% end PKA module

% PLB module
PLB = p(38)-y(19);
PLB_PHOSPH = p(41)*y(17)*PLB/(p(42)+PLB);
PLB_DEPHOSPH = p(43)*y(22)*y(19)/(p(44)+y(19));
ydot(19) = PLB_PHOSPH-PLB_DEPHOSPH;
 
Inhib1 = p(40)-y(20);
Inhib1p_PP1 = y(21)*y(22)/p(49);
Inhib1_PHOSPH = p(45)*y(17)*Inhib1/(p(46)+Inhib1); 
Inhib1_DEPHOSPH = p(47)*y(20)/(p(48)+y(20));
ydot(20) = Inhib1_PHOSPH-Inhib1_DEPHOSPH;
ydot(21) = y(20)-Inhib1p_PP1-y(21);
ydot(22) = p(39)-Inhib1p_PP1-y(22);

fracPLBp = y(19)/p(38);
fracPLB = PLB/p(38);
% end PLB module

% LCC module
% note- this is the simplified version.. it gets more
% complicated when the full markov model is used
LCCa = p(50)-y(23);
LCCa_PHOSPH = p(37)*p(53)*y(18)*LCCa/(p(54) + p(37)*LCCa);
LCCa_DEPHOSPH = p(37)*p(57)*p(52)*y(23)/(p(58)+p(37)*y(23));
ydot(23) = LCCa_PHOSPH - LCCa_DEPHOSPH;
fracLCCap = y(23)/p(50);
 
% phosphorylation rates for Markov model
% phosph[1..12] = p(37)*kcat_pka_lcc*y(18)*P[i]/(Km_pka_lcc+p(37)*P[i]*LCCtot)
% dephosph[1..12] = p(37)*kcat_pp2a_lcc*pp2alcctot*P[i+12]/(Km_pp2a_lcc+p(37)*P[i+12]*LCCtot)

LCCb = p(50)-y(24);
LCCb_PHOSPH = p(37)*p(53)*y(18)*LCCb/(p(54)+p(37)*LCCb);   
LCCb_DEPHOSPH = p(37)*p(55)*p(51)*y(24)/(p(56)+p(37)*y(24));
ydot(24) = LCCb_PHOSPH-LCCb_DEPHOSPH;
fracLCCbp = y(24)/p(50);
% end LCC module