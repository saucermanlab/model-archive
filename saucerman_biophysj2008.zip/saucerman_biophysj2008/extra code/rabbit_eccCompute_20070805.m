function [t,y] = rabbit_eccCompute
% Rabbit E-C coupling model.
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%NB: yfinal after 190s 1Hz%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Reference:
% Thomas R. Shannon, Fei Wang, Jose Puglisi, Christopher Weber, Donald M. Bers
% "A Mathematical Treatment of Integrated Ca Dynamics Within the Ventricular Myocyte",
% Biophys J., 87:3351-3371 (2004).
%
%% Notes:
% 02/28/2007 (JS): corrected Ito distribution as per Eleonora's comments:
%        GtoSlow = 0.06;     % [mS/uF], GtoFast = 0.02;     % [mS/uF]
% 09/29/2006 (JS):
% Copied from shannon_rabbit_06_05_2006.m, cleaning up implementation to
% make modular.
% 06/05/2006 (EG):
% current pulse:
% with Na concentration fixed ->different results
% with Na and Ca concentrations fixed -> same results -> Ca-related difference
% with Na concentration fixed, Ca free, release and leak=0 -> still differences
% voltage pulse:
% transmembrane fluxes don't change with Ca fixed
% buffers ok with Ca fixed
% diffusion ok with Ca fixed
% SR concentration and buffering ok both with Ca free and fixed

% 02/09/2006 (EG):
%   ICaL reduction factor (*0.45)
%   added I_kp as in C-code; set to 0; 
%   added Cl- currents (Ca-activated and background) in the calculation of the AP;
%   IbarSLCaP = 0.0673 [uA/uF]; % it was 0.093 [uA/uF]
%   Buffers: *0.1 junction reduction factor for Bmax_SLlowj and Bmax_SLhighj
%   fCa_junc and fCa_SL (I_Ca)  koff unit
%   r (I_tos) time-dependent gating variable
%   SR Ca leak volume ratio
% 02/23/2005 (JS):
%   corrected some mistakes with the diffusion between compartments and
%   buffers, things are looking better now.  uses imported initial
%   conditions from mat file
% 02/21/2005 (JS):
% oops forgot Neema's 1/26 version- incorporating differences
%   updated to rewrite parameter names.  ca concs are too
%   high, but E-C coupling is somehat functional;  cleaned up buffers but
%   requires more work.  items requiring most work include geometry,
%   buffers, and tau's.
% 12/25/2004 (NJ): ALL expressions checked w/ c-code + consistent for the 
%   exception of final ncx + some current summations (gross comparison 
%   appears consistent); additionally, MATLAB code was not changed in areas
%   in which c-code appeared to have the wrong expression **MARK THESE 
%   AREAS IN THE CODE**
%   CHANGES MADE TO PARAMETERS 
%   ONLY CHANGE TO EQUATIONS: CORRECTED INDICES FOR EQ
%   CHANGED TO FULL ydot(38) (Cai), ydot(35) (Ki)
% 05/27/2004 (JS): initial implementation from Shannon paper and c code
%
% JS: Jeffrey Saucerman <jsaucer@ucsd.edu>
% NJ: Neema Jamshid <njamshid@ucsd.edu>
% TS: Thomas Shannon <tshannon@rush.edu>
% EG: Eleonora Grandi <egrandi@deis.unibo.it>
%
clear all;
% external parameters
tic
cycleLength = 1e3/1;
p(1) = cycleLength;  % cycleLength for electrical stimulation

% available IC's:
%y0 = load('rabbit_eccICs_rest_20060929c.dat');
%y0 = load('rabbit_eccICs_0p5Hz_20060929c.dat');
y0 = load('rabbit_eccICs_1Hz_20060929c.dat')';
%y0 = load('rabbit_eccICs_2Hz_20060929c.dat');
%y0 = load('rabbit_eccICs_4Hz_20060929c.dat');

%% Single Run Simulation
tend = 30*cycleLength;
tspan = [0,tend];
options = odeset('RelTol',1e-5,'MaxStep',2); 
[t,y] = ode15s(@rabbit_eccODEfile_20070805,tspan,y0,options,p);
yfinal = y(end,:);

figure(1);
subplot(4,1,1); plot(t,y(:,39)); title('Voltage');
subplot(4,1,2); plot(t,y(:,38)); title('Cyto calcium');
subplot(4,1,3); plot(t,y(:,32),t,y(:,33),t,y(:,34)); title('Na concs');
subplot(4,1,4); plot(t,y(:,36),t,y(:,37),t,y(:,38)); title('Ca concs');
CaT = [t,y(:,38),y(:,36)];
%save 'CaT_2Hz.dat' CaT -ASCII;
% save -ascii 'yfinal.dat' yfinal
toc
