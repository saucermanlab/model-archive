%function yfinal = camCompute_20070222
% CaM/CaMKII/CaN validation script, basically throws all the in vitro
% validations together.  Run this in cell mode to do individual validations
% one at a time.

%% Run for a single simulation starting from zero state
% parameters
% status- works fine with camODEfile_20080418.m
%p = [K, Mg, CaMtot, Btot, CaMKIItot, CaNtot, PP1tot, Ca,cycleLength, compartment];
% p = [135, 1, 6, 0, 120*8.293e-4, 3e-3,0.5, .5, 6000*1e3, 0];
% p = [135, 1, 5.65, 24.2, 120*8.293e-4, 3e-3,10, .5, 6000*1e3, 0];
% p = [135, 1, 6, 24, 0, 3e-3,0, .5, 0, 0];    % testing new CaN model
p = [135, 1, 6, 12, 0, 0,0, 0, 0, 0];         % testing buffer kinetics
tspan = [0 60e3];
y0 = zeros(1,15); y0(1)=p(3);
options = odeset('RelTol',1e-5);
%options = odeset('MaxStep',10);
[t,y] = ode15s(@camODEfile_bufferKinetics20080429,tspan,y0,options,p); 
yfinal = y(end,:);

buffCaM = y(:,4)+y(:,5)+y(:,6);
plot(t./60e3,buffCaM);
%% Batch runs for Ca vs. Ca bound to CaM
% Validates Ca vs. CaCaM with Stemmer and Klee 1994
% status- works OK with camODEfile_temp20071205.m

% parameters
K = 100; % [mM]
CaMtot = 1.0;    % [uM]
Etot = 0.0;   % [uM]
CaMKIItot = 0.0;  % [uM] 
CaNtot = 0.0; % [uM]
PP1tot = 0.0; % [uM]
tspan = [0 5e3];
cycleLength = 1e3;
compartment = 0;
Mg = [1,6];  % [mM]
Camax = 10.^[-1:0.1:3];

y0 = zeros(1,13);
options = odeset('RelTol',1e-5); 
linecolors = ['b','r'];
for j = 1:size(Mg,2)
    for i = 1:size(Camax,2)
        % disp(['Run ',int2str(i),' of ',int2str(size(Camax,2))]);
        p = [K, Mg(j), CaMtot, CaMKIItot, Etot, CaNtot, PP1tot, Camax(i),cycleLength,compartment];
        [t,y] = ode15s(@camODEfile_20080418,tspan,y0,options,p);
        Ca2CaM(i) = y(end,1);
        Ca4CaM(i) = y(end,2);
    end
    figure(1); semilogx(Camax,2.*Ca2CaM+4.*Ca4CaM,linecolors(j)); hold on;
    figure(2); semilogx(Camax,Ca4CaM,linecolors(j)); hold on;
end
figure(1);
xlabel('Ca (\muM)'); ylabel('mol Ca bound/ mol CaM'); 
load '.\model validation data\stemmer_klee1994Mg1mM.dat';
load '.\model validation data\stemmer_klee1994Mg6mM.dat';
semilogx(stemmer_klee1994Mg1mM(:,1),stemmer_klee1994Mg1mM(:,2),'bo');
semilogx(stemmer_klee1994Mg6mM(:,1),stemmer_klee1994Mg6mM(:,2),'ro');
legend('Model 1 mM','Model 6 mM','Stemmer 1 mM','Stemmer 6 mM');
hold off;

figure(2); 
xlabel('Ca (\muM)'); ylabel('Ca4CaM (\muM)'); legend('1 mM Mg','6 mM Mg'); hold off;

%% Batch runs for Ca vs. CaM states in the presence of CaM buffer E
% status- functional with camODEfile_20080429.m

clear all;
% parameters
K = 135; % [mM]
Mg = 1;
CaMtot = 6;    % [uM]
Etot = 26;   % [uM]
CaMKIItot = 0.0;  % [uM] 
CaNtot = 0.0; % [uM]
PP1tot = 0.0; % [uM]
tspan = [0 1e8];
cycleLength = 1e3;
compartment = 0;
Ca = 10.^[-3:0.1:3];

y0 = [CaMtot,zeros(1,14)];
options = odeset('RelTol',1e-5); 
for i = 1:size(Ca,2)
    p = [K, Mg, CaMtot, Etot, CaMKIItot, CaNtot, PP1tot, Ca(i),cycleLength,compartment];
    [t,y] = ode15s(@camODEfile_20080429,tspan,y0,options,p);
    CaM(i) = y(end,1);
    Ca2CaM(i) = y(end,2);
    Ca4CaM(i) = y(end,3);
    CaME(i) = y(end,4);
    Ca2CaME(i) = y(end,5);
    Ca4CaME(i) = y(end,6);
    if i==1
        figure(3); 
        plot(t,y(:,1));
    end
end
E = Etot - CaME - Ca2CaME - Ca4CaME;
figure(1);
subplot(1,2,1);
semilogx(Ca,CaM,Ca,Ca2CaM,Ca,Ca4CaM); legend('CaM','Ca2CaM','Ca4CaM');

subplot(1,2,2);
semilogx(Ca,E,Ca,CaME,Ca,Ca2CaME,Ca,Ca4CaME); legend('E','CaME','Ca2CaME','Ca4CaME');

figure(2);
semilogx(Ca,CaME,Ca,Ca2CaME,Ca,Ca4CaME); legend('CaMB','Ca_2CaMB','Ca_4CaMB');

%% Batch run for CaM vs. CaM-dependent CaMKII activity validation
% compare with Gaertner JBC 2004 data Fig 5, looks good,
% should be setting kbt = 0, but for now I'm just summing all states
% status- works with camODEfile_temp20071205.m
clear all;
% parameters 
K = 150; % [mM]
Mg = 0;
Ca = 500.0;    % [uM]
Etot = 0;
CaMKIItot = 0.0067;  % [uM] 
CaNtot = 0.0; % [uM]
PP1tot = 0.0;   % [uM]
tspan = [0 30e3];
cycleLength = 1e3;
compartment = 0;
CaMtot = 10.^[-3.5:0.1:0.5];

y0 = zeros(1,13);
options = [];
for i = 1:size(CaMtot,2)
    p = [K, Mg, CaMtot(i), Etot,CaMKIItot, CaNtot, PP1tot, Ca, cycleLength,compartment];
    [t,y] = ode15s(@camODEfile_temp20071205,tspan,y0,options,p);
    activity(i) = y(end,7)+y(end,8)+y(end,9)+y(end,10);
end
load 'model validation data/gaertner_jbc2004fig5.dat';
CaMe = gaertner_jbc2004fig5(:,1);
CaMKIIe = gaertner_jbc2004fig5(:,2);
disp('plotting...');
semilogx(CaMtot,activity./max(activity),CaMe,CaMKIIe/25,'o');
xlabel('CaM (\muM)'); ylabel('CaM-dependent CaMKII activity');

%% Batch run for CaM vs. autonomous CaMKII activity
% compare with Gaertner 2004 Fig 6, looks good!
% status- works with camODEfile_20070720.m

clear all;
% parameters 
K = 150; % [mM]
Mg = 0;
Ca = 500.0;    % [uM]
Etot = 0;
CaMKIItot = 0.0067;  % [uM] 
CaNtot = 0.0; % [uM]
PP1tot = 0.0; % [uM]
tspan = [0 5e3];
cycleLength = 1e3;
compartment = 0;
CaMtot = 10.^[-3.0:0.1:1.0];

y0 = zeros(1,13);
options = [];
for i = 1:size(CaMtot,2)
    %disp(['Run ',int2str(i),' of ',int2str(size(CaMtot,2))]);
    p = [K, Mg, CaMtot(i), Etot, CaMKIItot, CaNtot, PP1tot, Ca, cycleLength,compartment];
    [t,y] = ode15s(@camODEfile_temp20071205,tspan,y0,options,p);
    Wt(i) = y(end,8);
    Wa2(i) = y(end,9);
    Wa(i) = y(end,10);
end
load 'model validation data/gaertner_jbc2004fig6.dat';
CaMe = gaertner_jbc2004fig6(:,1);
CaMKIIe = gaertner_jbc2004fig6(:,2);
semilogx(CaMtot,(Wt+Wa+Wa2)./max(Wt+Wa+Wa2),CaMe,CaMKIIe/max(CaMKIIe),'o');
xlabel('CaM (\muM)'); ylabel('% CaMKII autonomy');


%% Batch run for Ca vs. CaM dependent CaMKII activity
% looks pretty good
% status- works with camODEfile_20070719.m but Kd doesn't look so good,
% probably b/c this is at Mg 2.
clear all;
tspan = [0 30e3];
y0 = zeros(1,13);
options = [];%odeset('MaxStep',10e-3);

K = 200; % [mM]
Mg = 2;
CaMtot = 50;
Etot = 0;
CaMKIItot = 1.0;  % [uM] 
CaNtot = 0.0; % [uM]
PP1tot = 0.0; % [uM]
tspan = [0 30e3];   
cycleLength = 1e3;
compartment = 0;
Ca = 10.^[-1:0.1:2];
for i = 1:size(Ca,2)
    %disp(['Run ',int2str(i),' of ',int2str(size(Ca,2))]);
    p = [K, Mg, CaMtot, Etot, CaMKIItot, CaNtot, PP1tot, Ca(i), cycleLength,compartment];
    [t,y] = ode15s(@camODEfile_temp20071205,tspan,y0,options,p);
    activity(i) = sum(y(end,7:10));
end

semilogx(Ca,activity/max(activity)); xlabel('Ca (\muM)');
ylabel('CaM-dependent activity');
load 'model validation data/bradshaw_pnas2003fig2b.dat';
numDatapoints = size(bradshaw_pnas2003fig2b,1)/2;
Cae = bradshaw_pnas2003fig2b(1:numDatapoints,1);
CaMKIIe = bradshaw_pnas2003fig2b(1:numDatapoints,2)./100;
CaMKIIerror = bradshaw_pnas2003fig2b(numDatapoints+1:end,2)./100-CaMKIIe;
hold on; errorbar(Cae,CaMKIIe,CaMKIIerror,'o'); hold off;
errorbarlogx;

%% Batch run for Ca vs. autonomous CaMKII activity w/ different PP1's
% status- works with camODEfile_temp20071205.m
clear all;
tspan = [0 30e3];
y0 = zeros(1,13);
options = [];%odeset('MaxStep',10e-3);

K = 200; % [mM]
Mg = 2;
CaMtot = 50;
Etot = 0;
CaMKIItot = 1.0;  % [uM] 
CaNtot = 0.0; % [uM]
tspan = [0 30*60e3];   
cycleLength = 1e3;
compartment = 0;
Ca = 10.^[-1:0.01:2];
for i = 1:size(Ca,2)
    %disp(['Run ',int2str(i),' of ',int2str(size(Ca,2))]);
    PP1tot = 0.0;
    p = [K, Mg, CaMtot, Etot, CaMKIItot, CaNtot, PP1tot, Ca(i), cycleLength, compartment];
    [t,y] = ode15s(@camODEfile_temp20071205,tspan,y0,options,p);
    activity0(i) = sum(y(end,8:10));
end
for i = 1:size(Ca,2)
    %disp(['Run ',int2str(i),' of ',int2str(size(Ca,2))]);
    PP1tot = 2.5;
    p = [K, Mg, CaMtot, Etot, CaMKIItot, CaNtot, PP1tot, Ca(i), cycleLength, compartment];
    [t,y] = ode15s(@camODEfile_temp20071205,tspan,y0,options,p);
    activity2p5(i) = sum(y(end,8:10));  
end

semilogx(Ca,activity0/max(activity0),Ca,activity2p5/max(activity2p5)); xlabel('Ca (\muM)');
ylabel('Autonomous activity');
% Plot Bradshaw data with PP1 = 0
load 'model validation data/bradshaw_pnas2003fig2c1.dat';
numDatapoints = size(bradshaw_pnas2003fig2c1,1)/2;
Cae = bradshaw_pnas2003fig2c1(1:numDatapoints,1);
CaMKIIe = bradshaw_pnas2003fig2c1(1:numDatapoints,2)./100;
CaMKIIerror = bradshaw_pnas2003fig2c1(numDatapoints+1:end,2)./100-CaMKIIe;
hold on; errorbar(Cae,CaMKIIe,CaMKIIerror,'o'); hold off;
errorbarlogx;

% % Plot Bradshaw data with PP1 = 2.5
load 'model validation data/bradshaw_pnas2003fig3c2p5.dat';
numDatapoints = size(bradshaw_pnas2003fig3c2p5,1)/2;
Cae = bradshaw_pnas2003fig3c2p5(1:numDatapoints,1);
CaMKIIe = bradshaw_pnas2003fig3c2p5(1:numDatapoints,2)./100;
CaMKIIerror = bradshaw_pnas2003fig3c2p5(numDatapoints+1:end,2)./100-CaMKIIe;
hold on; errorbar(Cae,CaMKIIe,CaMKIIerror,'o'); hold off;
errorbarlogx;

% %% Batch run for rate vs. CaMKII activity
% % not yet tested using the new CaM module
% % tspan = [0 30];
% % y0 = [0,0,0,0,0];
% % options = odeset('MaxStep',10e-3);
% % rates = [0.1,0.5:0.5:5];
% % for i = 1:size(rates,2)
% %     disp(['Run ',int2str(i),' of ',int2str(size(rates,2))]);
% %     p(1) = rates(i);
% %     [t,y] = ode15s(@f,tspan,y0,options,p);
% %     Wb(i) = y(end,3);
% %     Wt(i) = y(end,4);
% %     Wa(i) = y(end,5);
% % end
% % plot(rates,Wt+Wa);
% 
%% Batch runs for Ca vs. CaN for testing CaN activation for fixed Ca at
% physiologic K and Mg
% status- works with camODEfile_20070222.m
% for validation against stemmer data
% parameters
K = 50; % [mM]
Mg = 6;  % [mM]
Etot = 0;  
CaMKIItot = 0.0;  % [uM] 
CaNtot = 3e-3; % [uM]
PP1tot = 0.0;   % [uM]
tspan = [0 1e8];
cycleLength = 1e3;
compartment = 0;

CaRange = 10.^[-2:0.1:2];
CaMrange = [0.03,0.3,3,20]; 
y0 = zeros(1,15); 
options = [];

for i = 1:length(CaMrange)
    for j = 1:length(CaRange)
        y0(1)=CaMrange(i);
        %disp(['Run ',int2str(j),' of ',int2str(size(Camax,2))]);
        p = [K, Mg, CaMrange(i), Etot, CaMKIItot, CaNtot, PP1tot, CaRange(j),cycleLength, compartment];
        [t,y] = ode15s(@camODEfile_20080429,tspan,y0,options,p);
        Ca2CaM(i,j) = y(end,2);
        Ca4CaM(i,j) = y(end,3);
        CaMCaN(i,j) = y(end,15);    % default version when all activity is Ca4CaMCaN
        CaMCaN(i,j) = 0.1*sum(y(end,12:14))+y(end,15); % 10% activity to CaN bound state
    end
end    
figure(1);
semilogx(CaRange,100/CaNtot.*CaMCaN(1,:)); 
xlabel('[Ca] (\muM)'); ylabel('CaMCaN'); 
axis([0.1 10 0 100])
hold on;
load '.\model validation data\stemmer_klee19940p03CaMCaN.dat';
semilogx(stemmer_klee19940p03CaMCaN(:,1),100.*stemmer_klee19940p03CaMCaN(:,2),'bo');
semilogx(CaRange,100/CaNtot.*CaMCaN(2,:));
load '.\model validation data\stemmer_klee19940p3CaMCaN.dat';
semilogx(stemmer_klee19940p3CaMCaN(:,1),100.*stemmer_klee19940p3CaMCaN(:,2),'bo');
semilogx(CaRange,100/CaNtot.*CaMCaN(3,:));
load '.\model validation data\stemmer_klee19943CaMCaN.dat';
semilogx(stemmer_klee19943CaMCaN(:,1),100.*stemmer_klee19943CaMCaN(:,2),'bo');
% semilogx(CaRange,100/CaNtot.*CaMCaN(4,:));
% load '.\model validation data\stemmer_klee199420CaMCaN.dat';
% semilogx(stemmer_klee199420CaMCaN(:,1),100.*stemmer_klee199420CaMCaN(:,2),'bo');
% legend('Model','Expt');
hold off;


%% Run for a single simulation starting from zero state for testing time
% constant of CaN activation
% parameters
% status- works fine with camODEfile_20080429.m
clear all;
K = 135; % [mM]
Mg = 1;  % [mM]
CaMtot = 5.4;    % [uM]
Etot = 0;   % [uM]
CaNtot = 3e-3; % [uM]
p = [K, Mg, CaMtot, Etot, 0, CaNtot, 0,0,0,0];
tspan = [0 1e8];
y0 = [CaMtot,zeros(1,14)];

options = odeset('RelTol',1e-5);
Ca = [.0745,.144,.234,.383,.4,.490,.595];
for i = 1:length(Ca)
    p(8) = Ca(i);
    [t,y] = ode15s(@camODEfile_20080429,tspan,y0,options,p);
    CaNact = 100/3e-3*(y(:,15) + 0.1*(y(:,12)+y(:,13)+y(:,14)));
    CaNactf(i) = CaNact(end);
    disp(['Run ',int2str(i)]);
end
subplot(1,2,1); plot(t./60e3,CaNact);
ylabel('CaN activity'); xlabel('time (min)'); 
subplot(1,2,2); 
plot(Ca,CaNactf); xlabel('Ca (\muM)'); ylabel('CaN activity (%)');

%% Run for testing CaM buffer kinetics
% replicating part of Xu Wu Cell Calcium Fig 8
% uses a special 'bufferKinetics' odefile where [CaM] is fixed at 60 nM < t, then 14
% nM afterwards

K = 135; % [mM]
Mg = 1;  % [mM]
CaMtot = 6;    % [uM]
Etot = 26;   % [uM]
p = [K, Mg, CaMtot, Etot, zeros(1,6)];
y0 = [CaMtot,zeros(1,14)];
options = odeset('RelTol',1e-5);
tspan = [0 100*60e3];
[t,y] = ode15s(@camODEfile_bufferKinetics20080429,tspan,y0,options,p); 
CaMbuff = y(:,4)+y(:,5)+y(:,6);

line(t./60e3,CaMbuff,'Color','k');
xlabel('Time (min)'); ylabel('Model: buffered CaM (\muM)');
ax1 = gca;
set(ax1,'XColor','k','YColor','k')
ax2 = axes('Position',get(ax1,'Position'),...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k','YColor','k','XTick',[]);
load '.\model validation data\wu_cellcalcium2006.dat';
line(wu_cellcalcium2006(:,1),wu_cellcalcium2006(:,2),'Color','k','Parent',ax2);
ylabel('Expt: fluorescent CaM (a.u.)');