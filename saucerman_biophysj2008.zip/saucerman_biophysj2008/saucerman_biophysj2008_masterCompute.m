function yfinal = saucerman_biophysj2008_masterCompute
% This function calls the ode solver and plots results.
% Dependency: saucerman_biophysj2008_masterODEfile.m
%
% Author: Jeff Saucerman <jsaucerman@virginia.edu>
% Copyright 2008, University of Virginia, All Rights Reserved
%
% Reference: JJ Saucerman and BM Bers, Calmodulin mediates differential
% sensitivity of CaMKII and calcineurin to local Ca2+ in cardiac myocytes. 
% Biophys J. 2008 Aug 8. [Epub ahead of print] 
% Please cite the above paper when using this model.

clear all;
%% Parameters
cycleLength = 1e3/1;
CaMtotDyad = 418;           % [uM]
BtotDyad = 1.54/8.293e-4;   % [uM]
CaMKIItotDyad = 120;        % [uM] 
CaNtotDyad = 3e-3/8.293e-4; % [uM] 
PP1totDyad = 96.5;          % [uM]
CaMtotSL = 5.65;            % [uM]
BtotSL = 24.2;              % [uM]
CaMKIItotSL = 120*8.293e-4; % [uM]
CaNtotSL = 3e-3;            % [uM]
PP1totSL = 0.57;            % [uM]
CaMtotCyt = 5.65;           % [uM]
BtotCyt = 24.2;             % [uM]
CaMKIItotCyt = 120*8.293e-4;% [uM]
CaNtotCyt = 3e-3;           % [uM] 
PP1totCyt = 0.57;           % [uM]
p = [cycleLength,CaMtotDyad,BtotDyad,CaMKIItotDyad,CaNtotDyad,PP1totDyad,...
    CaMtotSL,BtotSL,CaMKIItotSL,CaNtotSL,PP1totSL,...
    CaMtotCyt,BtotCyt,CaMKIItotCyt,CaNtotCyt,PP1totCyt];

%% Run single simulation
y0=load('yfinal1Hz.dat');
tspan = [0 5e3]; % [ms]
options = odeset('RelTol',1e-5,'MaxStep',2); 
[t,y] = ode15s(@saucerman_biophysj2008_masterODEfile,tspan,y0,options,p);
yfinal = y(end,:)';
save -ascii 'yfinal.dat' yfinal

%% Plot Ca4CaM, CaMKII, and CaN timecourses
ts = t/1e3; 
CaMcyt = y(:,46+30+1)+y(:,46+30+2)+y(:,46+30+3);
CaNcyt = 100/3e-3*(y(:,46+15+30) + 0.1*(y(:,46+12+30)+y(:,46+13+30)+y(:,46+14+30)));
CaMKIIcyt = 100.*(y(:,46+30+8)+y(:,46+30+9)+y(:,46+30+10)+y(:,46+30+11));
CaMdyad = y(:,46+1)+y(:,46+2)+y(:,46+3);
CaNdyad = 100/3e-3*8.293e-4*(y(:,46+15) + 0.1*(y(:,46+12)+y(:,46+13)+y(:,46+14)));
CaMKIIdyad = 100.*(y(:,46+8)+y(:,46+9)+y(:,46+10)+y(:,46+11));

figure(1);
subplot(1,2,1); plot(ts,1e6*y(:,46+30+3));
xlabel('Time (sec)'); ylabel('Cytosolic Ca_4CaM (pM)');
subplot(1,2,2); plot(ts,y(:,46+3));
xlabel('Time (sec)'); ylabel('Dyadic Ca_4CaM (\muM)');
figure(2);
subplot(1,2,1); plot(ts,CaMKIIcyt);
xlabel('Time (sec)'); ylabel('Cytosolic CaMKII activity (%)');
subplot(1,2,2); plot(ts,CaMKIIdyad);
xlabel('Time (sec)'); ylabel('Dyadic CaMKII activity (%)');
figure(3);
subplot(1,2,1); plot(ts,CaNcyt);
xlabel('Time (sec)'); ylabel('Cytosolic CaN activity (%)');
subplot(1,2,2); plot(ts,CaNdyad);
xlabel('Time (sec)'); ylabel('Dyadic CaN activity (%)');