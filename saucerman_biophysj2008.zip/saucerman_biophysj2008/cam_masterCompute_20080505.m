function yfinal = cam_masterCompute
clear all;
tic
%% Parameters
cycleLength = 1e3/1;
CaMtotDyad = 0;    % [uM]418
BtotDyad = 1.54/8.293e-4;
CaMKIItotDyad = 120;  % [uM] 120
CaNtotDyad = 3e-3/8.293e-4; % [uM] 3e-3/8.293e-4
PP1totDyad = 96.5; % [uM]
CaMtotSL = 6;    % [uM]5.65
BtotSL = 24.46;    % 24.2
CaMKIItotSL = 120*8.293e-4;  % [uM] 120*8.293e-4
CaNtotSL = 3e-3; % [uM] 3e-3
PP1totSL = 0.57; % [uM]
CaMtotCyt = 6;    % [uM]5.65
BtotCyt = 24.46;    % 24.2
CaMKIItotCyt = 120*8.293e-4;  % [uM] 120*8.293e-4
CaNtotCyt = 3e-3; % [uM] 3e-3
PP1totCyt = 0.57; % [uM]
p = [cycleLength,CaMtotDyad,BtotDyad,CaMKIItotDyad,CaNtotDyad,PP1totDyad,...
    CaMtotSL,BtotSL,CaMKIItotSL,CaNtotSL,PP1totSL,...
    CaMtotCyt,BtotCyt,CaMKIItotCyt,CaNtotCyt,PP1totCyt];
%Run for a single simulation
% y0cam = load('cam_masterICs_rest_20080501.dat');
% y0old = load('cam_masterICs_1Hz_20071210.dat');
% y0 = [y0old(1:46);y0cam(47:end)];
% y0=load('longrunIC_1Hzfast_20080502.dat');
% y0 = load('yfinal.dat');
% y0(46+13+3:46+13+5)=0; % set CaM buffer IC's to zero in some simulations
% y0(46+13) = 3e-3/8.293e-4;   % set maximally activated CaN in the cleft in some simulations
% % % y0(46+9+6) = 3e-4;          % set increased cytosolic CaMKII IC reversed affinity simulations
% y0(46+13+13) = 0.75*3e-3;     % set active CaN initial condition

%% Run single simulation
tic
y0=load('longrunIC_1Hz_20080505.dat');
tspan = [0 5*60e3];
options = odeset('RelTol',1e-5,'MaxStep',2); 
[t,y] = ode15s(@cam_masterODEfile_20080501,tspan,y0,options,p);
yfinal = y(end,:)';
% save -ascii 'yfinalnoE1Hz.dat' yfinal
ts = t/1e3; 
CaMcyt = y(:,46+30+1)+y(:,46+30+2)+y(:,46+30+3);
CaNcyt = 100/3e-3*(y(:,46+15+30) + 0.1*(y(:,46+12+30)+y(:,46+13+30)+y(:,46+14+30)));
CaMKIIcyt = 100.*(y(:,46+30+8)+y(:,46+30+9)+y(:,46+30+10)+y(:,46+30+11));
CaMdyad = y(:,46+1)+y(:,46+2)+y(:,46+3);
CaNdyad = 100/3e-3*8.293e-4*(y(:,46+15) + 0.1*(y(:,46+12)+y(:,46+13)+y(:,46+14)));
CaMKIIdyad = 100.*(y(:,46+8)+y(:,46+9)+y(:,46+10)+y(:,46+11));
toc
% figure(1);
% subplot(1,2,1); plot(ts,1e6*y(:,46+30+3));
% xlabel('Time (sec)'); ylabel('Cytosolic Ca_4CaM (pM)');
% subplot(1,2,2); plot(ts,y(:,46+3));
% xlabel('Time (sec)'); ylabel('Dyadic Ca_4CaM (\muM)');
% figure(2);
% subplot(1,2,1); plot(ts,CaMKIIcyt);
% xlabel('Time (sec)'); ylabel('Cytosolic CaMKII activity (%)');
% subplot(1,2,2); plot(ts,CaMKIIdyad);
% xlabel('Time (sec)'); ylabel('Dyadic CaMKII activity (%)');
figure();
subplot(1,2,1); plot(ts,CaNcyt);
xlabel('Time (sec)'); ylabel('Cytosolic CaN activity (%)');
% subplot(1,2,2); plot(ts,CaNdyad);
% xlabel('Time (sec)'); ylabel('Dyadic CaN activity (%)');

% %% Run 1 and 4 Hz simulations for Figure 5 20080505
% tic
% tspan = [0 60e3];
% options = odeset('RelTol',1e-5,'MaxStep',2); 
% y0=load('longrunIC_1Hz_20080505.dat');
% [t1,y1] = ode15s(@cam_masterODEfile_20080501,tspan,y0,options,p);
% p(1) = 1e3/4;   % cycleLength
% y0=load('
% [t4,y4] = ode15s(@cam_masterODEfile_reverseAffinities20080501,tspan,y0,options,p);
% t1s = t1/1e3; t4s = t4/1e3;
% CaMKIIdyad1 = 100.*(y1(:,46+8)+y1(:,46+9)+y1(:,46+10)+y1(:,46+11));
% CaMKIIcyt1 = 100.*(y1(:,46+30+8)+y1(:,46+30+9)+y1(:,46+30+10)+y1(:,46+30+11));
% CaMKIIdyad4 = 100.*(y4(:,46+8)+y4(:,46+9)+y4(:,46+10)+y4(:,46+11));
% CaMKIIcyt4 = 100.*(y4(:,46+30+8)+y4(:,46+30+9)+y4(:,46+30+10)+y4(:,46+30+11));
% CaMKIIPdyad1 = 100.*(y1(:,46+9)+y1(:,46+10)+y1(:,46+11));
% CaMKIIPdyad4 = 100.*(y4(:,46+9)+y4(:,46+10)+y4(:,46+11));
% set(0,'DefaultLineLineWidth',2)
% figure(1); % Dyadic cleft CaMKII
% plot(t1s,CaMKIIPdyad1,'k-',t4s,CaMKIIPdyad4,'k--'); xlabel('Time (sec)'); ylabel('Dyadic CaMKII activity (%)'); legend('1 Hz','4 Hz');
% %% Run single simulation in steps
% y0=load('longrunIC_2Hz_20080505.dat');
% p(1)=1e3/2; % cycleLength
% % p(8)=0; p(13)=0; %noBuffer ALSO SET SPEED = 1E4
% options = odeset('RelTol',1e-5,'MaxStep',2);
% t = 0;
% numRuns = 60;  % 120 minutes
% for runNum = 1:numRuns
%     tic
%     tspan = [t(end) t(end)+60e3];    %60e3 Run for 1 minute intervals
%     [t,y] = ode15s(@cam_masterODEfile_noCa2CaM20080501,tspan,y0,options,p);
%     yfinal = y(end,:)';
%     exportdata(runNum,:) = [t(end),yfinal'];   % add current values of state variables to exportdata
%     y0(47:end) = yfinal(47:end);   % set IC's to be the final of the previous run 
%     save -ascii 'longrunDatanoCa2CaM2Hz_20080507.dat' exportdata;
%     save -ascii 'yfinalnoCa2CaM2Hz.dat' yfinal;
%     disp(['Run ',int2str(runNum),' of ',int2str(numRuns),' complete.']);
%     tm = t/60e3; 
%     CaNact = 100/3e-3*(y(:,46+15+30) + 0.1*(y(:,46+12+30)+y(:,46+13+30)+y(:,46+14+30)));
%     CaMcyt = y(:,46+30+1)+y(:,46+30+2)+y(:,46+30+3);
%     subplot(1,2,1); plot(tm,CaNact); xlabel('Time (sec)'); ylabel('Cytosolic CaN activity (%)');
%     subplot(1,2,2); plot(tm,CaMcyt); ylabel('Total free cytosolic CaM');
%     toc
% end
% 
% %% Plot Ca dynamics
% figure();
% tmin = t./60e3;
% plot(tmin,1e3*y(:,38),tmin,1e3*y(:,37),tmin,1e3*.1*y(:,36));
% xlabel('Time (min)'); ylabel ('Ca (\muM)'); legend('Ca_{CYT}','Ca_{SL}','0.1*Ca_{CLEFT}');

% Plot Ca2CaM and Ca4CaM in cytosolic and dyadic compartments
% 4/21: (these are all old indices, needs to be updated)
% figure(1);
% subplot(4,1,1);
% plot(t,1e3*y(:,37),t,y(:,46+13+1),t,y(:,46+13+2)); legend('Ca','Ca2CaM','Ca4CaM'); title('cytosolic');
% subplot(4,1,2);
% plot(t,1e3*y(:,36),t,y(:,46+1),t,y(:,46+2)); legend('Ca','Ca2CaM','Ca4CaM'); title('dyadic');
% 
% % Plot CaMKII activity
% subplot(4,1,3);
% plot(t./1e3,y(:,46+7),t./1e3,sum(y(:,46+8:46+10),2)); legend('Pb','Thr287P');  % dyadic CaMKII activity
% % plot(t,y(:,46+13+7),t,sum(y(:,46+13+7:10),2)); legend('Pb','Thr287P');  % cytosolic CaMKII activity
% xlabel('Time (s)');
% 
% % Plot CaN activity
% subplot(4,1,4);
% plot(t,y(:,46+13+13).*100./3e-3); ylabel('% CaN activity');  % cytosolic CaN activity
% % plot(t,y(:,46+13).*100./(3e-3/8.2923e-4)); ylabel('% CaN activity');  % dyadic CaN activity
% 
% % Plot CaM buffering states
% figure(2);
% plot(t,y(:,46+13+3),t,y(:,46+13+4),t,y(:,46+13+5)); legend('CaME','Ca2CaME','Ca4CaME');
% toc

% %% Plotting 
% Vmyo = 2.1454e-11;      % [L]
% Vdyad = 1.7790e-014;    % [L]
% VSL = 6.6013e-013;      % [L]
% CaMtotDyad = sum(y(:,46+1:46+6),2)+CaMKIItotDyad.*sum(y(:,46+7:46+10),2)+sum(y(:,46+13:46+15),2);
% CaMtotSL = sum(y(:,46+15+1:46+15+6),2)+CaMKIItotSL.*sum(y(:,46+15+7:46+15+10),2)+sum(y(:,46+15+13:46+15+15),2);
% CaMtotCyt = sum(y(:,46+15+15+1:46+15+15+6),2)+CaMKIItotCyt.*sum(y(:,46+15+15+7:46+15+15+10),2)+sum(y(:,46+15+15+13:46+15+15+15),2);
% CaMfreeDyad = sum(y(:,46+1:46+3),2);
% CaMfreeSL = sum(y(:,46+15+1:46+15+3),2);
% CaMfreeCyt = sum(y(:,46+15+15+1:46+15+15+3),2);
% tmin = t./60e3; ts = t./1e3;
% 
% figure(1); 
% subplot(1,3,1);
% plot(tmin,CaMtotCyt,tmin,CaMtotSL,tmin,CaMtotDyad);
% title('Total CaM distribution');
% ylabel('total CaM concentration (\muM)'); xlabel('Time (min)');
% legend('Cyt','SL','Dyad'); 
% subplot(1,3,2);
% % plot(tmin,CaMtotCyt,tmin,CaMtotSL*VSL/Vmyo,tmin,CaMtotDyad*Vdyad/Vmyo,tmin,CaMtotCyt+CaMtotSL*VSL/Vmyo+CaMtotDyad*Vdyad/Vmyo);
% % title('Total CaM dist.'); legend('Cyt','SL','Dyad','Total'); ylabel('total CaM concentration (\mumol/L cytosol)');
% plot(tmin,y(:,46+30+1:46+30+6)); legend('CaM','Ca2CaM','Ca4CaM','CaMB','Ca2CaMB','Ca4CaMB');
% title('Cytosolic CaM');
% subplot(1,3,3);
% plot(tmin,y(:,46+1:46+6)); legend('CaM','Ca2CaM','Ca4CaM','CaMB','Ca2CaMB','Ca4CaMB');
% title('Dyadic CaM');
% 
% figure(2); 
% plot(ts,y(:,36),ts,y(:,37),ts,y(:,38)); legend('CaDyad','CaSL','CaCyt');
% title('Ca dynamics');
% 
% figure(3);
% subplot(1,2,1); 
% plot(ts,y(:,46+8),ts,sum(y(:,46+9:46+11),2)); legend('Pb','Thr287P');
% title('dyadic CaMKII');
% subplot(1,2,2); 
% plot(ts,y(:,46+30+15).*100./3e-3); ylabel('% CaN activity'); 
% title('cytosolic CaN');