% Run file for mouse excitation-contraction coupling model
%
% Copyright 2011, Cardiac Systems Biology Lab, University of Virginia
%   JS: Jeff Saucerman  <jsaucerman@virginia.edu>
%   JY: Jason Yang      <jhyang@virginia.edu>
%
% Jason Yang
% 09/28/11

%%

% Simulation Conditions
params = mousePARAMS;
Vclampflag = 0;
params = [params Vclampflag];

% Run Simulation
load 1Hz_WT_ICs

tspan = [0 1e4];
options = odeset('MaxStep',0.5,'NonNegative',[1:30 32:103]);

% Resting Conditions
% tspan = [0 1e10];
% options = odeset('NonNegative',[1:30 32:103]);
% params(3) = 0;

% b-Adrenergic Stimulation
% params(14) = 1;

% [t,y] = ode15s(@mouseODE,tspan,y0,options,params);

% cycle-by-cycle pacing
options = odeset('MaxStep',50,'NonNegative',[1:30 32:103]);
bcl = params(4);
params = num2cell(params);
numCycles = floor((tspan(2)-tspan(1))/bcl);
t = tspan(1);
y = y0';
tic
for cycle = 1:numCycles,
    disp(['Cycle ' num2str(cycle)]); 
    [tCycle,yCycle] = ode15s(@mouseODE,[t(end) t(end)+bcl],y0,options,params);
    t = [t; tCycle(2:end)];
    y = [y; yCycle(2:end,:)];
    y0 = yCycle(end,:)';
end
toc
% y0 = y(end,:)';
% save tempICs y0;

%% Plot Outputs
figure(1)
subplot(4,2,1);
plot(t,y(:,10));
ylabel('[cAMP] (\muM)');
xlabel('time (ms)');

subplot(4,2,2);
plot(t,y(:,16));
ylabel('[PKA C]_I (\muM)');
xlabel('time (ms)');

subplot(4,2,3);
plot(t,y(:,22));
ylabel('[PKA C]_I_I (\muM)');
xlabel('time (ms)');

subplot(4,2,4);
plot(t,y(:,31));
ylabel('V (mV)');
xlabel('time (ms)');

subplot(4,2,5);
plot(t,y(:,32)*1000);
ylabel('[Ca]_i (nM)');
xlabel('time (ms)');

subplot(4,2,6);
plot(t,y(:,33));
ylabel('[Ca]_S_R (\muM)');
xlabel('time (ms)');

subplot(4,2,7);
plot(t,y(:,34)/1000);
ylabel('[K]_i (mM)');
xlabel('time (ms)');

subplot(4,2,8);
plot(t,y(:,35)/1000);
ylabel('[Na]_i (mM)');
xlabel('time (ms)');