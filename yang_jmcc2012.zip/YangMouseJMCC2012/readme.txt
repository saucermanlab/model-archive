Integrated mouse excitation-contraction coupling model as described in

"Phospholemman is a Negative Feed-Forward Regulator of Ca2+ in �-Adrenergic
 Signaling, Accelerating �-Adrenergic Inotropy"

Copyright 2012, Cardiac Systems Biology Lab, University of Virginia
  JS: Jeff Saucerman  <jsaucerman@virginia.edu>
  JY: Jason Yang      <jhyang@virginia.edu>

Matlab v. 2011a

Revision History:
v. 1.03 (03/06/2013)
v. 1.02 (12/11/2012)
v. 1.01 (06/25/2012)
v. 1.00 (11/20/2011)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

The following files are included in this supplement:
  mouseCompute.m - master run file
  mouseODE.m - ODE file for integrated model
  mousePARAMS.m - parameters file for integrated model
  rest_WT_ICs.mat - initial conditions file for WT model at rest
  1Hz_WT_ICs.mat - initial conditions file for WT model, 1 Hz pacing
  1Hz_WT_ISO_ICs.mat - initial conditions file for WT model, 1 Hz pacing, 1 uM ISO

Usage:
  Select an initial conditions file and save to tempICs. eg., At command window,
  execute "load 1Hz_WT_ICs.mat; save tempICs y0;".

  To run the model, execute "mouseCompute".  Simulation conditions are 
  specified in the compute file.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Revision Notes:

v. 1.03 (JS, 03/06/2013)
- Changed mouseCompute.m to simulate cycle-by-cycle, allowing larger MaxStep
- Eliminated num2cell calls in mouseODE.m, which was taking bulk of time.

v. 1.02 (JY, 12/11/12)
- Corrected bug on line 90 of mouseODE.m regarding dLR/dt
- Adjusted effects of PKA phosphorylation on LCC (lines 220, 240), PLB (line 523),
  PLM (line 573) and TnI (line 204).

v. 1.01 (JY, 06/25/12)
- Corrected bug on line 92 of mouseODE.m regarding dRG/dt
- The Hill coefficient on line 575 for INaK Na+ sensitivity should be 2.8 instead 
  of 3.2. However, this adjustment will require refitting model parameters 
  to the extensive mouse ec-coupling literature. Because the Hill coefficient in
  the current model is similar to the experimentally reported value and the current
  model adequately captures whole-cell Ca2+ and Na+ dynamics, these adjustments are
  reserved for a future revision to the model.