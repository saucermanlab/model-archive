function dydt = mouseODE(t,y,params)

% ODE for mouse excitation-contraction coupling model
% dydt = mouseODE(t,y,params)
%
% Copyright 2013, Cardiac Systems Biology Lab, University of Virginia
%   JS: Jeff Saucerman  <jsaucerman@virginia.edu>
%   JY: Jason Yang      <jhyang@virginia.edu>
%
% Jason Yang
% 09/28/11
% 
% Revisions:
%   v1.01 JY, corrected bug on dRG:
%           dRG = kf_RG*b1AR*Gs - kr_RG*RG - k_G_act*RG;
%   v1.02 JY, corrected bug on dLR:
%           dLR = kf_LR*ISO*b1AR - kr_LR*LR + kr_LRG*LRG - kf_LRG*LR*Gs;
%   v1.03 JS, changed mouseCompute and mouseODE to run faster (40% of original time)

%% Assign Parameters and State Variables
[F RT_over_F Istimmax bcl Cm Csa Vmyo VSR VSS ...
  Cao Ko Nao Mgi ...
  ISO FSK IBMX ...
  b1ARtot kf_LR kf_LRG kf_RG kr_LR kr_LRG kr_RG ...
  Gstot k_G_act k_G_hyd k_G_reassoc ...
  kf_bARK kr_bARK kf_PKA kr_PKA ...
  ACtot ATP k_AC_basal Km_AC_basal ...
  kf_AC_Gsa kr_AC_Gsa k_AC_Gsa Km_AC_Gsa ...
  Kd_AC_FSK k_AC_FSK Km_AC_FSK ...
  PDEtot k_cAMP_PDE k_cAMP_PDEp Km_PDE_cAMP ...
  Kd_PDE_IBMX k_PKA_PDE k_PP_PDE ...
  PKAIItot PKItot ...
  kf_RC_cAMP kf_RCcAMP_cAMP kf_RcAMPcAMP_C kf_PKA_PKI ...
  kr_RC_cAMP kr_RCcAMP_cAMP kr_RcAMPcAMP_C kr_PKA_PKI ...
  epsilon ...
  PP1tot I1tot k_PKA_I1 Km_PKA_I1 Vmax_PP2A_I1 Km_PP2A_I1 ...
  kf_PP1_I1 kr_PP1_I1 ...
  LCCtot PKACII_LCCtot PP1_LCC PP2A_LCC ...
  k_PKA_LCC Km_PKA_LCC k_PP1_LCC Km_PP1_LCC k_PP2A_LCC Km_PP2A_LCC ...
  PLBtot k_PKA_PLB Km_PKA_PLB k_PP1_PLB Km_PP1_PLB ...
  PLMtot k_PKA_PLM Km_PKA_PLM k_PP1_PLM Km_PP1_PLM ...
  TnItot PP2A_TnI k_PKA_TnI Km_PKA_TnI k_PP2A_TnI Km_PP2A_TnI ...
  CaMtot TnCLtot TnCHtot Myosintot CSQNtot ...
  CaSRbtot CaSLtot CaSLhtot CaATPtot CaPCrtot ...
  kon_CaM koff_CaM kon_TnCL koff_TnCL kon_TnCHCa koff_TnCHCa ...
  kon_TnCHMg koff_TnCHMg kon_MyosinCa koff_MyosinCa ...
  kon_MyosinMg koff_MyosinMg ...
  kon_CaSRb koff_CaSRb kon_CaSL koff_CaSL kon_CaSLh koff_CaSLh ...
  kon_CaATP koff_CaATP kon_CaPCr koff_CaPCr ...
  Ki_MgATP Km_CSQN ...
  NCaRU PCaL r_xfer JRyRmax fL aL bL gammaL omegaL ...
  k12 k21 k23 k32 k34 k43 k45 k54 k56 k65 k25 k52 ...
  SRmax SRmin SREC50 SRH r_leak ...
  g_ICab Vmax_NaCa KmNai_NaCa KmCai_NaCa KmCao_NaCa ksat_NaCa eta_NaCa ...
  IpCamax Km_IpCa Kfb Krb N vmax ...
  g_INa g_INab INaKmax Km_Nai Km_Ko ...
  g_IKtof g_IKss g_IKs IKr_kb IKr_kf g_IKr g_IKur ...
  Vclampflag] = params{:};

% yCell = num2cell(y);
% [LR LRG RG b1AR_S464 b1AR_S301 ...
%   GsaGTPtot GsaGDP Gsby AC_GsaGTP cAMPtot PDEp ...
%   RC_I RCcAMP_I RCcAMPcAMP_I RcAMPcAMP_I PKACI PKACI_PKI ...
%   RC_II RCcAMP_II RCcAMPcAMP_II RcAMPcAMP_II PKACII PKACII_PKI ...
%   I1p_PP1 I1ptot LCCap LCCbp PLBp PLMp TnIp ...
%   V Cai CaSR Ki Nai ...
%   CNa1 CNa2 IFNa INa1 INa2 ICNa2 ICNa3 ONa ...
%   atof itof ...
%   aKss nKs ...
%   CK1 CK2 IK OK aur iur...
%   TnCLCa TnCHCa TnCHMg MyosinCa MyosinMg CaMCa ...
%   CaSRb CaSL CaSLh CaATP CaPCr ...
%   LCCRyR1 LCCRyR2 LCCRyR3 LCCRyR4 LCCRyR5 LCCRyR6 LCCRyR7 LCCRyR8 ...
%   LCCRyR9 LCCRyR10 LCCRyR11 LCCRyR12 LCCRyR13 LCCRyR14 LCCRyR15 ...
%   LCCRyR16 LCCRyR17 LCCRyR18 LCCRyR19 LCCRyR20 LCCRyR21 LCCRyR22 ...
%   LCCRyR23 LCCRyR24 LCCRyR25 LCCRyR26 LCCRyR27 LCCRyR28 LCCRyR29 ...
%   LCCRyR30 LCCRyR31 LCCRyR32 LCCRyR33 LCCRyR34 LCCRyR35 LCCRyR36 ...
%   LCCRyR37 LCCRyR38 LCCRyR39 ...
%   ]=yCell{:};
LR = y(1);
LRG = y(2);
RG = y(3);
b1AR_S464 = y(4);
b1AR_S301 = y(5);
GsaGTPtot = y(6);
GsaGDP = y(7);
Gsby = y(8);
AC_GsaGTP = y(9);
cAMPtot = y(10);
PDEp = y(11);
RC_I = y(12);
RCcAMP_I = y(13);
RCcAMPcAMP_I = y(14);
RcAMPcAMP_I = y(15);
PKACI = y(16);
PKACI_PKI = y(17);
RC_II = y(18);
RCcAMP_II = y(19);
RCcAMPcAMP_II = y(20);
RcAMPcAMP_II = y(21);
PKACII = y(22);
PKACII_PKI = y(23);
I1p_PP1 = y(24);
I1ptot = y(25);
LCCap = y(26);
LCCbp = y(27);
PLBp = y(28);
PLMp = y(29);
TnIp = y(30);
V = y(31);
Cai = y(32);
CaSR = y(33);
Ki = y(34);
Nai = y(35);
CNa1 = y(36);
CNa2 = y(37);
IFNa = y(38);
INa1 = y(39);
INa2 = y(40);
ICNa2 = y(41);
ICNa3 = y(42); 
ONa = y(43);
atof = y(44);
itof = y(45);
aKss = y(46);
nKs = y(47);
CK1 = y(48);
CK2 = y(49);
IK = y(50);
OK = y(51);
aur = y(52);
iur = y(53);
TnCLCa = y(54);
TnCHCa = y(55);
TnCHMg = y(56);
MyosinCa = y(57);
MyosinMg = y(58);
CaMCa = y(59);
CaSRb = y(60);
CaSL = y(61);
CaSLh = y(62);
CaATP = y(63);
CaPCr = y(64);
LCCRyR1 = y(65);
LCCRyR2 = y(66);
LCCRyR3 = y(67);
LCCRyR4 = y(68);
LCCRyR5 = y(69);
LCCRyR6 = y(70);
LCCRyR7 = y(71);
LCCRyR8 = y(72);
LCCRyR9 = y(73);
LCCRyR10 = y(74);
LCCRyR11 = y(75);
LCCRyR12 = y(76);
LCCRyR13 = y(77);
LCCRyR14 = y(78);
LCCRyR15 = y(79);
LCCRyR16 = y(80);
LCCRyR17 = y(81);
LCCRyR18 = y(82);
LCCRyR19 = y(83);
LCCRyR20 = y(84);
LCCRyR21 = y(85);
LCCRyR22 = y(86);
LCCRyR23 = y(87);
LCCRyR24 = y(88);
LCCRyR25 = y(89);
LCCRyR26 = y(90);
LCCRyR27 = y(91);
LCCRyR28 = y(92);
LCCRyR29 = y(93);
LCCRyR30 = y(94);
LCCRyR31 = y(95);
LCCRyR32 = y(96);
LCCRyR33 = y(97);
LCCRyR34 = y(98);
LCCRyR35 = y(99);
LCCRyR36 = y(100);
LCCRyR37 = y(101);
LCCRyR38 = y(102);
LCCRyR39 = y(103);

LRs = [LCCRyR1 LCCRyR2 LCCRyR3 LCCRyR4 LCCRyR5 LCCRyR6 LCCRyR7 LCCRyR8 ...
  LCCRyR9 LCCRyR10 LCCRyR11 LCCRyR12 LCCRyR13 LCCRyR14 LCCRyR15 ...
  LCCRyR16 LCCRyR17 LCCRyR18 LCCRyR19 LCCRyR20 LCCRyR21 LCCRyR22 ...
  LCCRyR23 LCCRyR24 LCCRyR25 LCCRyR26 LCCRyR27 LCCRyR28 LCCRyR29 ...
  LCCRyR30 LCCRyR31 LCCRyR32 LCCRyR33 LCCRyR34 LCCRyR35 LCCRyR36 ...
  LCCRyR37 LCCRyR38 LCCRyR39];
LCCRyR40 = 1-sum(LRs);

%% Signaling Module

% b-AR/Gs module
b1ARact = b1ARtot - b1AR_S464 - b1AR_S301;
b1AR = b1ARact - LR - LRG - RG;
Gs = Gstot - LRG - RG - Gsby;

dLR = kf_LR*ISO*b1AR - kr_LR*LR + kr_LRG*LRG - kf_LRG*LR*Gs;
dLRG = kf_LRG*LR*Gs - kr_LRG*LRG - k_G_act*LRG;
dRG = kf_RG*b1AR*Gs - kr_RG*RG - k_G_act*RG;

bARK_desens = kf_bARK*(LR+LRG);
bARK_resens = kr_bARK*b1AR_S464;
PKA_desens = kf_PKA*PKACI*b1ARact;
PKA_resens = kr_PKA*b1AR_S301;
db1AR_S464 = bARK_desens - bARK_resens;
db1AR_S301 = PKA_desens - PKA_resens;

G_act = k_G_act*(RG+LRG);
G_hyd = k_G_hyd*GsaGTPtot;
G_reassoc = k_G_reassoc*GsaGDP*Gsby;
dGsaGTPtot = G_act - G_hyd;
dGsaGDP = G_hyd - G_reassoc;
dGsby = G_act - G_reassoc;

% cAMP module
cAMP = cAMPtot - (RCcAMP_I+2*RCcAMPcAMP_I+2*RcAMPcAMP_I) - (RCcAMP_II+2*RCcAMPcAMP_II+2*RcAMPcAMP_II);
AC = ACtot-AC_GsaGTP;
GsaGTP = GsaGTPtot - AC_GsaGTP;
dAC_GsaGTP = kf_AC_Gsa*GsaGTP*AC - kr_AC_Gsa*AC_GsaGTP;

AC_FSK = FSK*AC/Kd_AC_FSK;
AC_ACT_BASAL = k_AC_basal*AC*ATP/(Km_AC_basal+ATP);
AC_ACT_GSA = k_AC_Gsa*AC_GsaGTP*ATP/(Km_AC_Gsa+ATP);
AC_ACT_FSK = k_AC_FSK*AC_FSK*ATP/(Km_AC_FSK+ATP);

PDE_IBMX = PDEtot*IBMX/Kd_PDE_IBMX;
PDE = PDEtot - PDE_IBMX - PDEp;
dPDEp = k_PKA_PDE*PKACII*PDE - k_PP_PDE*PDEp;
PDE_ACT = k_cAMP_PDE*PDE*cAMP/(Km_PDE_cAMP+cAMP) + k_cAMP_PDEp*PDEp*cAMP/(Km_PDE_cAMP+cAMP);

dcAMPtot = AC_ACT_BASAL + AC_ACT_GSA + AC_ACT_FSK - PDE_ACT;

% PKA module
PKI = PKItot - PKACI_PKI - PKACII_PKI;

dRC_I = - kf_RC_cAMP*RC_I*cAMP + kr_RC_cAMP*RCcAMP_I;
dRCcAMP_I = - kr_RC_cAMP*RCcAMP_I + kf_RC_cAMP*RC_I*cAMP - kf_RCcAMP_cAMP*RCcAMP_I*cAMP + kr_RCcAMP_cAMP*RCcAMPcAMP_I;
dRCcAMPcAMP_I = - kr_RCcAMP_cAMP*RCcAMPcAMP_I + kf_RCcAMP_cAMP*RCcAMP_I*cAMP - kf_RcAMPcAMP_C*RCcAMPcAMP_I + kr_RcAMPcAMP_C*RcAMPcAMP_I*PKACI;
dRcAMPcAMP_I = - kr_RcAMPcAMP_C*RcAMPcAMP_I*PKACI + kf_RcAMPcAMP_C*RCcAMPcAMP_I;
dPKACI = - kr_RcAMPcAMP_C*RcAMPcAMP_I*PKACI + kf_RcAMPcAMP_C*RCcAMPcAMP_I - kf_PKA_PKI*PKACI*PKI + kr_PKA_PKI*PKACI_PKI;
dPKACI_PKI = - kr_PKA_PKI*PKACI_PKI + kf_PKA_PKI*PKACI*PKI;

dRC_II = - kf_RC_cAMP*RC_II*cAMP + kr_RC_cAMP*RCcAMP_II;
dRCcAMP_II = - kr_RC_cAMP*RCcAMP_II + kf_RC_cAMP*RC_II*cAMP - kf_RCcAMP_cAMP*RCcAMP_II*cAMP + kr_RCcAMP_cAMP*RCcAMPcAMP_II;
dRCcAMPcAMP_II = - kr_RCcAMP_cAMP*RCcAMPcAMP_II + kf_RCcAMP_cAMP*RCcAMP_II*cAMP - kf_RcAMPcAMP_C*RCcAMPcAMP_II + kr_RcAMPcAMP_C*RcAMPcAMP_II*PKACII;
dRcAMPcAMP_II = - kr_RcAMPcAMP_C*RcAMPcAMP_II*PKACII + kf_RcAMPcAMP_C*RCcAMPcAMP_II;
dPKACII = - kr_RcAMPcAMP_C*RcAMPcAMP_II*PKACII + kf_RcAMPcAMP_C*RCcAMPcAMP_II - kf_PKA_PKI*PKACII*PKI + kr_PKA_PKI*PKACII_PKI;
dPKACII_PKI = - kr_PKA_PKI*PKACII_PKI + kf_PKA_PKI*PKACII*PKI;

% I-1/PP1 module
I1 = I1tot - I1ptot;
PP1 = PP1tot - I1p_PP1;
I1p = I1ptot - I1p_PP1;
I1_phosph = k_PKA_I1*PKACI*I1/(Km_PKA_I1+I1);
I1_dephosph = Vmax_PP2A_I1*I1ptot/(Km_PP2A_I1+I1ptot);

dI1p_PP1 = kf_PP1_I1*PP1*I1p - kr_PP1_I1*I1p_PP1;
dI1ptot = I1_phosph - I1_dephosph;

% LCC module
PKACII_LCC = (PKACII_LCCtot/PKAIItot)*PKACII;
LCCa = LCCtot - LCCap;
LCCa_phosph = epsilon*k_PKA_LCC*PKACII_LCC*LCCa/(Km_PKA_LCC+epsilon*LCCa);
LCCa_dephosph = epsilon*k_PP2A_LCC*PP2A_LCC*LCCap/(Km_PP2A_LCC+epsilon*LCCap);
dLCCap = LCCa_phosph - LCCa_dephosph;

LCCb = LCCtot - LCCbp;
LCCb_phosph = epsilon*k_PKA_LCC*PKACII_LCC*LCCb/(Km_PKA_LCC+epsilon*LCCb);
LCCb_dephosph = epsilon*k_PP1_LCC*PP1_LCC*LCCbp/(Km_PP1_LCC+epsilon*LCCbp);
dLCCbp = LCCb_phosph - LCCb_dephosph;

% PLB module
PLB = PLBtot - PLBp;
PLB_phosph = k_PKA_PLB*PKACI*PLB/(Km_PKA_PLB+PLB);
PLB_dephosph = k_PP1_PLB*PP1*PLBp/(Km_PP1_PLB+PLBp);
dPLBp = PLB_phosph - PLB_dephosph;

% PLM module
PLM = PLMtot - PLMp;
PLM_phosph = k_PKA_PLM*PKACI*PLM/(Km_PKA_PLM+PLM);
PLM_dephosph = k_PP1_PLM*PP1*PLMp/(Km_PP1_PLM+PLMp);
dPLMp = PLM_phosph - PLM_dephosph;

% TnI module
TnI = TnItot - TnIp;
TnI_phosph = k_PKA_TnI*PKACI*TnI/(Km_PKA_TnI+TnI);
TnI_dephosph = k_PP2A_TnI*PP2A_TnI*TnIp/(Km_PP2A_TnI+TnIp);
dTnIp = TnI_phosph - TnI_dephosph;

%% Voltage/Concentration-Dependent Parameters

% Global Parameters
VF_over_RT = V/RT_over_F;
VFsq_over_RT = F*VF_over_RT;

% Stimulating Current
if (mod(t,bcl) <= 2)
  Istim = Istimmax;
else
  Istim = 0;
end;

% Nernst Potentials
ECa = 0.5*RT_over_F*log(Cao/max(1e-10,Cai));
EK = RT_over_F*log(Ko/Ki);
ENa = RT_over_F*log(Nao/Nai);

%% Ca-Induced Ca-Release

% Ca Buffering
koff_TnCL = koff_TnCL*(0.6546*TnIp/TnItot+0.959);
dTnCLCa = kon_TnCL*Cai*(TnCLtot-TnCLCa) - koff_TnCL*TnCLCa;
dTnCHCa = kon_TnCHCa*Cai*(TnCHtot-TnCHCa-TnCHMg) - koff_TnCHCa*TnCHCa;
dTnCHMg = kon_TnCHMg*Mgi*(TnCHtot-TnCHCa-TnCHMg) - koff_TnCHMg*TnCHMg;
dMyosinCa = kon_MyosinCa*Cai*(Myosintot-MyosinCa-MyosinMg) - koff_MyosinCa*MyosinCa;
dMyosinMg = kon_MyosinMg*Mgi*(Myosintot-MyosinCa-MyosinMg) - koff_MyosinMg*MyosinMg;
dCaMCa = kon_CaM*Cai*(CaMtot-CaMCa) - koff_CaM*CaMCa;
dCaSRb = kon_CaSRb*Cai*(CaSRbtot-CaSRb) - koff_CaSRb*CaSRb;
dCaSL = kon_CaSL*Cai*(CaSLtot-CaSL) - koff_CaSL*CaSL;
dCaSLh = kon_CaSLh*Cai*(CaSLhtot-CaSLh) - koff_CaSLh*CaSLh;
dCaATP = kon_CaATP*Cai*(CaATPtot-CaATP) - koff_CaATP*(1+Mgi/Ki_MgATP)*CaATP;
dCaPCr = kon_CaPCr*Cai*(CaPCrtot-CaPCr) - koff_CaPCr*CaPCr;

CaBSR = 1/(1+CSQNtot*Km_CSQN/(Km_CSQN+CaSR)^2);

% Local Ca Concentrations for Subspace Ca Release Unit Populations
PCaL = (2.0364*LCCbp/LCCtot+0.4896)*PCaL;

CaSS1 = (r_leak*CaSR+r_xfer*Cai)/(r_leak+r_xfer);
CaSS2 = (PCaL*2*VF_over_RT/VSS*0.341*Cao/(exp(2*VF_over_RT)-1) ...
  + r_leak*CaSR + r_xfer*Cai) ...
  / (PCaL*2*VF_over_RT/VSS/(1-exp(-2*VF_over_RT)) + r_leak + r_xfer);
CaSS3 = ((JRyRmax+r_leak)*CaSR + r_xfer*Cai)/(JRyRmax + r_leak + r_xfer);
CaSS4 = (PCaL*2*VF_over_RT/VSS*0.341*Cao/(exp(2*VF_over_RT)-1) ...
  + (JRyRmax+r_leak)*CaSR + r_xfer*Cai) / (PCaL*2*VF_over_RT/VSS/ ...
  (1-exp(-2*VF_over_RT)) + JRyRmax + r_leak + r_xfer);

% Parameters
alphaL = 0.835399*exp(0.0269241*(V-35));
betaL =  0.0331584*exp(-0.0934594*(V-35));

yCainf = 0.95/(1+exp((V+25)/5))+0.05;
tauyCa = (340/(1+exp((V+30)/12)) + 60);
kby = yCainf/tauyCa;
kfy = (1 - yCainf)/tauyCa;

fMode1 = -0.6431*LCCap/LCCtot + 1.1412;
gL = (0.545455+0.161214*fMode1)./(0.5454555-0.189663*fMode1);

% Rate Constant Assignments
LCC_12 = alphaL;
LCC_21 = betaL;
LCC_23 = fL;
LCC_32 = gL;
LCC_14_CaSS1 = gammaL*CaSS1;
LCC_14_CaSS3 = gammaL*CaSS3;
LCC_41 = omegaL;
LCC_45 = aL*alphaL;
LCC_54 = betaL/bL;
LCC_25_CaSS1 = aL*gammaL*CaSS1;
LCC_25_CaSS3 = aL*gammaL*CaSS3;
LCC_52 = omegaL/bL;

LCC_67 = alphaL;
LCC_76 = betaL;
LCC_78 = fL;
LCC_87 = gL;
LCC_69_CaSS1 = gammaL*CaSS1;
LCC_69_CaSS3 = gammaL*CaSS3;
LCC_96 = omegaL;
LCC_910 = aL*alphaL;
LCC_109 = betaL/bL;
LCC_710_CaSS1 = aL*gammaL*CaSS1;
LCC_710_CaSS3 = aL*gammaL*CaSS3;
LCC_107 = omegaL/bL;

LCC_16 = kfy;
LCC_27 = kfy;
LCC_38 = kfy;
LCC_49 = kfy;
LCC_510 = kfy;
LCC_61 = kby;
LCC_72 = kby;
LCC_83 = kby;
LCC_94 = kby;
LCC_105 = kby;

klumen = SRmax - (SRmax-SRmin)/(1+(SREC50/CaSR)^SRH);
k12 = k12*klumen;
k23 = k23*klumen;
k54 = k54*klumen;
k25 = k25/klumen;
k45 = k45/klumen;

RyR_12_CaSS1 = k12*CaSS1^2;
RyR_12_CaSS2 = k12*CaSS2^2;
RyR_21 = k21;
RyR_23_CaSS1 = k23*CaSS1^2;
RyR_23_CaSS2 = k23*CaSS2^2;
RyR_32_CaSS3 = k32*k43/(k34*CaSS3^2 + k43);
RyR_32_CaSS4 = k32*k43/(k34*CaSS4^2 + k43);
RyR_24_CaSS1 = k25*CaSS1^2;
RyR_24_CaSS2 = k25*CaSS2^2;
RyR_42_CaSS1 = k52*k65/(k56*CaSS1^2 + k65);
RyR_42_CaSS2 = k52*k65/(k56*CaSS2^2 + k65);
RyR_34_CaSS3 = k45*k34*CaSS3^2/(k34*CaSS3^2 + k43);
RyR_34_CaSS4 = k45*k34*CaSS4^2/(k34*CaSS4^2 + k43);
RyR_43_CaSS1 = k65*k54*CaSS1^2/(k56*CaSS1^2 + k65);
RyR_43_CaSS2 = k65*k54*CaSS2^2/(k56*CaSS2^2 + k65);

% State Derivatives for Coupled LCC-RyR Model
dLCCRyR1 = -LCC_12*LCCRyR1 +LCC_21*LCCRyR2 ...
  -LCC_14_CaSS1*LCCRyR1 +LCC_41*LCCRyR4 -LCC_16*LCCRyR1 ...
  +LCC_61*LCCRyR6 -RyR_12_CaSS1*LCCRyR1 +RyR_21*LCCRyR11;
dLCCRyR2 = +LCC_12*LCCRyR1 -LCC_21*LCCRyR2 -LCC_23*LCCRyR2 ...
  +LCC_32*LCCRyR3 -LCC_25_CaSS1*LCCRyR2 +LCC_52*LCCRyR5 ...
  -LCC_27*LCCRyR2 +LCC_72*LCCRyR7 -RyR_12_CaSS1*LCCRyR2 ...
  +RyR_21*LCCRyR12;
dLCCRyR3 = +LCC_23*LCCRyR2 -LCC_32*LCCRyR3 -LCC_38*LCCRyR3 ...
  +LCC_83*LCCRyR8 -RyR_12_CaSS2*LCCRyR3 +RyR_21*LCCRyR13;
dLCCRyR4 = +LCC_14_CaSS1*LCCRyR1 -LCC_41*LCCRyR4 ...
  -LCC_45*LCCRyR4 +LCC_54*LCCRyR5 -LCC_49*LCCRyR4 ...
  +LCC_94*LCCRyR9 -RyR_12_CaSS1*LCCRyR4 +RyR_21*LCCRyR14;
dLCCRyR5 = +LCC_25_CaSS1*LCCRyR2 -LCC_52*LCCRyR5 ...
  +LCC_45*LCCRyR4 -LCC_54*LCCRyR5 -LCC_510*LCCRyR5 ...
  +LCC_105*LCCRyR10 -RyR_12_CaSS1*LCCRyR5 +RyR_21*LCCRyR15;
dLCCRyR6 = +LCC_16*LCCRyR1 -LCC_61*LCCRyR6 -LCC_67*LCCRyR6 ...
  +LCC_76*LCCRyR7 -LCC_69_CaSS1*LCCRyR6 +LCC_96*LCCRyR9 ...
  -RyR_12_CaSS1*LCCRyR6 +RyR_21*LCCRyR16;
dLCCRyR7 = +LCC_27*LCCRyR2 -LCC_72*LCCRyR7 +LCC_67*LCCRyR6 ...
  -LCC_76*LCCRyR7 -LCC_78*LCCRyR7 +LCC_87*LCCRyR8 ...
  -LCC_710_CaSS1*LCCRyR7 +LCC_107*LCCRyR10 ...
  -RyR_12_CaSS1*LCCRyR7 +RyR_21*LCCRyR17;
dLCCRyR8 = +LCC_38*LCCRyR3 -LCC_83*LCCRyR8 +LCC_78*LCCRyR7 ...
  -LCC_87*LCCRyR8 -RyR_12_CaSS1*LCCRyR8 +RyR_21*LCCRyR18;
dLCCRyR9 = +LCC_49*LCCRyR4 -LCC_94*LCCRyR9 ...
  +LCC_69_CaSS1*LCCRyR6 -LCC_96*LCCRyR9 -LCC_910*LCCRyR9 ...
  +LCC_109*LCCRyR10 -RyR_12_CaSS1*LCCRyR9 +RyR_21*LCCRyR19;
dLCCRyR10 = +LCC_510*LCCRyR5 -LCC_105*LCCRyR10 ...
  +LCC_710_CaSS1*LCCRyR7 -LCC_107*LCCRyR10 ...
  +LCC_910*LCCRyR9 -LCC_109*LCCRyR10 ...
  -RyR_12_CaSS1*LCCRyR10 +RyR_21*LCCRyR20;
dLCCRyR11 = +RyR_12_CaSS1*LCCRyR1 -RyR_21*LCCRyR11 ...
  -LCC_12*LCCRyR11 +LCC_21*LCCRyR12 -LCC_14_CaSS1*LCCRyR11 ...
  +LCC_41*LCCRyR14 -LCC_16*LCCRyR11 +LCC_61*LCCRyR16 ...
  -RyR_23_CaSS1*LCCRyR11 +RyR_32_CaSS3*LCCRyR21 ...
  -RyR_24_CaSS1*LCCRyR11 +RyR_42_CaSS1*LCCRyR31;
dLCCRyR12 = +RyR_12_CaSS1*LCCRyR2 -RyR_21*LCCRyR12 ...
  +LCC_12*LCCRyR11 -LCC_21*LCCRyR12 -LCC_23*LCCRyR12 ...
  +LCC_32*LCCRyR13 -LCC_25_CaSS1*LCCRyR12 +LCC_52*LCCRyR15 ...
  -LCC_27*LCCRyR12 +LCC_72*LCCRyR17 -RyR_23_CaSS1*LCCRyR12 ...
  +RyR_32_CaSS3*LCCRyR22 -RyR_24_CaSS1*LCCRyR12 ...
  +RyR_42_CaSS1*LCCRyR32;
dLCCRyR13 = +RyR_12_CaSS2*LCCRyR3 -RyR_21*LCCRyR13 ...
  +LCC_23*LCCRyR12 -LCC_32*LCCRyR13 -LCC_38*LCCRyR13 ...
  +LCC_83*LCCRyR18 -RyR_23_CaSS2*LCCRyR13 ...
  +RyR_32_CaSS4*LCCRyR23 -RyR_24_CaSS2*LCCRyR13 ...
  +RyR_42_CaSS2*LCCRyR33;
dLCCRyR14 = +RyR_12_CaSS1*LCCRyR4 -RyR_21*LCCRyR14 ...
  +LCC_14_CaSS1*LCCRyR11 -LCC_41*LCCRyR14 -LCC_45*LCCRyR14 ...
  +LCC_54*LCCRyR15 -LCC_49*LCCRyR14 +LCC_94*LCCRyR19 ...
  -RyR_23_CaSS1*LCCRyR14 +RyR_32_CaSS3*LCCRyR24 ...
  -RyR_24_CaSS1*LCCRyR14 +RyR_42_CaSS1*LCCRyR34;
dLCCRyR15 = +RyR_12_CaSS1*LCCRyR5 -RyR_21*LCCRyR15 ...
  +LCC_25_CaSS1*LCCRyR12 -LCC_52*LCCRyR15 ...
  +LCC_45*LCCRyR14 -LCC_54*LCCRyR15 -LCC_510*LCCRyR15 ...
  +LCC_105*LCCRyR20 -RyR_23_CaSS1*LCCRyR15 ...
  +RyR_32_CaSS3*LCCRyR25 -RyR_24_CaSS1*LCCRyR15 ...
  +RyR_42_CaSS1*LCCRyR35;
dLCCRyR16 = +RyR_12_CaSS1*LCCRyR6 -RyR_21*LCCRyR16 ...
  +LCC_16*LCCRyR11 -LCC_61*LCCRyR16 -LCC_67*LCCRyR16 ...
  +LCC_76*LCCRyR17 -LCC_69_CaSS1*LCCRyR16 +LCC_96*LCCRyR19 ...
  -RyR_23_CaSS1*LCCRyR16 +RyR_32_CaSS3*LCCRyR26 ...
  -RyR_24_CaSS1*LCCRyR16 +RyR_42_CaSS1*LCCRyR36;
dLCCRyR17 = +RyR_12_CaSS1*LCCRyR7 -RyR_21*LCCRyR17 ...
  +LCC_27*LCCRyR12 -LCC_72*LCCRyR17 +LCC_67*LCCRyR16 ...
  -LCC_76*LCCRyR17 -LCC_78*LCCRyR17 +LCC_87*LCCRyR18 ...
  -LCC_710_CaSS1*LCCRyR17 +LCC_107*LCCRyR20 ...
  -RyR_23_CaSS1*LCCRyR17 +RyR_32_CaSS3*LCCRyR27 ...
  -RyR_24_CaSS1*LCCRyR17 +RyR_42_CaSS1*LCCRyR37;
dLCCRyR18 = +RyR_12_CaSS1*LCCRyR8 -RyR_21*LCCRyR18 ...
  +LCC_38*LCCRyR13 -LCC_83*LCCRyR18 +LCC_78*LCCRyR17 ...
  -LCC_87*LCCRyR18 -RyR_23_CaSS1*LCCRyR18 ...
  +RyR_32_CaSS3*LCCRyR28 -RyR_24_CaSS1*LCCRyR18 ...
  +RyR_42_CaSS1*LCCRyR38;
dLCCRyR19 = +RyR_12_CaSS1*LCCRyR9 -RyR_21*LCCRyR19 ...
  +LCC_49*LCCRyR14 -LCC_94*LCCRyR19 ...
  +LCC_69_CaSS1*LCCRyR16 -LCC_96*LCCRyR19 ...
  -LCC_910*LCCRyR19 +LCC_109*LCCRyR20 ...
  -RyR_23_CaSS1*LCCRyR19 +RyR_32_CaSS3*LCCRyR29 ...
  -RyR_24_CaSS1*LCCRyR19 +RyR_42_CaSS1*LCCRyR39;
dLCCRyR20 = +RyR_12_CaSS1*LCCRyR10 -RyR_21*LCCRyR20 ...
  +LCC_510*LCCRyR15 -LCC_105*LCCRyR20 ...
  +LCC_710_CaSS1*LCCRyR17 -LCC_107*LCCRyR20 ...
  +LCC_910*LCCRyR19 -LCC_109*LCCRyR20 ...
  -RyR_23_CaSS1*LCCRyR20 +RyR_32_CaSS3*LCCRyR30 ...
  -RyR_24_CaSS1*LCCRyR20 +RyR_42_CaSS1*LCCRyR40;
dLCCRyR21 = +RyR_23_CaSS1*LCCRyR11 -RyR_32_CaSS3*LCCRyR21 ...
  -LCC_12*LCCRyR21 +LCC_21*LCCRyR22 -LCC_14_CaSS3*LCCRyR21 ...
  +LCC_41*LCCRyR24 -LCC_16*LCCRyR21 +LCC_61*LCCRyR26 ...
  -RyR_34_CaSS3*LCCRyR21 +RyR_43_CaSS1*LCCRyR31;
dLCCRyR22 = +RyR_23_CaSS1*LCCRyR12 -RyR_32_CaSS3*LCCRyR22 ...
  +LCC_12*LCCRyR21 -LCC_21*LCCRyR22 -LCC_23*LCCRyR22 ...
  +LCC_32*LCCRyR23 -LCC_25_CaSS3*LCCRyR22 +LCC_52*LCCRyR25 ...
  -LCC_27*LCCRyR22 +LCC_72*LCCRyR27 -RyR_34_CaSS3*LCCRyR22 ...
  +RyR_43_CaSS1*LCCRyR32;
dLCCRyR23 = +RyR_23_CaSS2*LCCRyR13 -RyR_32_CaSS4*LCCRyR23 ...
  +LCC_23*LCCRyR22 -LCC_32*LCCRyR23 -LCC_38*LCCRyR23 ...
  +LCC_83*LCCRyR28 -RyR_34_CaSS4*LCCRyR23 ...
  +RyR_43_CaSS2*LCCRyR33;
dLCCRyR24 = +RyR_23_CaSS1*LCCRyR14 -RyR_32_CaSS3*LCCRyR24 ...
  +LCC_14_CaSS3*LCCRyR21 -LCC_41*LCCRyR24 -LCC_45*LCCRyR24 ...
  +LCC_54*LCCRyR25 -LCC_49*LCCRyR24 +LCC_94*LCCRyR29 ...
  -RyR_34_CaSS3*LCCRyR24 +RyR_43_CaSS1*LCCRyR34;
dLCCRyR25 = +RyR_23_CaSS1*LCCRyR15 -RyR_32_CaSS3*LCCRyR25 ...
  +LCC_25_CaSS3*LCCRyR22 -LCC_52*LCCRyR25 +LCC_45*LCCRyR24 ...
  -LCC_54*LCCRyR25 -LCC_510*LCCRyR25 +LCC_105*LCCRyR30 ...
  -RyR_34_CaSS3*LCCRyR25 +RyR_43_CaSS1*LCCRyR35;
dLCCRyR26 = +RyR_23_CaSS1*LCCRyR16 -RyR_32_CaSS3*LCCRyR26 ...
  +LCC_16*LCCRyR21 -LCC_61*LCCRyR26 -LCC_67*LCCRyR26 ...
  +LCC_76*LCCRyR27 -LCC_69_CaSS3*LCCRyR26 +LCC_96*LCCRyR29 ...
  -RyR_34_CaSS3*LCCRyR26 +RyR_43_CaSS1*LCCRyR36;
dLCCRyR27 = +RyR_23_CaSS1*LCCRyR17 -RyR_32_CaSS3*LCCRyR27 ...
  +LCC_27*LCCRyR22 -LCC_72*LCCRyR27 +LCC_67*LCCRyR26 ...
  -LCC_76*LCCRyR27 -LCC_78*LCCRyR27 +LCC_87*LCCRyR28 ...
  -LCC_710_CaSS3*LCCRyR27 +LCC_107*LCCRyR30 ...
  -RyR_34_CaSS3*LCCRyR27 +RyR_43_CaSS1*LCCRyR37;
dLCCRyR28 = +RyR_23_CaSS1*LCCRyR18 -RyR_32_CaSS3*LCCRyR28 ...
  +LCC_38*LCCRyR23 -LCC_83*LCCRyR28 +LCC_78*LCCRyR27 ...
  -LCC_87*LCCRyR28 -RyR_34_CaSS3*LCCRyR28 ...
  +RyR_43_CaSS1*LCCRyR38;
dLCCRyR29 = +RyR_23_CaSS1*LCCRyR19 -RyR_32_CaSS3*LCCRyR29 ...
  +LCC_49*LCCRyR24 -LCC_94*LCCRyR29 +LCC_69_CaSS3*LCCRyR26 ...
  -LCC_96*LCCRyR29 -LCC_910*LCCRyR29 +LCC_109*LCCRyR30 ...
  -RyR_34_CaSS3*LCCRyR29 +RyR_43_CaSS1*LCCRyR39;
dLCCRyR30 = +RyR_23_CaSS1*LCCRyR20 -RyR_32_CaSS3*LCCRyR30 ...
  +LCC_510*LCCRyR25 -LCC_105*LCCRyR30 ...
  +LCC_710_CaSS3*LCCRyR27 -LCC_107*LCCRyR30 ...
  +LCC_910*LCCRyR29 -LCC_109*LCCRyR30 ...
  -RyR_34_CaSS3*LCCRyR30 +RyR_43_CaSS1*LCCRyR40;
dLCCRyR31 = +RyR_24_CaSS1*LCCRyR11 -RyR_42_CaSS1*LCCRyR31 ...
  +RyR_34_CaSS3*LCCRyR21 -RyR_43_CaSS1*LCCRyR31 ...
  -LCC_12*LCCRyR31 +LCC_21*LCCRyR32 -LCC_14_CaSS1*LCCRyR31 ...
  +LCC_41*LCCRyR34 -LCC_16*LCCRyR31 +LCC_61*LCCRyR36;
dLCCRyR32 = +RyR_24_CaSS1*LCCRyR12 -RyR_42_CaSS1*LCCRyR32 ...
  +RyR_34_CaSS3*LCCRyR22 -RyR_43_CaSS1*LCCRyR32 ...
  +LCC_12*LCCRyR31 -LCC_21*LCCRyR32 -LCC_23*LCCRyR32 ...
  +LCC_32*LCCRyR33 -LCC_25_CaSS1*LCCRyR32 +LCC_52*LCCRyR35 ...
  -LCC_27*LCCRyR32 +LCC_72*LCCRyR37;
dLCCRyR33 = +RyR_24_CaSS2*LCCRyR13 -RyR_42_CaSS2*LCCRyR33 ...
  +RyR_34_CaSS4*LCCRyR23 -RyR_43_CaSS2*LCCRyR33 ...
  +LCC_23*LCCRyR32 -LCC_32*LCCRyR33 -LCC_38*LCCRyR33 ...
  +LCC_83*LCCRyR38;
dLCCRyR34 = +RyR_24_CaSS1*LCCRyR14 -RyR_42_CaSS1*LCCRyR34 ...
  +RyR_34_CaSS3*LCCRyR24 -RyR_43_CaSS1*LCCRyR34 ...
  +LCC_14_CaSS1*LCCRyR31 -LCC_41*LCCRyR34 ...
  -LCC_45*LCCRyR34 +LCC_54*LCCRyR35 -LCC_49*LCCRyR34 ...
  +LCC_94*LCCRyR39;
dLCCRyR35 = +RyR_24_CaSS1*LCCRyR15 -RyR_42_CaSS1*LCCRyR35 ...
  +RyR_34_CaSS3*LCCRyR25 -RyR_43_CaSS1*LCCRyR35 ...
  +LCC_25_CaSS1*LCCRyR32 -LCC_52*LCCRyR35 +LCC_45*LCCRyR34 ...
  -LCC_54*LCCRyR35 -LCC_510*LCCRyR35 +LCC_105*LCCRyR40;
dLCCRyR36 = +RyR_24_CaSS1*LCCRyR16 -RyR_42_CaSS1*LCCRyR36 ...
  +RyR_34_CaSS3*LCCRyR26 -RyR_43_CaSS1*LCCRyR36 ...
  +LCC_16*LCCRyR31 -LCC_61*LCCRyR36 -LCC_67*LCCRyR36 ...
  +LCC_76*LCCRyR37 -LCC_69_CaSS1*LCCRyR36 +LCC_96*LCCRyR39;
dLCCRyR37 = +RyR_24_CaSS1*LCCRyR17 -RyR_42_CaSS1*LCCRyR37 ...
  +RyR_34_CaSS3*LCCRyR27 -RyR_43_CaSS1*LCCRyR37 ...
  +LCC_27*LCCRyR32 -LCC_72*LCCRyR37 +LCC_67*LCCRyR36 ...
  -LCC_76*LCCRyR37 -LCC_78*LCCRyR37 +LCC_87*LCCRyR38 ...
  -LCC_710_CaSS1*LCCRyR37 +LCC_107*LCCRyR40;
dLCCRyR38 = +RyR_24_CaSS1*LCCRyR18 -RyR_42_CaSS1*LCCRyR38 ...
  +RyR_34_CaSS3*LCCRyR28 -RyR_43_CaSS1*LCCRyR38 ...
  +LCC_38*LCCRyR33 -LCC_83*LCCRyR38 +LCC_78*LCCRyR37 ...
  -LCC_87*LCCRyR38;
dLCCRyR39 = +RyR_24_CaSS1*LCCRyR19 -RyR_42_CaSS1*LCCRyR39 ...
  +RyR_34_CaSS3*LCCRyR29 -RyR_43_CaSS1*LCCRyR39 ...
  +LCC_49*LCCRyR34 -LCC_94*LCCRyR39 +LCC_69_CaSS1*LCCRyR36 ...
  -LCC_96*LCCRyR39 -LCC_910*LCCRyR39 +LCC_109*LCCRyR40;

dLCCRyR = [dLCCRyR1 dLCCRyR2 dLCCRyR3 dLCCRyR4 dLCCRyR5 dLCCRyR6 ...
  dLCCRyR7 dLCCRyR8 dLCCRyR9 dLCCRyR10 dLCCRyR11 dLCCRyR12 dLCCRyR13 ...
  dLCCRyR14 dLCCRyR15 dLCCRyR16 dLCCRyR17 dLCCRyR18 dLCCRyR19 dLCCRyR20 ...
  dLCCRyR21 dLCCRyR22 dLCCRyR23 dLCCRyR24 dLCCRyR25 dLCCRyR26 dLCCRyR27 ...
  dLCCRyR28 dLCCRyR29 dLCCRyR30 dLCCRyR31 dLCCRyR32 dLCCRyR33 dLCCRyR34 ...
  dLCCRyR35 dLCCRyR36 dLCCRyR37 dLCCRyR38 dLCCRyR39];

% Ca Release Unit Distributions
PCaSS2 = LCCRyR3 +LCCRyR13 +LCCRyR33;
PCaSS3 = LCCRyR21 +LCCRyR22 +LCCRyR24 +LCCRyR25 +LCCRyR26 +LCCRyR27 ...
  +LCCRyR28 +LCCRyR29 +LCCRyR30;
PCaSS4 = LCCRyR23;
PCaSS1 = 1 - PCaSS2 - PCaSS3 - PCaSS4;

% L-type Ca Channel and Ryanodine Receptor Currents/Fluxes
ICaL = NCaRU/Csa*PCaL*4*VFsq_over_RT/(exp(2*VF_over_RT)-1) ...
  * (PCaSS2*(CaSS2*exp(2*VF_over_RT)-0.341*Cao) ...
  + PCaSS4*(CaSS4*exp(2*VF_over_RT)-0.341*Cao));

JRyR = NCaRU*JRyRmax*(PCaSS4*(CaSR-CaSS4) + PCaSS3*(CaSR-CaSS3));

% Subspace Ca Handling
Jxfer = NCaRU*r_xfer * (PCaSS4*(CaSS4-Cai) + PCaSS3*(CaSS3-Cai) ...
  + PCaSS2*(CaSS2-Cai) + PCaSS1*(CaSS1-Cai));

JSRleak = NCaRU*r_leak * (PCaSS1*(CaSR-CaSS1) + PCaSS2*(CaSR-CaSS2) ...
  + PCaSS3*(CaSR-CaSS3) + PCaSS4*(CaSR-CaSS4));

CaSS = PCaSS1*CaSS1 +PCaSS2*CaSS2 +PCaSS3*CaSS3 +PCaSS4*CaSS4;

%% Ca Handling

% Ca Background Current
ICab = g_ICab*(V-ECa);

% Na/Ca Exchanger
KmNao_NaCa = (KmNai_NaCa^3*KmCao_NaCa/KmCai_NaCa)^(1/3);

ssCai = Cai + 3*(Cai-0.1);
INaCa = Vmax_NaCa ...
  *(Nai^3*Cao*exp(eta_NaCa*VF_over_RT) - Nao^3*ssCai*exp((eta_NaCa-1)*VF_over_RT)) ...
  /(KmCao_NaCa*Nai^3 + KmNao_NaCa*ssCai + KmNai_NaCa*Cao*(1+ssCai/KmCai_NaCa) ...
  + KmCai_NaCa*Nao^3*(1+Nai^3/KmNai_NaCa^3) + Nai^3*Cao + Nao^3*ssCai) ...
  /(1+ksat_NaCa*exp((eta_NaCa-1)*VF_over_RT));

% Sarcolemnal Ca Pump
IpCa = IpCamax*Cai^2/(Km_IpCa^2+Cai^2);

% PLBp = PLBtot;
Kfb = Kfb*(1.0387-0.4856*PLBp/PLBtot);
fb = (Cai/Kfb)^N;
rb = (CaSR/Krb)^N;
Jup = vmax*(fb - rb)/(1 + fb + rb);

%% Na Currents

% INa
aNa11 = 3.802/(0.1027*exp(-(V+2.5)/17)+0.2*exp(-(V+2.5)/150));
bNa11 = 0.1917*exp(-(V+2.5)/20.3);
aNa12 = 3.802/(0.1027*exp(-(V+2.5)/15)+0.23*exp(-(V+2.5)/150));
bNa12 = 0.2*exp(-(V-2.5)/20.3);
aNa13 = 3.802/(0.1027*exp(-(V+2.5)/12)+0.25*exp(-(V+2.5)/150));
bNa13 = 0.22*exp(-(V-7.5)/20.3);

aNa3 = 7e-7*exp(-(V+7)/7.7);
bNa3 = 0.0084+0.00002*(V+7);
aNa2 = 1.0/(0.188495*exp(-(V+7.0)/16.6)+0.393956);
bNa2 = aNa13*aNa2*aNa3/(bNa13*bNa3);
aNa4 = aNa2/1000;
bNa4 = aNa3;
aNa5 = aNa2/95000;
bNa5 = aNa3/50;

CNa3 = 1-(ONa+CNa1+CNa2+IFNa+INa1+INa2+ICNa2+ICNa3);

dCNa1 = aNa12*CNa2 +bNa13*ONa +aNa3*IFNa ...
  -(bNa12*CNa1 +aNa13*CNa1 +bNa3*CNa1);
dCNa2 = aNa11*CNa3 +bNa12*CNa1 +aNa3*ICNa2 ...
  -(bNa11*CNa2 +aNa12*CNa2 +bNa3*CNa2);
dIFNa = aNa2*ONa +bNa3*CNa1 +bNa4*INa1 +aNa12*ICNa2 ...
  -(bNa2*IFNa +aNa3*IFNa +aNa4*IFNa +bNa12*IFNa);
dINa1 = aNa4*IFNa +bNa5*INa2 -(bNa4*INa1 +aNa5*INa1);
dINa2 = aNa5*INa1 -bNa5*INa2;
dICNa2 = aNa11*ICNa3 +bNa12*IFNa +bNa3*CNa2 ...
  -(bNa11*ICNa2 +aNa12*ICNa2 +aNa3*ICNa2);
dICNa3 = bNa11*ICNa2 +bNa3*CNa3 -(aNa11*ICNa3 +aNa3*ICNa3);
dONa = aNa13*CNa1 +bNa2*IFNa -(bNa13*ONa +aNa2*ONa);

INa = g_INa*ONa*(V-ENa);

% INab
INab = g_INab*(V-ENa);

% Na/K Pump
INaKsigma = 1/7*(exp(Nao/67300)-1);
INaK_f_NaK = 1/(1+0.1245*exp(-0.1*VF_over_RT)+ ...
  0.0365*INaKsigma*exp(-VF_over_RT));

% PLMp = PLMtot;
Km_Nai = Km_Nai*(1.0469-0.4015*PLMp/PLMtot);

INaK = INaKmax*INaK_f_NaK*1/(1+(Km_Nai/Nai)^3.2)*Ko/(Ko+Km_Ko);
  % The Hill coefficient on Nai should maybe be 2.8 instead of 3.2
  % (Despa, Bers, Circ Res, 2005)

%% K Currents

% Fast Transient Outward
IKtof_alpha_a = 0.18064*exp(0.03577*(V+30));
IKtof_beta_a = 0.3956*exp(-0.06237*(V+30));
IKtof_alpha_i = 0.000152*exp(-(V+13.5)/7)/(0.0067083*exp(-(V+33.5)/7)+1);
IKtof_beta_i = 0.00095*exp((V+33.5)/7)/(0.051335*exp((V+33.5)/7)+1);

datof = IKtof_alpha_a*(1-atof)-IKtof_beta_a*atof;
ditof = IKtof_alpha_i*(1-itof)-IKtof_beta_i*itof;

IKtof = g_IKtof*atof^3*itof*(V-EK);

% Non-Inactivating Steady-State Potassium Current
IKss_ass = 1/(1+exp(-(V+22.5)/7.7));
tau_IKss = 39.3*exp(-0.0862*V)+13.17;
daKss = (IKss_ass-aKss)/tau_IKss;
IKss = g_IKss*aKss*(V-EK);

% Inward Rectifier
IK1 = 0.25*Ko/(Ko+210)*(V-EK)/(1+exp(0.0896*(V-EK)));

% Slow Delayed Rectifier
IKs_alpha_n = 0.00000481333*(V+26.5)/(1.0-exp(-0.128*(V+26.5)));
IKs_beta_n = 0.0000953333*exp(-0.038*(V+26.5));
dnKs = IKs_alpha_n*(1-nKs)-IKs_beta_n*nKs;

IKs = g_IKs*nKs^2*(V-EK);

% Rapid Delayed Rectifier
IKr_beta_a1 = 0.0000689*exp(-0.04178*V);
IKr_alpha_a1 = 0.013733*exp(0.038198*V);
IKr_alpha_a0 = 0.022348*exp(0.01176*V);
IKr_beta_a0 = 0.047002*exp(-0.0631*V);
IKr_beta_i = 0.006497*exp(-0.03268*(V+5));
IKr_alpha_i = 0.090821*exp(0.023391*(V+5));

CK0 = 1-(CK1+CK2+OK+IK);
dCK1 = IKr_alpha_a0*CK0 +IKr_kb*CK2 -(IKr_beta_a0*CK1 +IKr_kf*CK1);
dCK2 = IKr_kf*CK1 +IKr_beta_a1*OK -(IKr_kb*CK2 +IKr_alpha_a1*CK2);
dIK = IKr_alpha_i*OK -IKr_beta_i*IK;
dOK = IKr_alpha_a1*CK2 +IKr_beta_i*IK -(IKr_beta_a1*OK +IKr_alpha_i*OK);

IKr = g_IKr*OK*(V-RT_over_F*log((0.98*Ko+0.02*Nao)/(0.98*Ki+0.02*Nai)));

% Ultra-Rapid Delayed Rectifier
IKur_ass = 1/(1+exp(-(V+22.5)/7.7));
tau_aur = 0.493*exp(-0.0629*V)+2.058;
IKur_iss = 1/(1+exp((V+45.2)/5.7));
tau_iur = 1200.0-170.0/(1.0+exp((V+45.2)/5.7));

daur = (IKur_ass-aur)/tau_aur;
diur = (IKur_iss-iur)/tau_iur;

IKur = g_IKur*aur*iur*(V-EK);

%% Membrane Potential / Ion Balance

dV = -(ICaL+IpCa+INaCa+ICab +INa+INab+INaK ...
  +IKtof+IK1+IKs+IKur+IKss+IKr+Istim)/Cm;

dCai = Jxfer*VSS/Vmyo-(Jup+(ICab+IpCa-2*INaCa)*Csa/(2*Vmyo*F)) ...
  -dTnCLCa-dTnCHCa-dMyosinCa-dCaMCa-dCaSRb-dCaSL-dCaSLh-dCaATP-dCaPCr;
dCaSR = CaBSR*(Jup*Vmyo/VSR-JRyR*VSS/VSR-JSRleak*VSS/VSR);

dNai = -(INa+INab+3*INaK+3*INaCa)*Csa/(Vmyo*F);
dKi = -(IKtof+IK1+IKs+IKss+IKur+IKr-2*INaK+Istim)*Csa/(Vmyo*F);

if Vclampflag
  dV = 0;
end

%% Reassemble dydt

dydt = [dLR dLRG dRG db1AR_S464 db1AR_S301 ...
  dGsaGTPtot dGsaGDP dGsby ...
  dAC_GsaGTP dcAMPtot dPDEp ...
  dRC_I dRCcAMP_I dRCcAMPcAMP_I dRcAMPcAMP_I dPKACI dPKACI_PKI ...
  dRC_II dRCcAMP_II dRCcAMPcAMP_II dRcAMPcAMP_II dPKACII dPKACII_PKI ...
  dI1p_PP1 dI1ptot ...
  dLCCap dLCCbp dPLBp dPLMp dTnIp ...
  dV dCai dCaSR dKi dNai ...
  dCNa1 dCNa2 dIFNa dINa1 dINa2 dICNa2 dICNa3 dONa ...
  datof ditof ...
  daKss dnKs ...
  dCK1 dCK2 dIK dOK ...
  daur diur ...
  dTnCLCa dTnCHCa dTnCHMg dMyosinCa dMyosinMg dCaMCa ...
  dCaSRb dCaSL dCaSLh dCaATP dCaPCr...
  dLCCRyR ...
  ]';

