function output = saucerman_circres2004
% saucerman_circres2004.m
% coupled beta adrenergic signaling/EC for adult rabbit ventricular
% myocytes, with extensions for yotiao interactions, KCNQ1-G589D mutation
%
% Copyright (2004) The Regents of the University of California
% All Rights Reserved
% Permission to use, copy, and modify, any part of this software for
% academic purposes only, including non-profit  education and research,
% without fee, and without a written agreement is hereby granted, provided
% that the above copyright notice, this paragraph and the following three
% paragraphs appear in all copies.
% The receiving party agrees not to further distribute nor disclose the
% source code to third parties without written permission and not to use
% the software for research under commercial sponsorship or for any other
% any commercial undertaking.  Those desiring to incorporate this software
% into commercial products of to use it for commercial purposes should
% contact the Technology Transfer Office, University of California, San
% Diego, 9500 Gilman Drive, La Jolla, California, 92093-0910, Ph: (619)
% 534 5815, referring to Case SDC98008.
% IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
% FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
% INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE, EVEN IF
% THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
% DAMAGE.
% THE SOFTWARE PROVIDED HEREUNDER IS ON AN AS IS BASIS, AND THE
% UNIVERSITY OF CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE,
% SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.  THE UNIVERSITY OF
% CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES OF ANY
% KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MECHANT ABILITY OR FITNESS FOR A PARTICULAR
% PURPOSE, OR THAT THE USE OF THE MATERIAL WILL NOT INFRINGE ANY PATENT,
% TRADEMARK OR OTHER RIGHTS.
%
% Those using this code should acknowledge Dr. Andrew D. McCulloch and the
% National Biomedical Computation Resource (NBCR), NIH grant #P41 RR08605.
%
% References:
% -----------
% Jeffrey J. Saucerman, Sarah N. Healy, Mary E. Belik, Jose L. Puglisi, and
% Andrew D. McCulloch.  "Proarrhythmic Consequences of a KCNQ1 AKAP-Binding 
% Domain Mutation: Computational Models of Whole Cells and Heterogeneous
% Tissue", Circ. Res., Vol 95: 1216-1224 (2004).
%
% Jeffrey J. Saucerman and Andrew D. McCulloch
% "Mechanistic systems models of cell signaling networks: a case study of
% myocyte adrenergic regulation", Prog. Biophys. Mol. Bio., Vol 84: 261-278 (2004).
%
% Jeffrey J. Saucerman, Laurence L. Brunton, Anushka P. Michailova, and Andrew D. McCulloch
% "Modeling beta-adrenergic control of cardiac myocyte contractility in
% silico", J. Biol. Chem., Vol 278: 47977-48003 (2003).
%
% Last modified: 12/20/2004
% Implemented by: Jeffrey Saucerman <jsaucer@ucsd.edu>
%
% Notes:
% - This code was used for the single cell simulations in the Circ Res ms.
% - In Matlab 7, you can enable cell mode to jump between modules.
% - Please email me for any questions or comments.


%% Parameters
%% ----- Signaling model parameters -------
% b-AR/Gs module
p(1) = 1.0;       % Ltotmax   [uM] ** apply agonist concentration here **
p(2) = 0.028;   % sumb1AR   [uM]
p(3) = 3.83;    % Gstot     [uM]
p(4) = 0.285;   % Kl        [uM]
p(5) = 0.062;   % Kr        [uM]
p(6) = 33.0;    % Kc        [uM]
p(7) = 1.1e-3;  % k_barkp   [1/sec]
p(8) = 2.2e-3;  % k_barkm   [1/sec]
p(9) = 3.6e-3;  % k_pkap    [1/sec/uM]
p(10) = 2.2e-3; % k_pkam    [1/sec]
p(11) = 16.0;   % k_gact    [1/sec]
p(12) = 0.8;    % k_hyd     [1/sec]
p(13) = 1.21e3; % k_reassoc [1/sec/uM]
% cAMP module
p(14) = 0.047;  % AC_tot    [uM]
p(15) = 5.0e3;  % ATP       [uM]
p(16) = 0.06;   % PDE3tot   [uM]
p(17) = 0.036;  % PDE4tot   [uM]
p(18) = 0.0;    % IBMXtot   [uM]
p(19) = 0.0;    % Fsktot    [uM] (10 uM when used)
p(20) = 0.2;    % k_ac_basal[1/sec]
p(21) = 8.5;    % k_ac_gsa  [1/sec]
p(22) = 7.3;    % k_ac_fsk  [1/sec]
p(23) = 1.03e3; % Km_basal  [uM]
p(24) = 315.0;  % Km_gsa    [uM]
p(25) = 860.0;  % Km_fsk    [uM]
p(26) = 0.4;    % Kgsa      [uM]
p(27) = 44.0;   % Kfsk      [uM]
p(28) = 3.5;    % k_pde3    [1/sec]
p(29) = 0.15;   % Km_pde3   [uM]
p(30) = 5.0;    % k_pde4    [1/sec]
p(31) = 1.3;    % Km_pde4   [uM]
p(32) = 30.0;   % Ki_ibmx   [uM]
% PKA module
p(33) = 0.46;   % PKAItot   [uM]
p(34) = 0.084;  % PKAIItot  [uM]
p(35) = 0.18;   % PKItot    [uM]
p(36) = 9.14;   % Ka        [uM]
p(37) = 1.64;   % Kb        [uM]
p(38) = 4.375;  % Kd        [uM]
p(39) = 0.2e-3; % Ki_pki    [uM]
% PLB module
p(40) = 10;     % epsilon   [none]
p(41) = 38;     % PLBtot    [uM]
p(42) = 0.89;   % PP1tot    [uM]
p(43) = 0.3;    % Inhib1tot [uM]
p(44) = 54;     % k_pka_plb     [1/sec]
p(45) = 21;     % Km_pka_plb    [uM]
p(46) = 8.5;    % k_pp1_plb     [1/sec]
p(47) = 7.0;    % Km_pp1_plb    [uM]
p(48) = 60;     % k_pka_i1      [1/sec]
p(49) = 1.0;    % Km_pka_i1     [uM]
p(50) = 14.0;   % Vmax_pp2a_i1  [uM/sec]
p(51) = 1.0;    % Km_pp2a_i1    [uM]
p(52) = 1.0e-3; % Ki_inhib1     [uM]
% LCC module
p(53) = 0.025;  % LCCtot        [uM]
p(54) = 0.025;  % PKAIIlcctot   [uM]
p(55) = 0.025;  % PP1lcctot     [uM]
p(56) = 0.025;  % PP2Alcctot    [uM]
p(57) = 54;     % k_pka_lcc     [1/sec]
p(58) = 21;     % Km_pka_lcc    [uM]
p(59) = 8.52;   % k_pp1_lcc     [1/sec]
p(60) = 3;      % Km_pp1_lcc    [uM]
p(61) = 10.1;   % k_pp2a_lcc    [1/sec]
p(62) = 3;      % Km_pp2a_lcc   [uM]
% RyR module
p(63) = 0.135;  % RyRtot        [uM]
p(64) = 0.034;  % PKAIIryrtot   [uM]
p(65) = 0.034;  % PP1ryr        [uM]
p(66) = 0.034;  % PP2Aryr       [uM]
p(67) = 54;     % kcat_pka_ryr  [1/sec]
p(68) = 21;     % Km_pka_ryr    [uM]
p(69) = 8.52;   % kcat_pp1_ryr  [1/sec]
p(70) = 7;      % Km_pp1_ryr    [uM]
p(71) = 10.1;   % kcat_pp2a_ryr [1/sec]
p(72) = 4.1;    % Km_pp2a_ryr   [uM]
% TnI module
p(73) = 70;     % TnItot        [uM]
p(74) = 0.67;   % PP2Atni       [uM]
p(75) = 54;     % kcat_pka_tni  [1/sec]
p(76) = 21;     % Km_pka_tni    [uM]
p(77) = 10.1;   % kcat_pp2a_tni [1/sec]
p(78) = 4.1;    % Km_pp2a_tni   [uM]
% Iks module
p(79) = 0.025;  % Iks_tot       [uM]
p(80) = 0.025;  % Yotiao_tot    [uM]
p(81) = 0.1e-3; % K_yotiao      [uM] ** apply G589D mutation here **
p(82) = 0.025;  % PKAII_ikstot  [uM]
p(83) = 0.025;  % PP1_ikstot    [uM]
p(84) = 54;     % k_pka_iks     [1/sec]
p(85) = 21;     % Km_pka_iks    [uM]
p(86) = 8.52;   % k_pp1_iks     [1/sec]
p(87) = 7;      % Km_pp1_iks    [uM]
%% ---- EC Coupling model parameters ------
% universal parameters
p(88) = 25.84e-6;    % Vmyo  [uL]
p(89) = 2.098e-6;    % Vnsr  [uL]
p(90) = 0.182e-6;    % Vjsr  [uL]
p(91) = 1.534e-4;    % ACap  [cm^2] with C = 1 uF/cm^2
p(92) = 310;         % Temp  [K]
% extracellular concentrations     
p(93) = 140;     % Extracellular Na  [mM]
p(94) = 5.4;     % Extracellular K   [mM]
p(95) = 1.8;     % Extracellular Ca  [mM]
% current conductances
p(96) = 8.0;    % G_Na      [mS/uF]
p(97) = 0.06;   % G_to      [mS/uF] 
p(98) = 0.035;  % G_kro     [mS/uF]
p(99) = 0.54;   % G_kibar   [mS/uF] 
p(100) = 0.008;  % G_kp      [mS/uF]
p(101) = 0.5;	% Gkso       [mS/uF]
% I_Ca parameters
p(102) = 0.0;	 % Nifidipine[uM]
p(103) = 0.43;	 % IC50_nif  [uM]
p(104) = 6.75e-7;% pNa       [cm/sec]
p(105) = 5.4e-4; % pCa       [cm/sec]
p(106) = 1.93e-7;% pK        [cm/sec]
p(107) = 0.6e-3; % KmCa      [mM]
p(108) = 0;
% pumps and background currents
p(109) = 2.6e3;  % k_NaCa    [uA/uF]
p(110) = 87.5;   % Km_Na     [mM]
p(111) = 1.38;   % Km_Ca     [mM]
p(112) = 0.1;    % k_sat     [none]  
p(113) = 0.35;   % eta       [none]
p(114) = 1.79;   % ibarnak   [uA/uF]
p(115) = 10;     % Km_Nai    [mM]
p(116) = 1.5;    % Km_Ko     [mM]
p(117) = 1.15;   % ibarpca   [uA/uF]
p(118) = 0.5e-3; % Km_pca    [mM]
p(119) = 3e-3;   % G_Cab     [uA/uF] 
p(120) = 9.8e-5; % G_Nab     [uA/uF] 
p(121) = 1.75e-7;% Pns       [cm/sec]
p(122) = 1.2e-3; % Km_ns     [mM]
% Calcium handling parameters
p(123) = 4.0;    % I_upbar   [mM/sec]
p(124) = 3e-4;   % Km_up     [mM]
p(125) = 15;     % nsrbar    [mM]
p(126) = 2e-3;   % tauon     [sec]
p(127) = 2e-3;   % tauoff    [sec]
p(128) = 90e3;   % gmaxrel   [mM/sec]
p(129) = 20e3;   % gmaxrelol [mM/sec]
p(130) = 0.8e-3; % Km_rel    [mM]
p(131) = 7.5;   % CSQNth    [mM]
p(132) = 10;     % CSQNbar   [mM]
p(133) = 0.8333; % Km_csqn   [mM]
p(134) = 0.006;  % tau_tr    [sec] 
p(135) = 0.07;   % TRPNbar   [mM]
p(136) = 0.05;   % CMDNbar   [mM]
p(137) = 0.0;    % INDObar   [mM]
p(138) = 0.5128e-3;  % Km_trpn   [mM]
p(139) = 2.38e-3;    % Km_cmdn   [mM]
p(140) = 8.44e-4;    % Km_indo   [mM]
% Simulation parameters
p(141) = 1.0; % rate (Hz)   ** change pacing rate here **
p(142) = -80; % Vhold
p(143) = -80; % Vtest
p(144) = 50.5;  % S2_time

%% Initial conditions and mass matrix
% b-AR/Gsa module
%   1       2       3       4       5       6       7           8       9
%   L       R       Gs      b1ARtot b1ARd   b1ARp   Gsagtptot   Gsagdp  Gsbg
y10=[1;     0.0243; 3.827;  0.0276; 0.0;    4e-4;   0.0574;     6.54e-4;0.058];
m1 =[0,     0,      0,      1,      1,      1,      1,          1,      1];
% cAMP module and PKA module
%   10      11      12      13      14      15      
%   Gsa_gtp Fsk     AC      PDE     IBMX    cAMPtot 
y20=[0.052; 0;      0.0416; 0.036;  0;      0.487];
m2 =[0,     0,      0,      0,      0,      1];
% PKA module
%   16      17      18
%   cAMP    PKACI   PKACII
y30=[0.072; 8.3e-3; 3.2e-3];
m3 =[0,     0,      0];
% PLB and LCC  modules
%   19      20          21      22      23      24
%   PLBs    Inhib1ptot  Inhib1p PP1     LCCap   LCCbp
y40=[0.28;  8.1e-3;     9.1e-6; 0.88;   7.0e-4; 8.2e-4];
m4 =[1,     1,          0,      0,      1,          1];
% RyR and TnI modules
%   25      26      27      28      29
%   RyRp    TnIp    Iks     Yotiao  Iksp
y50=[3.3e-3;0.22;   1.5e-3; 1.5e-3; 1.8e-3];
m5 =[1,     1,      0,      0,      1];
% Gating variables      
%   30      31      32      33      34      35      36      37      38      39      40      41      42
%   m       h       j       d       f       x       y       z       xto     yto     xkr     xks   
y60_p5=[1.4e-3;0.99;   0.99;   0.0;    1.0;    0.13;   0.96;   0.92;   0.0;    1.0;    0.0;    6.5e-3;   0.0];    % 0.5 Hz
y60_1=[1.4e-3;0.99;   0.99;   0.0;    1.0;    0.13;   0.96;   0.92;   0.0;    1.0;    0.0;    6.6e-3;   0.0];    % 1 Hz
y60_1p5=[1.4e-3;0.99;   0.99;   0.0;    1.0;    0.13;   0.96;   0.92;   0.0;    1.0;    0.0;    0.017;   0.0];    % 1.5 Hz
y60_2=[1.4e-3;0.99;   0.99;   0.0;    0.99;    0.13;   0.96;   0.92;   0.0;    1.0;    0.0;    0.042;   0.0]; % 2 Hz
y60_3=[1.7e-3;0.98;   0.98;   0.0;    0.90;    0.13;   0.96;   0.92;   0.0;    1.0;    0.0;    0.11;   0.0];   % 3 Hz
y60_4=[2.6e-3;0.86;   0.45;   0.0;    0.58;    0.13;   0.96;   0.92;   0.0;    1.0;    0.0;    0.18;   0.0];    % 4 Hz
m6 =[1,     1,      1,      1,      1,      1,      1,      1,      1,      1,      1,      1,      1];
%   Intracellular concentrations/ Membrane voltage
%   43      44      45      46      47      48      49      50      
%   Ca_nsr  Ca_jsr  Nai     Ki      Cai     Vm      trel    
y70_p5=[0.98;  0.98;   9.95;     145;    1.23e-4;-86.5;  0.895;];   % 0.5 Hz
y70_1=[1.20;  1.20;   10;     145;    1.45e-4;-85.5;  0.895;];   % 1 Hz
y70_1p5=[1.42;  1.42;   10.2;     145;    1.80e-4;-85.2;  0.562;];   % 1.5 Hz
y70_2=[1.42;  1.42;   10.2;     145;    1.45e-4;-85.2;  0.395;]; % 2 Hz
y70_3=[1.45;  1.45;   10.5;     145;    2.55e-4;-84.5;  0.229;];  % 3 Hz
y70_4=[1.35;  1.32;   11.0;     145;    4.13e-4;-81.3;  0.145;];   % 4 Hz
m7 =[1,     1,      1,      1,      1,      1,      1];
% Put everything together, specify IC's based on pacing rate
switch p(141)
 case 0.5, y60=y60_p5; y70=y70_p5;
 case 1.0, y60=y60_1; y70=y70_1;
 case 1.5, y60=y60_1p5; y70=y70_1p5;
 case 2.0, y60=y60_2; y70=y70_2;
 case 3.0, y60=y60_3; y70=y70_3;
 case 4.0, y60=y60_4; y70=y70_4;
end
y0  = [y10;y20;y30;y40;y50;y60;y70];    
M = diag([m1,m2,m3,m4,m5,m6,m7]); 

%% Simulation and plotting
% Single Run
tspan = [0;40];
options = odeset('Mass',M,'RelTol',1e-5,'MaxStep',5e-3,'Stats','on'); 
clear global jsrol_time;
[t,y] = ode15s(@f,tspan,y0,options,p);
yfinal = y(end,:)
cai=yfinal(47)
%output = [t, y(:,48), y(:,47), y(:,44)];
subplot(4,1,1); plot(t,y(:,48)); 
subplot(4,1,2); plot(t,y(:,47));
subplot(4,1,3); plot(t,y(:,44));
%subplot(4,1,4); plot(t,y(:,45));

figure(2);
subplot(4,1,1); plot(t,y(:,23)); legend('lcc');
subplot(4,1,2); plot(t,y(:,29)); legend('iksp');
subplot(4,1,3); plot(t,y(:,19)); legend('plb');
subplot(4,1,4); plot(t,y(:,18)); legend('PKACII');

function ydot = f(t,y,p)
%% ODE function
ydot = zeros(size(y));
%% -------- SIGNALING MODEL -----------

%% b-AR module
LR = y(1)*y(2)/p(4);
LRG = LR*y(3)/p(5);
RG = y(2)*y(3)/p(6);
BARKDESENS = p(7)*(LR+LRG);
BARKRESENS = p(8)*y(5);
PKADESENS = p(9)*y(17)*y(4);  
PKARESENS = p(10)*y(6);
GACT = p(11)*(RG+LRG);
HYD = p(12)*y(7);
REASSOC = p(13)*y(8)*y(9);
ydot(1) = p(1)-LR-LRG-y(1);
ydot(2) = y(4)-LR-LRG-RG-y(2);
ydot(3) = p(3)-LRG-RG-y(3);
ydot(4) = (BARKRESENS-BARKDESENS)+(PKARESENS-PKADESENS);
ydot(5) = BARKDESENS-BARKRESENS;
ydot(6) = PKADESENS-PKARESENS;
ydot(7) = GACT-HYD;
ydot(8) = HYD-REASSOC;
ydot(9) = GACT-REASSOC;
% end b-AR module

%% cAMP module
Gsa_gtp_AC = y(10)*y(12)/p(26);
Fsk_AC = y(11)*y(12)/p(27);
AC_ACT_BASAL = p(20)*y(12)*p(15)/(p(23)+p(15));	    
AC_ACT_GSA = p(21)*Gsa_gtp_AC*p(15)/(p(24)+p(15)); 
AC_ACT_FSK = p(22)*Fsk_AC*p(15)/(p(25)+p(15));	   
PDE3_ACT = p(28)*y(13)*y(16)/(p(29)+y(16));	
PDE4_ACT = p(30)*y(13)*y(16)/(p(31)+y(16));	
PDE_IBMX = y(13)*y(14)/p(32);
ydot(10) = y(7)-Gsa_gtp_AC-y(10);
ydot(11) = p(19)-Fsk_AC-y(11);
ydot(12) = p(14)-Gsa_gtp_AC-y(12);  % note: assumes Fsk = 0.  Change Gsa_gtp_AC to Fsk_AC for Forskolin.
ydot(13) = p(17)-PDE_IBMX-y(13);
ydot(14) = p(18)-PDE_IBMX-y(14);
ydot(15) = AC_ACT_BASAL+AC_ACT_GSA+AC_ACT_FSK-PDE3_ACT-PDE4_ACT;
% end cAMP module

%% PKA module
PKI = p(35)*p(39)/(p(39)+y(17)+y(18));
A2RC_I = (y(17)/p(38))*y(17)*(1+PKI/p(39));
A2R_I = y(17)*(1+PKI/p(39));
A2RC_II = (y(18)/p(38))*y(18)*(1+PKI/p(39));
A2R_II = y(18)*(1+PKI/p(39));
ARC_I = (p(36)/y(16))*A2RC_I;
ARC_II = (p(36)/y(16))*A2RC_II;
ydot(16) = y(15)-(ARC_I+2*A2RC_I+2*A2R_I)-(ARC_II+2*A2RC_II+2*A2R_II)-y(16);
PKAtemp = p(36)*p(37)/p(38)+p(36)*y(16)/p(38)+y(16)^2/p(38);
ydot(17) = 2*p(33)*y(16)^2-y(17)*(1+PKI/p(39))*(PKAtemp*y(17)+y(16)^2);
ydot(18) = 2*p(34)*y(16)^2-y(18)*(1+PKI/p(39))*(PKAtemp*y(18)+y(16)^2);
% end PKA module

%% PLB module
PLB = p(41)-y(19);
PLB_PHOSPH = p(44)*y(17)*PLB/(p(45)+PLB);
PLB_DEPHOSPH = p(46)*y(22)*y(19)/(p(47)+y(19));
ydot(19) = PLB_PHOSPH-PLB_DEPHOSPH;
 
Inhib1 = p(43)-y(20);
Inhib1p_PP1 = y(21)*y(22)/p(52);
Inhib1_PHOSPH = p(48)*y(17)*Inhib1/(p(49)+Inhib1); 
Inhib1_DEPHOSPH = p(50)*y(20)/(p(51)+y(20));
ydot(20) = Inhib1_PHOSPH-Inhib1_DEPHOSPH;
ydot(21) = y(20)-Inhib1p_PP1-y(21);
ydot(22) = p(42)-Inhib1p_PP1-y(22);

fracPLBp = y(19)/p(41);
fracPLB = PLB/p(41);
fracPLBo = 0.9926;
% end PLB module

%% LCC module
PKAClcc = (p(54)/p(34))*y(18);
LCCa = p(53)-y(23);
LCCa_PHOSPH = p(40)*p(57)*PKAClcc*LCCa/(p(58) + p(40)*LCCa);
LCCa_DEPHOSPH = p(40)*p(61)*p(56)*y(23)/(p(62)+p(40)*y(23));
ydot(23) = LCCa_PHOSPH - LCCa_DEPHOSPH;
fracLCCap = y(23)/p(53);
fracLCCapo = 0.028;
 
LCCb = p(53)-y(24);
LCCb_PHOSPH = p(40)*p(57)*PKAClcc*LCCb/(p(58)+p(40)*LCCb);   
LCCb_DEPHOSPH = p(40)*p(59)*p(55)*y(24)/(p(60)+p(40)*y(24));
ydot(24) = LCCb_PHOSPH-LCCb_DEPHOSPH;
fracLCCbp = y(24)/p(53);
fracLCCbpo = 0.0328;
% end LCC module

%% RyR module
PKACryr = (p(64)/p(34))*y(18);
RyR = p(63)-y(25);
RyRPHOSPH = p(40)*p(67)*PKACryr*RyR/(p(68)+p(40)*RyR);
RyRDEPHOSPH1 = p(40)*p(69)*p(65)*y(25)/(p(70)+p(40)*y(25));
RyRDEPHOSPH2A = p(40)*p(71)*p(66)*y(25)/(p(72)+p(40)*y(25));
ydot(25) = RyRPHOSPH-RyRDEPHOSPH1-RyRDEPHOSPH2A;
fracRyRp = y(25)/p(63);
fracRyRpo = 0.0244;
% end RyR module

%% TnI module
TnI = p(73)-y(26);
TnIPHOSPH = p(75)*y(17)*TnI/(p(76)+TnI);
TnIDEPHOSPH = p(77)*p(74)*y(26)/(p(78)+y(26));
ydot(26) = TnIPHOSPH-TnIDEPHOSPH;
fracTnIp = y(26)/p(73);
fracTnIpo = 0.0031;
% end TnI module

%% Iks module
IksYot = y(27)*y(28)/p(81);           % [uM]
ydot(27) = p(79) - IksYot - y(27);    % [uM]
ydot(28) = p(80) - IksYot - y(28);    % [uM]
PKACiks = (IksYot/p(79))*(p(82)/p(34))*y(18);
PP1iks = (IksYot/p(79))*p(83);
Iks = p(79)-y(29);
IKS_PHOSPH = p(40)*p(84)*PKACiks*Iks/(p(85)+p(40)*Iks);
IKS_DEPHOSPH = p(40)*p(86)*PP1iks*y(29)/(p(87)+p(40)*y(29));
ydot(29) = IKS_PHOSPH-IKS_DEPHOSPH;
fracIksp = y(29)/p(79);
fracIkspo = 1.8e-3/p(79);
% end Iks module
% -------- END SIGNALING MODEL ---------
%% -------- EC COUPLING MODEL -----------

%% Constants
R = 8314;   % R     [J/kmol*K]
Frdy = 96485;  % Frdy     [C/mol]
FoRT = Frdy/R/p(92);
zna = 1;    % Na valence
zk = 1;     % K valence
zca = 2;    % Ca valence
% Nernst Potentials
ena = (1/FoRT/zna)*log(p(93)/y(45));  % should be 70.54 mV
ek = (1/FoRT/zk)*log(p(94)/y(46));	  % should be -87.94 mV
eca = (1/FoRT/zca)*log(p(95)/y(47));  % should be 120 mV
prnak = 0.01833;
eks = (1/FoRT)*log((p(94)+prnak*p(93))/(y(46)+prnak*y(45)));	% should be -77.54
ecl = -40.0;

%% I_Na: Fast Na Current
am = 0.32*(y(48)+47.13)/(1-exp(-0.1*(y(48)+47.13)));
bm = 0.08*exp(-y(48)/11);
if y(48) >= -40
    ah = 0; aj = 0;
    bh = 1/(0.13*(1+exp(-(y(48)+10.66)/11.1)));
    bj = 0.3*exp(-2.535e-7*y(48))/(1+exp(-0.1*(y(48)+32)));
else
    ah = 0.135*exp((80+y(48))/-6.8);
    bh = 3.56*exp(0.079*y(48))+3.1e5*exp(0.35*y(48));
    aj = (-1.2714e5*exp(0.2444*y(48))-3.474e-5*exp(-0.04391*y(48)))*(y(48)+37.78)/(1+exp(0.311*(y(48)+79.23)));
    bj = 0.1212*exp(-0.01052*y(48))/(1+exp(-0.1378*(y(48)+40.14)));
end
ydot(30) = 1e3*(am*(1-y(30))-bm*y(30));
ydot(31) = 1e3*(ah*(1-y(31))-bh*y(31));
ydot(32) = 1e3*(aj*(1-y(32))-bj*y(32));
I_Na = p(96)*y(30)^3*y(31)*y(32)*(y(48)-ena);

%% I_Ca: L-type Calcium Current
dss = 1/(1+exp(-(y(48)+0.01)/6.24));
taud = dss*(1-exp(-(y(48)+0.01)/6.24))/(0.035*(y(48)+0.01));
fss = 1/(1+exp((y(48)+35.06)/8.6))+0.6/(1+exp((50-y(48))/20));
tauf = 1/(0.0197*exp( -(0.0337*(y(48)+0.01))^2 )+0.02);
ydot(33) = 1e3*(dss-y(33))/taud;
ydot(34) = 1e3*(fss-y(34))/tauf;

ibarca = p(105)*4*(y(48)*Frdy*FoRT) * (y(47)*exp(2*y(48)*FoRT)-0.341*p(95)) /(exp(2*y(48)*FoRT)-1);
ibark = p(106)*(y(48)*Frdy*FoRT)*(0.75*y(46)*exp(y(48)*FoRT)-0.75*p(94)) /(exp(y(48)*FoRT)-1);
ibarna = p(104)*(y(48)*Frdy*FoRT) *(0.75*y(45)*exp(y(48)*FoRT)-0.75*p(93))  /(exp(y(48)*FoRT)-1);
fCa = 1/(1+(y(47)/p(107))^2);   
favail = 1*(0.05*fracLCCbp/fracLCCbpo+0.95);    % PHOSPHOREGULATION
fpo = 1*(0.03*fracLCCap/fracLCCapo+0.97);       % PHOSPHOREGULATION
rel = p(103)/(p(103)+p(102));			% effect of nifedipine (ICa blocker)
I_Ca = rel*ibarca*favail*fpo*y(33)*y(34)*fCa;
I_CaK = rel*ibark*favail*fpo*y(33)*y(34)*fCa;
I_CaNa = rel*ibarna*favail*fpo*y(33)*y(34)*fCa;
I_Catot = I_Ca+I_CaK+I_CaNa;

%% I_to: Transient Outward K Current
axto = 0.04561 * exp(0.03577*y(48));
bxto = 0.0989 * exp(-0.06237*y(48));
ydot(38) = 1e3*(axto*(1-y(38))-bxto*y(38));
ayto = 0.005415*exp(-(y(48)+33.5)/5)/(1+0.051335*exp(-(y(48)+33.5)/5));  
byto = 0.005415*exp((y(48)+33.5)/5)/(1+0.05133*exp((y(48)+33.5)/5));
ydot(39) = 1e3*(ayto*(1-y(39))-byto*y(39));
I_to = p(97)*y(38)*y(39)*(y(48)-ek);    % [uA/uF]

%% I_kr: Rapidly Activating K Current
gkr = p(98)*sqrt(p(94)/5.4);
xrss = 1/(1+exp(-(y(48)+50)/7.5));
tauxr = 1/(1.38e-3*(y(48)+7)/(1-exp(-0.123*(y(48)+7)))+6.1e-4*(y(48)+10)/(exp(0.145*(y(48)+10))-1));
ydot(40) = 1e3*(xrss-y(40))/tauxr;
rkr = 1/(1+exp((y(48)+33)/22.4));
I_kr = gkr*y(40)*rkr*(y(48)-ek);

%% I_ks: Slowly Activating K Current
pcaks = -log10(y(47))+3.0;
gkso = p(101)*(0.04 +0.133/(1+ exp((-7.2+pcaks)/0.6)));
gks = gkso*(0.2*fracIksp/fracIkspo+0.8);    % PHOSPHOREGULATION
xs05 = 1.5-(1.5*fracIksp/fracIkspo-1.5);    % PHOSPHOREGULATION 
xsss = 1/(1+exp(-(y(48)-xs05)/16.7));
tauxs = 1/(7.19e-5*(y(48)+30)/(1-exp(-0.148*(y(48)+30)))+1.31e-4*(y(48)+30)/(exp(0.0687*(y(48)+30))-1)); 
ydot(41) = 1e3*(xsss-y(41))/tauxs;
I_ks = gks*y(41)^2*(y(48)-eks);

%% I_ki: Time-Independent K Current
aki = 1.02/(1+exp(0.2385*(y(48)-ek-59.215)));
bki =(0.49124*exp(0.08032*(y(48)+5.476-ek)) + exp(0.06175*(y(48)-ek-594.31))) /(1 + exp(-0.5143*(y(48)-ek+4.753)));
kiss = aki/(aki+bki);
I_ki = p(99)*sqrt(p(94)/5.4)*kiss*(y(48)-ek);

%% I_kp: Plateau K Current
kp = 1/(1+exp((7.488-y(48))/5.98));
I_kp = p(100)*kp*(y(48)-ek);

%% I_ncx: Na/Ca Exchanger Current
s4 = exp(p(113)*y(48)*FoRT)*y(45)^3*p(95);
s5 = exp((p(113)-1)*y(48)*FoRT)*p(93)^3*y(47);
I_ncx = p(109)/(p(110)^3+p(93)^3) /(p(111)+p(95)) /(1+p(112)*exp((p(113)-1)*y(48)*FoRT)) *(s4-s5);

%% I_nak: Na/K Pump Current
sigma = (exp(p(93)/67.3)-1)/7;
fnak = 1/(1+0.1245*exp(-0.1*y(48)*FoRT)+0.0365*sigma*exp(-y(48)*FoRT));
I_nak = p(114) *fnak /(1+(p(115)/y(45))^1.5) *(p(94)/(p(94)+p(116)));

%% I_ns: Nonspecific Calcium-activated Current
ibarnsk = p(121)*(y(48)*Frdy*FoRT)*(0.75*y(46)*exp(y(48)*FoRT)-0.75*p(94)) /(exp(y(48)*FoRT)-1);
ibarnsna = p(121)*(y(48)*Frdy*FoRT) *(0.75*y(45)*exp(y(48)*FoRT)-0.75*p(93))  /(exp(y(48)*FoRT)-1);
I_nsK = ibarnsk/(1+(p(122)/y(47))^3);
I_nsNa = ibarnsna/(1+(p(122)/y(47))^3);
I_ns = I_nsK + I_nsNa;

%% I_pca: Sarcolemmal Ca Pump Current
I_pca = p(117)*y(47)/(p(118)+y(47));
 
%% I_cab: Ca Background Current
I_cab = p(119)*(y(48)-eca);
 
%% I_nab: Na Background Current
I_nab = p(120)*(y(48)-ena);

%% I_ClCa: Calcium-activated Chloride Current
G_Cl = 0.010;
I_ClCa = G_Cl /(1+0.1e-3/y(47)) * (y(48)-ecl);

%% Total Membrane Currents
I_Na_tot = I_Na+I_nab+3*I_ncx+3*I_nak+I_CaNa+I_nsNa;    % [uA/uF]
I_K_tot = I_to+I_kr+I_ks+I_ki+I_kp-2*I_nak+I_CaK+I_nsK; % [uA/uF]
I_Ca_tot = I_Ca+I_cab+I_pca-2*I_ncx;                    % [uA/uF]

%% Calcium Induced Calcium Release (CICR): Faber/Rudy style
Kmrel = 5*(2/3*(1-fracRyRp)/(1-fracRyRpo)+1/3); % [uA/uF] 
trel = y(49)-4e-3;
ryron = 1/(1+exp(-trel/0.5e-3));  
ryroff = 1-1/(1+exp(-trel/0.5e-3));
grel = p(128)/(1+exp((I_Ca_tot+Kmrel)/0.9))*ryron*ryroff;         
I_relcicr = grel*(y(44)-y(47));          % [mM/sec]

%% Calcium overload release
global jsrol_time;
bcsqn = p(132)*y(44)/(p(133)+y(44));
if (bcsqn > p(131)) & (isempty(jsrol_time) | (t-jsrol_time) > 500e-3)
    jsrol_time = t;
end
t_ol = t-jsrol_time;    
if (t_ol >= 0) & (t_ol <= 100e-3)
    grelol = p(129)*(1-exp(-t_ol/0.5e-3))*exp(-t_ol/0.5e-3);
    I_relol = grelol*(y(44)-y(47));          % [mM/sec]
else
    I_relol = 0;
end
I_rel = I_relcicr+I_relol;

%% Other SR fluxes and concentrations
Bjsr = 1/(1+p(132)*p(133)/(p(133)+y(44))^2);
Km_up = p(124)*(3/4*fracPLB/fracPLBo+1/4);      % PHOSPHOREGULATION
% Shannon Iup
I_up = p(123)*((y(47)/Km_up)^2-(y(43)/3)^2)/(1+(y(47)/Km_up)^2+(y(43)/3)^2);
I_leak = p(123)*y(43)/p(125);                   %   [mM/sec]
I_tr = (y(43)-y(44))/p(134);                    %   [mM/sec]
ydot(43) = I_up-I_leak-I_tr*p(90)/p(89);        %   [mM/sec]
ydot(44) = Bjsr*(I_tr-I_rel);                   %   [mM/sec]
SRcontent = 1e3*((y(44)+y(44)/Bjsr)*p(90)/p(88)+y(43)*p(89)/p(88));    % [umol/L cytosol]

% Cytoplasmic Calcium Buffering
kmtrpn = p(138)*(1.45-0.45*(1-fracTnIp)/(1-fracTnIpo)); % PHOSPHOREGULATION
btrpn = p(135)*kmtrpn/(kmtrpn+y(47))^2;
bcmdn = p(136)*p(139)/(p(139)+y(47))^2;
bindo = p(137)*p(140)/(p(140)+y(47))^2;
Bmyo = 1/( 1+ bcmdn + btrpn + bindo);

%% Ion Concentrations and Membrane Potential
ydot(45) = -1e3*I_Na_tot*p(91)/(p(88)*zna*Frdy);          % [mM/sec] 
ydot(46) = -1e3*I_K_tot*p(91)/(p(88)*zk*Frdy);            % [mM/sec]
ydot(47) = -Bmyo*(1e3*I_Ca_tot*p(91)/(p(88)*zca*Frdy) ...
    +((I_up-I_leak)*p(89)/p(88))-(I_rel*p(90)/p(88)));    % [mM/sec]

%% Simulation type
protocol = 'pace';
rate = p(141);
s2_time = p(144);

switch lower(protocol)
    case {'none',''},
        I_app = 0;
    case 'pace',        % pace w/ current injection at rate 'rate'
	if mod(t+0.9,1/rate) <= 5e-3
        	I_app = 10.0;
	else
        	I_app = 0.0;
	end
    case 's1s2',
	if mod(t+0.9,1/rate) <= 5e-3 & t < 50.15
        	I_app = 10.0;
	elseif mod(t,s2_time) <= 5e-3 & t >= s2_time
		I_app = 10.0;
	else
        	I_app = 0.0;
	end
	
    case 'vclamp',      
	V_hold = p(142);
        V_test = p(143);
	if (t > 0.1 & t < 0.5)
		V_clamp = V_test;
	else
		V_clamp = V_hold;
	end
		R_clamp = 0.02;
		I_app = (V_clamp-y(48))/R_clamp;
end  

ydot(48) = -1e3*(I_Ca_tot+I_K_tot+I_Na_tot+I_ClCa-I_app);

% CICR timing: y(49) tracks the last time when Vdot > 30 mV/msec or Ca overload
if (ydot(48) > 30e3)
    ydot(49) = 1-2e4*y(49); 
else
    ydot(49) = 1;
end
% ----- END EC COUPLING MODEL ---------------