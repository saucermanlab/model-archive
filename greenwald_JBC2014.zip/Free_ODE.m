function dydt=Free_ODE(t,y,params,InhibOpt)

% params=[kesa,kesd,kcat,kppase,kaa,...
%           kab,kad,Etot,A,Stot,...
%           kiaa,kida,Ia,KiATP,ATP,...
%           KmATP,Iatp,kias,kids,Is]

%Enzyme Catalysis (AES) Kinetics
kesa=params(1);
kesd=params(2);
kcat=params(3);

%Phosphatase (PP) Kinetics
kppase=params(4);

%Enzyme Activation Kinetics
kaa=params(5);
kab=params(6);
kad=params(7);

% Activator transport Kinetics
kt = 1;

%Constant Concentrations
Etot =params(8);
Aec    =params(9);
Stot =params(10);


% Model Species
Sp=y(1);     %product
AEiS=y(2);  %enzyme-substrate active intermediate
Ea=y(3);    %Active Enzyme
A = y(4);   % Activator Concentration

% Number of species before inhibition
ConcInd=3;
% Activation Competitive Inhibitor (Ia)
if InhibOpt(1) == 1
    kiaa = params(11);
    kida = params(12);
    Ia   = params(13);
    EIa  = y(ConcInd+1);
    ConcInd = ConcInd + 1;
else
    kiaa = 0;
    kida = 0;
    Ia   = 0;
    EIa  = 0;
end
% ATP Competitive Inhibitor (Iatp)
if InhibOpt(2) == 1
    KiATP = params(14);
    ATP   = params(15);
    KmATP = params(16);
    Iatp  = params(17);
    ATPfrac = ATP/(KmATP*(1 + Iatp/KiATP)+ATP);    
else
    ATPfrac = 1;   
end
% Substrate Competitive Inhibitor (Is)
if InhibOpt(3) == 1
    kias = params(18);
    kids = params(19);
    Is   = params(20);
    EaIs  = y(ConcInd+1);
    EIs  = y(ConcInd+2);
    ConcInd = ConcInd + 2;    
else
    kias = 0;
    kids = 0;
    Is   = 0;
    EaIs  = 0;
    EIs  = 0;
end
    

%% Differential Equations
%%%% Mass Balance Equations
S=Stot-Sp-AEiS;
E=Etot-AEiS-Ea;
% Inhibitor Effect on Mass Balance
E = E - EIa - EaIs - EIs;

%%%% Reactions
R1 = (kaa*A+kab)*E-kad*Ea;      % Enzyme activation
R2 = kesa*S*Ea - kesd*AEiS;     % Enzyme Substrate Association
R3 = kcat*AEiS;                 % Enzyme Catalysis
R4 = kppase*Sp;                 % Substrate dephosphorylation

% Inhibitor Reactions
    % Activation Competitive
R5 = kiaa*Ia*E - kida*EIa;
    % ATP Competitive
R3 = R3*ATPfrac;
    % Substrate Competitive
R6 = kias*Is*Ea - kids*EaIs;
R7 = (kaa*A+kab)*EIs-kad*EaIs;
R8 = kids*EIs;

% Activator Transport
R9 = kt*Aec - kt*A;

%%%% ODEs
% Main Model ODEs
dSp_dt = R3 - R4;
dAEiS_dt = R2 - R3;
dEa_dt = R1 - R2 + R3;
dA_dt = R9;

% Inhibitor ODEs
    % Activation Competitive
dEIa_dt = R5;
    % Substrate Competitive
dEa_dt   = dEa_dt - R6;
dEaIs_dt = R6 + R7;
dEIs_dt  = -R7 - R8;

% Reassemble the ODE vector
dydt = [dSp_dt;dAEiS_dt;dEa_dt;dA_dt];
% Inhibiors
if InhibOpt(1) == 1
    dydt = [dydt;dEIa_dt];
end
if InhibOpt(3) == 1
    dydt = [dydt;dEaIs_dt;dEIs_dt];
end








