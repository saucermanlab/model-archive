%% Scaffold State-Switching model code, Greenwald et al. JBC 2014
% This function uses the model defined in journal the article: 
%
% E.C. Greenwald, J.M. Redden, K.L. Dodge-Kafka and J.J. Saucerman.
% "Scaffold state switching amplifies, accelerates, and insulates Protein
% Kinase C signaling." _JBC_ 2014 289, 2353-2360.
%
% <http://www.ncbi.nlm.nih.gov/pubmed/24302730 [Pubmed]>
% 

%% Model Dependencies
% When run, this function generates the model based figures used in the
% paper. This code has the following global function dependencies:
%
% * Free_ODE.m
% * Scaff_ODE_scaff.m
% * odeEvents.m
% * odeEvents_scaff.m
% * baseParams.m
%
% This function also uses seperate functions to generate each of the figure
% results which have additional subfigure dependencies:
%
% * GreenwaldJBC2014_singleSimulation.m
% * FullDriver_PDBU
% * InhibDriver_PDBu
%

%% Figure 2: Prediction of amplification and acceleration
% this is where I ran the model before fitting
ChangeVect=[];

% use base parameters



% Run Sim
normPlotVal=2;
parOpt = 11;
baseX0= [];
% epsVect = [1,3,10];
epsVect = [1,3,10];
[~,~]=ModelDriver(baseX0,epsVect,2,ChangeVect,normPlotVal,parOpt)
% Plot results

%% Figure 3: Fitting model to experimental data
% Using data from the FRET biosensors CKAR-AKAP7$\alpha$ and myrCKAR we fit
% the model to agree with the experimental data. 
ChangeVect=[4,6,8];
baseEps=5.6971751211;
baseX0= [0.00479772008,0.00457957567,0.039698683537];

% new best fit
% baseEps = 5.25675;
% baseX0 = [0.00473,0.0029,0.0441];

% baseEps=5.7;
% baseX0= [0.0048,0.0046,0.0397];
% baseEps=5.7;
% baseX0= [.0055,0.003,0.01];
                                 
% baseX0=[.0055,.003,.1];

% Run Sim
normPlotVal=2;
parOpt = 11;
    bounds(1,:)=baseX0*.01;
    bounds(2,:)=baseX0*100;
    bounds(1,1) = .99;
%     
%     [norm,xnew]=FullDriver_PDBU(baseX0,1,ChangeVect,normPlotVal,parOpt,bounds)
[~,~]=ModelDriver(baseX0,baseEps,1,ChangeVect,normPlotVal,parOpt)
    
%% Pre Fit model
% baseX0 = [2,0.0055,0.003,.1];

%% look at global search results
% baseX0 = x_new_vals_all(641,:);
% baseX0 = [13.8633 .0064 .5558 .0150];
% baseX0 = [14.55397 0.00652 1.74328 0.01444]

%% try different epsilon values for fig2 plot
% baseX0 = [1,0.004733364784829,0.0029139599879620,.044135903800301];
% baseX0 = [5,0.004733364784829,0.0029139599879620,.044135903800301];
% baseX0 = [10,0.004733364784829,0.0029139599879620,.044135903800301];

%% Test Higher PKC Conc
% baseX0= [5.69717512112645,4,0.004579575671098,16];
% baseX0= [5.69717512112645,0.004797720089586,0,0.0396986835372648];