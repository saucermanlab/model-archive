function ymodel=FreeODEdriver(ParamVector,InhibOpt,tPC,DoseTime)

%% Pull kinetic parameters from ParamVector Cell
[kesa,kesd,kcat,kppase,kaa,...
    kab,kad,Etot,A,Stot,...
    kiaa,kida,Ia,KiATP,ATP,...
    KmATP,Iatp,kias,kids,Is]=ParamVector{:};
% verify using assumption of total substrate being equal to total enzyme
Stot=Etot;

%Re-package kinetic parameters to vector, with no inhibitors and no
%activators
kvals=[kesa,kesd,kcat,kppase,kaa,...
    kab,kad,Etot,0,Stot,...
    kiaa,kida,0,KiATP,ATP,...
    KmATP,0,kias,kids,0];

% kesa,kesd,kesc,kpc,Kmp,...
%         kaa,kab,kad,kt,Kip,...
%         PPtot,Etot,0,0,Stot,...
%         keia1,keid1,0,keia2,keid2,...
%         0,keia3,keid3,0,Ki4,...
%         0,ATP,KmATP];
    NumVars=4;
%Inhibitor 1 
if InhibOpt(1)==1
    NumVars=NumVars+1;
end
%Inhibitor 2
if InhibOpt(2)==1
    NumVars=NumVars;
end
%Inhibitor 3
if InhibOpt(3)==1
    NumVars=NumVars+2;
end
%% Initial Equilibrium
%initial concentrations
C0=zeros(1,NumVars);

% set up run parameters
% define a long run time to let the model come to equilibrium
del_t1=100000;
% set up global parameters for the ODE events
global t0val colval
% Define the global initial time so the ODE events can start checking after
% that time has passed
t0val=0;
% Define which ouput columns are used to determine equilibrium
colval=1;
% define an ODE events file to stop simulating when equilibrium has been
% reached
options=odeset('Events',@odeEvents_Free,'MaxStep',15);
%run the simulation
[t,C]=ode15s(@(t,y) Free_ODE(t,y,kvals,InhibOpt),[t0val del_t1],C0,options);

%% Define basal time period before first stimulation
nInit=find(tPC==DoseTime(1));
tSSinit=tPC(1:nInit);
tMod=t-max(t)+max(tSSinit);
tstart=find(tMod<0,1,'last');
ySSinit=interp1(tMod(tstart:end),C(tstart:end,:),tSSinit);
ymodelinit=ySSinit(:,1)./Stot;
%% Simulate Activation of PKC with PDBu
% Define kinetic parameters with the Activator (A) present
kvals_new=kvals;kvals_new(9)=A;
% Define initial conditions from the equilibrium
C0_new=ySSinit(end,:);
% t0val=tMod(end);
% t0val=tPC(nInit);
% del_t2=14.5*60;
% define ODE options w/o ODE events file
options2=odeset('MaxStep',15);
[t1,C1]=ode15s(@(t,y) Free_ODE(t,y,kvals_new,InhibOpt),tPC(nInit:end),C0_new,options2);
% t1model=[tPC(1:nInit);t1(2:end)];
ymodel=[ymodelinit;C1(2:end,1)./Stot];



