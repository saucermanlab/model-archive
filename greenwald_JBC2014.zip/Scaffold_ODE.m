function dydt=Scaffold_ODE(t,y,params,InhibOpt)

% params = [ke,kesd,kcat,kppase,kaa,...
%     kab,kad,EStot,A,~,...
%     kiaa,kida,Ia,KiATP,ATP,...
%     KmATP,Iatp,kias,kids,Is];

%Enzyme Catalysis (AES) Kinetics
ke=params(1);
kesd=params(2);
kcat=params(3);

%Phosphatase (PP) Kinetics
kppase=params(4);

%Activator Kinetics
kaa=params(5);
kab=params(6);
kad=params(7);

% Activator Transport Kinetics
kt = 1;

%Constant Concentrations
EStot=params(8);
Aec=params(9);

% Model Species
EaSp=y(1);
ESp=y(2);
AEiS=y(3);
EaS=y(4);
A = y(5);

% Number of species before inhibition
ConcInd=4;
% Activation Competitive Inhibitor (Ia)
if InhibOpt(1) == 1
    kiaa = params(11);
    kida = params(12);
    Ia   = params(13);
    EIaS  = y(ConcInd+1);
    EIaSp = y(ConcInd+2);
    ConcInd = ConcInd + 2;
else
    kiaa = 0;
    kida = 0;
    Ia   = 0;
    EIaS  = 0;
    EIaSp = 0;
end
% ATP Competitive Inhibitor (Iatp)
if InhibOpt(2) == 1
    KiATP = params(14);
    ATP   = params(15);
    KmATP = params(16);
    Iatp  = params(17);
    ATPfrac = ATP/(KmATP*(1 + Iatp/KiATP)+ATP);    
else
    ATPfrac = 1;   
end
% Substrate Competitive Inhibitor (Is)
if InhibOpt(3) == 1
    kias = params(18);
    kids = params(19);
    Is   = params(20);
    EaIsS  = y(ConcInd+1);
    EIsS  = y(ConcInd+2);
    EaIsSp  = y(ConcInd+3);
    EIsSp  = y(ConcInd+4);
    ConcInd = ConcInd + 4;    
else
    kias = 0;
    kids = 0;
    Is   = 0;
    EaIsS  = 0;
    EIsS  = 0;
    EaIsSp  = 0;
    EIsSp  = 0;
end


%% Differential Equations
%%%% Mass Balance Equation
ES = EStot - EaS - AEiS - EaSp - ESp;
% Inhibitor Effect on Mass Balance
ES = ES - EIaS - EIaSp - EaIsS - EIsS - EaIsSp - EIsSp;

%%%% Reactions
R1s = (kaa*A+kab)*ES-kad*EaS;
R2s = ke*EaS-kesd*AEiS;
R3s = kcat*AEiS;
R4s = kppase*EaSp;
R5s = (kaa*A+kab)*ESp-kad*EaSp;
R6s = kppase*ESp;

%Inhibitor Reactions
    % Activation Competitive
R7s = kiaa*Ia*ES-kida*EIaS;
R8s = kiaa*Ia*ESp - kida*EIaSp;
R9s = kppase*EIaSp;
    % ATP Competitive
R3s = R3s*ATPfrac;
    %Substrate Competitive
R10s = kias*Is*EaS - kids*EaIsS;
R11s = (kaa*A+kab)*EIsS - kad*EaIsS;
R12s = kids*EIsS;
R13s = kias*Is*EaSp - kids*EaIsSp;
R14s = (kaa*A+kab)*EIsSp - kad*EaIsSp;
R15s = kids*EIsSp;
R16s = kppase*EaIsSp;
R17s = kppase*EIsSp;

R18s = kt*Aec - kt*A;

%%%% ODEs
% Main Model ODEs
dEaSp_dt = R3s - R4s + R5s;
dESp_dt  = -R5s - R6s;
dAEiS_dt = R2s - R3s;
dEaS_dt  = R1s - R2s + R4s;
dA_dt = R18s;

% Inhibitor ODEs
dEaSp_dt  = dEaSp_dt - R13s;
dESp_dt   = dESp_dt - R8s + R15s;
dEaS_dt   = dEaS_dt - R10s;
dEIaS_dt  = R7s + R9s;
dEIaSp_dt = R8s - R9s;
dEaIsS_dt = R10s + R11s + R16s;
dEIsS_dt  = -R11s - R12s + R17s;
dEaIsSp_dt= R13s + R14s - R16s;
dEIsSp_dt = -R14s - R15s - R17s;

% Reassemble the ODE vector
dydt = [dEaSp_dt;dESp_dt;dAEiS_dt;dEaS_dt;dA_dt];
if InhibOpt(1) == 1
    dydt = [dydt;dEIaS_dt;dEIaSp_dt];
end
if InhibOpt(3) == 1
    dydt = [dydt;dEaIsS_dt;dEIsS_dt;dEaIsSp_dt;dEIsSp_dt];
end

