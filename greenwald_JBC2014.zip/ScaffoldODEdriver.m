function ymodel=ScaffoldODEdriver(eps,ParamVector,InhibOpt,tPC,DoseTime)

%rate parameters

[kesa,kesd,kcat,kppase,kaa,...
    kab,kad,Etot,A,Stot,...
    kiaa,kida,Ia,KiATP,ATP,...
    KmATP,Iatp,kias,kids,Is]=ParamVector{:};
% kvals=[kra*k_accl,krd,krc,kpc,kmp,kkaa,kkab,kkd,kt,kkia,kkid,kpi,...
%     Ptot,KRtot,0,0,0];
% kesd=4*kesc;
EStot=Etot;

% kvals=[kesa*eps*EStot,kesd,kesc,kpc,Kmp,...
%         kaa,kab,kad,kt,Kip,...
%         PPtot,0,0,0,EStot,...
%         keia1,keid1,0,keia2,keid2,...
%         0,keia3,keid3,0,Ki4,...
%         0,ATP,KmATP];
kvals=[kesa*eps*EStot,kesd,kcat,kppase,kaa,...
    kab,kad,Etot,0,0,...
    kiaa,kida,0,KiATP,ATP,...
    KmATP,0,kias,kids,0];


    
NumVars=5;
ProdVect=[1,2];
    %Inhibitor 1 
if InhibOpt(1)==1
    ProdVect=[ProdVect,NumVars+2];
    NumVars=NumVars+2;
end
%Inhibitor 3
if InhibOpt(3)==1
    ProdVect=[ProdVect,NumVars+3,NumVars+4];
    NumVars=NumVars+4;
end


%% Initial Equilibrium
C0=zeros(1,NumVars);
% C0(1)=testval;
% C0=[0,0,0,0,0,0,0];
%run the simulation
del_t1=100000;
global t0val colval
t0val=0;colval=ProdVect;
options=odeset('Events',@odeEvents_Scaffold,'MaxStep',30);
[t,C]=ode15s(@(t,y) Scaffold_ODE(t,y,kvals,InhibOpt),[t0val del_t1],C0,options);

nInit=find(tPC==DoseTime(1));
tSSinit=tPC(1:nInit);
% tSSinit=0:.25*60:.75*60;
tMod=t-max(t)+max(tSSinit);
tstart=find(tMod<0,1,'last');
ySSinit=interp1(tMod(tstart:end),C(tstart:end,:),tSSinit);
ymodelinit=sum(ySSinit(:,ProdVect),2)./EStot;

%% PdBu Stimulation
% nPPase=find(tPC==DoseTime(2));
kvals_new=kvals;kvals_new(9)=A;
C0_new=ySSinit(end,:);


options2=odeset('MaxStep',30);
[t1,C1]=ode15s(@(t,y) Scaffold_ODE(t,y,kvals_new,InhibOpt),tPC(nInit:end),C0_new,options2);
t1model=[tPC(1:nInit);t1(2:end)];
y1model=[ymodelinit;sum(C1(2:end,ProdVect),2)./EStot];
% t2model=[tPC(1:nInit);t1(2:45)];
% y2SSinterm=C1(45,:);
% y2model=[ymodelinit;sum(C1(2:45,ProdVect),2)./EStot];

% t_PDBu=[t;t3(2:end)];
% C_PDBu=[C;C3(2:end,:)];
% tstart=find(t_PDBu>=t3(1)-2*60,1,'first');
% 
% range=nvect(1)+1:nvect(1)+nvect(2);
% 
% ymodel2=interp1((t_PDBu(tstart:end)-t_PDBu(tstart))/60,sum(C_PDBu(tstart:end,ProdVect),2)./EStot,xpoint(range));
% ymodel2=interp1((t_PDBu(tstart:end)-t_PDBu(tstart))/60,C_PDBu(tstart:end,1)./Ktot,xpoint);

% %% PPase Inhibitor 
% 
% % PI0_new=50;     %uM
% % kvals_new=kvals_new;
% kvals_new=kvals;
% kvals_new(14)=Aec;
% kvals_new(13)=PPItot;
% C0_new=C1(end,:);
% % t0val=t1model(end);
% t0val=tPC(nPPase);
% % del_t2=10*60;
% [t2,C2]=ode15s(@(t,y) AllInhib_ODE_scaff(t,y,kvals_new,InhibOpt),tPC(nPPase:end),C0_new,options2);
% t1model=[tPC(1:nPPase);t2(2:end)];
% y1model=[y1model;sum(C2(2:end,ProdVect),2)./EStot];

% t_PI=[t_PDBu;t4(2:end)];
% C_PI=[C_PDBu;C4(2:end,:)];
% tstart=find(t_PI>=t4(1)-1*60,1,'first');
% range=nvect(1)+nvect(2)+1:nvect(1)+nvect(2)+nvect(3);
% ymodel3=interp1((t_PI(tstart:end)-t_PI(tstart))/60,sum(C_PI(tstart:end,ProdVect),2)./EStot,xpoint(range));


%% PKC inhibitor
% nInit=find(tG==DoseTime(1));
% tSSinit=tG(1:nInit);
% tMod=t-max(t)+max(tSSinit);
% tstart=find(tMod<0,1,'last');
% ySSinit=interp1(tMod(tstart:end),C(tstart:end,:),tSSinit);
% ymodelinit=sum(ySSinit(:,ProdVect),2)./EStot;
% 
% % PKC_I_new=.5;     %uM
% kvals_new=kvals;
% % kvals_new(14)=Aec;
% %Inhibitor 1 
% if InhibOpt(1)==1
%     kvals_new(18)=I1;
% end
% %Inhibitor 2
% if InhibOpt(2)==1
%     kvals_new(21)=I2;
% end
% %Inhibitor 3
% if InhibOpt(3)==1
%     kvals_new(24)=I3;
% end
% %ATP mimic inhibitor
% if InhibOpt(4)==1
%     kvals_new(26)=I4;
% end
% % kvals_new=kvals;
% % kvals_new(16)=KI;
% % t0val=t2model(end);
% t0val=tG(nInit);
% % C0_new=y2SSinterm;
% C0_new = ySSinit(end,:);
% % del_t2=11*60;
% options2=odeset('MaxStep',5);
% [t3,C3]=ode15s(@(t,y) AllInhib_ODE_scaff(t,y,kvals_new,InhibOpt),tG(nInit:end),C0_new,options2);
% t2model=[tG(1:nInit);t3(2:end)];
% y2model=[ymodelinit;sum(C3(2:end,ProdVect),2)./EStot];

% ymodel=[y1model;y2model];
ymodel=[y1model];

% t_PKCI=[t;t2(2:end)];
% C_PKCI=[C;C2(2:end,:)];
% tstart=find(t_PKCI>=t2(1)-2*60,1,'first');
% ymodel1=interp1((t_PKCI(tstart:end)-t_PKCI(tstart))/60,sum(C_PKCI(tstart:end,ProdVect),2)./EStot,xpoint(1:nvect(1)));

% %% PdBu Stimulation
% kvals_new=kvals;
% kvals_new(14)=Aec;
% C0_new=C(end,:);
% t0val=t(end);
% del_t2=30*60;
% [t3,C3]=ode15s(@(t,y) AllInhib_ODE_scaff(t,y,kvals_new,InhibOpt),[t0val t0val+del_t2],C0_new,options2);
% t_PDBu=[t;t3(2:end)];
% C_PDBu=[C;C3(2:end,:)];
% tstart=find(t_PDBu>=t3(1)-2*60,1,'first');
% 
% range=nvect(1)+1:nvect(1)+nvect(2);
% 
% ymodel2=interp1((t_PDBu(tstart:end)-t_PDBu(tstart))/60,sum(C_PDBu(tstart:end,ProdVect),2)./EStot,xpoint(range));
% % ymodel2=interp1((t_PDBu(tstart:end)-t_PDBu(tstart))/60,C_PDBu(tstart:end,1)./Ktot,xpoint);
% 
% %% PPase Inhibitor 
% 
% % PI0_new=50;     %uM
% % kvals_new=kvals_new;
% kvals_new(13)=PPItot;
% C0_new=C3(end,:);
% t0val=t3(end);
% del_t2=10*60;
% [t4,C4]=ode15s(@(t,y) AllInhib_ODE_scaff(t,y,kvals_new,InhibOpt),[t0val t0val+del_t2],C0_new,options2);
% t_PI=[t_PDBu;t4(2:end)];
% C_PI=[C_PDBu;C4(2:end,:)];
% tstart=find(t_PI>=t4(1)-1*60,1,'first');
% range=nvect(1)+nvect(2)+1:nvect(1)+nvect(2)+nvect(3);
% ymodel3=interp1((t_PI(tstart:end)-t_PI(tstart))/60,sum(C_PI(tstart:end,ProdVect),2)./EStot,xpoint(range));
% %% Output
% ymodel=[ymodel1;ymodel2;ymodel3];