READ ME

This file contains the code to generate the figures in:

E.C. Greenwald, J.M. Redden, K.L. Dodge-Kafka and J.J. Saucerman. "Scaffold state switching amplifies, accelerates, and insulates Protein Kinase C signaling." _JBC_ 2014 289, 2353-2360.

The function masterCompute.m is the driver function that will generate the figures from the paper. This is a script and when run Figures 2 and 3 are generated. 
Also the folder �ParamSpaceSample� contains the code used to do the latin hypercube parameter space sampling. The folder �DataFromDK� contains the excel spreadsheets with the fret data from the Dodge-Kafka lab. 

Eric Greenwald
5/26/2015
