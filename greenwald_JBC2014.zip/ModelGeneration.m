function [ymodel_norm,ymodel_orig]=ModelGeneration(x,Xpts,ParamVector,changeVect,InhibOpt,showOpt,nVect,DoseTime,FRETpoints,CIopt)
% function [ymodel_both_mod,ymodel_both]=FreeAndScaff_PaperData(x,uselessXpts,FretPoints,ParamVector,changeVect,InhibOpt,showOpt,parOpt)
if CIopt{1}==1 && CIopt{2}==-1
    eps = CIopt{3};
else
    eps=x(1);
    if showOpt==2
        fprintf(' %5.5f',x(1))
    end
end

for k=1:length(changeVect)
    if CIopt{1}==1 && CIopt{2}==-1
        xVal=x(k);
    else
        xVal=x(k+1);
    end
    ParamVector{changeVect(k)}=xVal;
    if showOpt==2
    if x(k)<.001
         fprintf(' %5.5e',xVal)
    else
        fprintf(' %5.5f',xVal)
    end    
    if k==length(changeVect)
        fprintf('\n');
    end
    end
end

%run both at the same time
tPCfree=Xpts(1:nVect(1));
tPC18=Xpts(1+nVect(1):sum(nVect(1:2)));

ymodel_free=FreeODEdriver(ParamVector,InhibOpt,tPCfree,DoseTime);

ymodel_scaff=ScaffoldODEdriver(eps,ParamVector,InhibOpt,tPC18,DoseTime);

ymodel_orig=[ymodel_free;ymodel_scaff];

y_free_1 = ymodel_orig(1:nVect(1));
y_scaff_1 = ymodel_orig(1+nVect(1):sum(nVect(1:2)));

% Linear Mapping of the Model to the Data
        
%scaling factor based on free data
phi = (FRETpoints(1)-1)/(y_free_1(end)-y_free_1(1));

y_free_1 = (y_free_1-y_free_1(1))*phi + 1;
y_scaff_1 = (y_scaff_1-y_scaff_1(1))*phi + 1;
        
ymodel_norm=[y_free_1;y_scaff_1];


        
        
