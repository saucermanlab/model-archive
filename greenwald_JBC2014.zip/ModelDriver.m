function [normVal,x_new]=ModelDriver(x0,epsVect,plotopt,ChangeVector,normplot,parOpt,bounds,CIopt)
if nargin<5
    normplot=0;
    parOpt=0;
    bounds(1,:)=zeros(1,length(x0));
    bounds(2,:)=100000*ones(1,length(x0));
    CIopt = {0,0,0};
elseif nargin<6
    parOpt=0;
    bounds(1,:)=zeros(1,length(x0));
    bounds(2,:)=100000*ones(1,length(x0));
    CIopt = {0,0,0};
elseif nargin<7
    bounds(1,:)=zeros(1,length(x0));
    bounds(2,:)=100000*ones(1,length(x0));
    CIopt = {0,0,0};
elseif nargin<8
    CIopt = {0,0,0};
end

%% Load Data

% load fittingData_2012_11_14.mat
load fittingData.mat
yPCfree    =myrCKARPDBU(:,2);
tPCfree    =myrCKARPDBU(:,1);
yPC18      =CKAR7PDBU(:,2);
tPC18      =CKAR7PDBU(:,1);
DoseTime = tPCfree(4,1);
DoseTime=DoseTime*60;
FRETpoints = [max(yPCfree), max(yPC18)];


%% Define parameters
OrigParams=OriginalParameters(x0,ChangeVector);

[kesa,kesd,kcat,kppase,kaa,...
      kab,kad,Etot,A,Stot,...
      kiaa,kida,Ia,KiATP,ATP,...
      KmATP,Iatp,kias,kids,Is]=OrigParams{:};

Stot=Etot;
InhibOpt=[0,1,0];

ParamVector={kesa,kesd,kcat,kppase,kaa,...
                kab,kad,Etot,A,Stot,...
                kiaa,kida,Ia,KiATP,ATP,...
                KmATP,Iatp,kias,kids,Is};
%% Opt

opt=1; 

xGroup=[tPCfree;tPC18]*60;
yGroup=[yPCfree;yPC18];
n1 = length(tPCfree);
n3 = length(tPC18);
nVect =[n1,n3];


%% Change Vector
if nargin<3
    ChangeVector=[1,9,12];
end
%% Fn eval
choice=plotopt;
% choice=2;
switch choice
    case 1
        %% Fit both at the same time
        valsGuess=[epsVect,x0];
        lb=bounds(1,:);
        ub=bounds(2,:);
        options=optimset('TolX',min(x0)*1e-4,'Display','off');
        for k = 1:3
        [x_new,normVal,residual,exitflag,output,lambda,jacobian]=lsqcurvefit(@(x,xpoints)ModelGeneration(x,xpoints,ParamVector,ChangeVector,InhibOpt,2,nVect,DoseTime,FRETpoints,CIopt),valsGuess,xGroup,yGroup,lb,ub,options);
            ci = nlparci(x_new,residual,'Jacobian',jacobian)
            jsqr = jacobian'*jacobian;
            condNumb = cond(full(jsqr))
            valsGuess = x_new;
        end
        [yGroupSim,yGroupSimOrig]=ModelGeneration(x_new,xGroup,ParamVector,ChangeVector,InhibOpt,parOpt,nVect,DoseTime,FRETpoints,CIopt);
%         plotopt=1;
    case 2
        % Dont fit just run the simulation
        modelOpt = 1; %Run both at the same time
        yGroupSimAll = [];
        LegVect = {'Free'};
        for k = 1: length(epsVect)
        xIn = [epsVect(k),x0];
        [yGroupSim,yGroupSimOrig]=ModelGeneration(xIn,xGroup,ParamVector,ChangeVector,InhibOpt,plotopt,nVect,DoseTime,FRETpoints,CIopt);
        x_new=x0;
        normVal=norm(yGroupSim-yGroup,2)^2;
        yGroupSimAll = [yGroupSimAll,yGroupSimOrig];
        LegVect{1,k+1} = strcat('\epsilon = ',num2str(epsVect(k)));
        end
    
end
% xnew=x_new;

%% Plot
switch choice
    case 1
        figure
        subplot(1,4,1:2)
        hold off
        plot(xGroup(1+n1:n1+n3)/60,yGroup(1+n1:n1+n3),'rs:');hold on;
        plot(xGroup(1+n1:n1+n3)/60,yGroupSim(1+n1:n1+n3),'r');hold on;
        plot(xGroup(1:n1)/60,yGroup(1:n1),'b*:');hold on;
        plot(xGroup(1:n1)/60,yGroupSim(1:n1),'b');
        
        legend('Data - AKAP7-CKAR','Model - AKAP7-CKAR','Data - myrCKAR','Model - myrCKAR',4)
        title('Model Fit to Data')
        xlabel('Time (min)')
        ylabel('Fret Ratio')
        
        ySimFRET_free = yGroupSim(1:n1);
        ySimFRET_scaf = yGroupSim(1+n1:n1+n3);
        ySimModel_free = yGroupSimOrig(1:n1);
        ySimModel_scaf = yGroupSimOrig(1+n1:n1+n3);
        
        subplot(1,4,3)
        hold off
        plot(xGroup(1+n1:n1+n3)/60,ySimFRET_scaf,'r'); hold on;
        plot(xGroup(1:n1)/60,ySimFRET_free,'b');
        title('"normalized" to FRET data')
        xlabel('Time (min)')
        ylabel('"Fret Change" ')
        
        subplot(1,4,4)
        hold off
        plot(xGroup(1+n1:n1+n3)/60,ySimModel_scaf,'r'); hold on
        plot(xGroup(1:n1)/60,ySimModel_free,'b');
        ylim([0 1])
        title('Original Model Output')
        xlabel('Time (min)')
        ylabel('Fraction Phosp. ')
    case 2
        figure
        ySimModel_free = yGroupSimAll(1:n1,1);
        ySimModel_scaf = yGroupSimAll(1+n1:n1+n3,:);
        hold off
        plot(xGroup(1+n1:n1+n3)/60,ySimModel_free,'--k');hold on
        plot(xGroup(1:n1)/60,ySimModel_scaf)
        
        ylim([0 1])
        legend(LegVect,4)
       
        
end


if plotopt==1
%     figure
%     plot(xGroup(1:n1)/60,yGroup(1:n1),'b*:');hold on;
%     plot(xGroup(1:n1)/60,yGroupSim(1:n1),'b');
%     legend('Data - PDBu','Model - PDBu')
%     title('myrCKAR')
%     xlabel('Time (min)')
%     ylabel('Fret Ratio')
%     
%     figure
%     plot(xGroup(1+n1:n1+n3)/60,yGroup(1+n1:n1+n3),'b*:');hold on;
%     plot(xGroup(1+n1:n1+n3)/60,yGroupSim(1+n1:n1+n3),'b');hold on;
%     legend('Data - PDBu','Model - PDBu');
%     title('AKAP7-CKAR')
%     xlabel('Time (min)')
%     ylabel('FRET Ratio')
    
%     figure
%     subplot(1,4,1:2)
%     hold off
%     plot(xGroup(1+n1:n1+n3)/60,yGroup(1+n1:n1+n3),'rs:');hold on;
%     plot(xGroup(1+n1:n1+n3)/60,yGroupSim(1+n1:n1+n3),'r');hold on;
%     plot(xGroup(1:n1)/60,yGroup(1:n1),'b*:');hold on;
%     plot(xGroup(1:n1)/60,yGroupSim(1:n1),'b');
% 
%     legend('Data - AKAP7-CKAR','Model - AKAP7-CKAR','Data - myrCKAR','Model - myrCKAR','Location','WestOutside')
%     title('Model Fit to Data')
%     xlabel('Time (min)')
%     ylabel('Fret Ratio')
% 
%     ySimFRET_free = yGroupSim(1:n1);
%     ySimFRET_scaf = yGroupSim(1+n1:n1+n3);
%     ySimModel_free = yGroupSimOrig(1:n1);
%     ySimModel_scaf = yGroupSimOrig(1+n1:n1+n3);
%     
%     yOutput = [ySimFRET_free,ySimFRET_scaf,ySimModel_free,ySimModel_scaf];
%     save simOutput yOutput
%     
% %     figure
% %     subplot(2,1,1)
%     subplot(1,4,3)
%     hold off
%     plot(xGroup(1+n1:n1+n3)/60,ySimFRET_scaf,'r'); hold on;
%     plot(xGroup(1:n1)/60,ySimFRET_free,'b');
%  
% %     plot(xGroup(1+n1:n1+n2)/60,yGroupSim(1+n1:n1+n2),'b')
% %     plot(xGroup(1+n1+n2+n3:n1+n2+n3+n4)/60,yGroupSim(1+n1+n2+n3:n1+n2+n3+n4),'r')
% %     legend('Model AKAP7-CKAR','Model myrCKAR',2) 
%     title('"normalized" to FRET data')
%     xlabel('Time (min)')
%     ylabel('"Fret Change" ')
%     
% %     subplot(2,1,2)
%     subplot(1,4,4)
%     hold off
%     plot(xGroup(1+n1:n1+n3)/60,ySimModel_scaf,'r'); hold on
%     plot(xGroup(1:n1)/60,ySimModel_free,'b');
%  
% %     plot(xGroup(1+n1:n1+n2)/60,yGroupSimOrig(1+n1:n1+n2),'b')
% %     plot(xGroup(1+n1+n2+n3:n1+n2+n3+n4)/60,yGroupSimOrig(1+n1+n2+n3:n1+n2+n3+n4),'r')
% ylim([0 1])
% %     legend('Model AKAP7-CKAR','Model myrCKAR',2) 
%     title('Original Model Output')
%     xlabel('Time (min)')
%     ylabel('Fraction Phosp. ')
    
    
    
    
%         figure
%     plot(xGroup(1:n1)/60,yGroup(1:n1),'b*:');hold on;
%     plot(xGroup(1:n1)/60,yGroupSim_mod(1:n1),'b');
%     plot(xGroup(1+n1:n1+n2)/60,yGroup(1+n1:n1+n2),'r*:')    
%     plot(xGroup(1+n1:n1+n2)/60,yGroupSim_mod(1+n1:n1+n2),'r')
%     legend('Data - PDBu + CalyA','Model - PDBu + CalyA','Data - Go6976','Model) - Go6976')
%     title('myrCKAr')
%     xlabel('Time (min)')
%     ylabel('Fret Ratio')
%     
%     figure
%     plot(xGroup(1+n1+n2:n1+n2+n3)/60,yGroup(1+n1+n2:n1+n2+n3),'b*:');hold on;
%     plot(xGroup(1+n1+n2:n1+n2+n3)/60,yGroupSim_mod(1+n1+n2:n1+n2+n3),'b');hold on;
%     plot(xGroup(1+n1+n2+n3:n1+n2+n3+n4)/60,yGroup(1+n1+n2+n3:n1+n2+n3+n4),'r*:')
%     plot(xGroup(1+n1+n2+n3:n1+n2+n3+n4)/60,yGroupSim_mod(1+n1+n2+n3:n1+n2+n3+n4),'r')
%     legend('Data - PDBu + CalyA','Model - PDBu + CalyA','Data - Go6976','Model) - Go6976')
%     title('CKAR 18')
%     xlabel('Time (min)')
%     ylabel('Fret Ratio')
end

end
    
    
   

