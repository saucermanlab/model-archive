%% Model Parameter functions
% This function contains the rate constants used in the model and was used
% to change different parameters during the fitting process. See Greenwald
% JBC 2014 supplement for sources and explanation.

function params=OriginalParameters(ChangeVals,ChangeVect)

%% CKAR kinetic parameters
% PKC Catalysis Kinetics
kcat=4.4;                   % [s^-1] catalytic rate constant
KmPKC = 57;                 % [s^-1 uM^-1] Michaelis-Menten Constant (Km)
kesd=4*kcat;                % [s^-1] enzyme-substrate dissociation rate
kesa = (kcat+kesd)/KmPKC;   % [s^-1 uM^-1] enzyme-substrate association rate

% PKC Activation Kinetics
Kd_PDBu=.00799;             % [uM] dissociation constant for PDBu binding (Kd)
kad=.778/60;                % [s^-1] rate of PDBu dissociation
kaa=kad/Kd_PDBu;            % [s^-1 uM^-1] rate of PDBu association
kab=0.003;%1.08564e-004;       	% [s^-1] basal PKC activity

% Phosphatase Kinetics
kppase = .0055;             % [s^-1] linear rate of dephosporylation
             
% Concentrations
Etot = 0.1;                 % [uM] total enzyme concentration
A = 0.25;                      % [uM] Activator (PDBu) concentration
Stot = Etot;                % [uM] Total substrate concentration

%% PKC inhibtor kinetic parameters
% Activation Competitive Inhibitors (Calphostin C)
kiaa=kaa;                   % [s^-1 uM^-1] Rate of inhibitor association, assume similar to PDBU
Kia=4.48e-4;                % [uM] Inhibition constant (Ki) for Calphostin C
kida=kiaa*Kia;              % [s^-1] Inhibitor rate of dissociation
Ia = 0.1;                   % [uM] Inhibitor concentration

% ATP Competitive inhibitors (Go 6976)
KiATP = .0028;              % [uM] Inhibition constant (Ki) for Go6976 vs ATP 
ATP=5000;                   % [uM] Concentration of ATP in the cell
KmATP = 24;                 % [uM] Michaelis-Menten Constant (Km) of ATP for PKC
Iatp=1;                     % [uM] Inhibitor concentration

% Substrate Competitive Inhibitors (PKC 20-28)
kias = kesa;                % [s^-1 uM^-1] Rate of inhibitor association, assume similar to substrate
Ki_1 = 8;                   % [uM] Inhibition constant (Ki) for PKC 20-28, Assume the Ki is similar to the IC50
kids = Ki_1*kias;           % [s^-1] Inhibitor rate of dissociation
Is = 16;                    % [uM] Inhibitor concentration

%% Pack variables into a Cell array
params={kesa,kesd,kcat,kppase,kaa,...
          kab,kad,Etot,A,Stot,...
          kiaa,kida,Ia,KiATP,ATP,...
          KmATP,Iatp,kias,kids,Is};
%% Change variables that are fed into the function
for k=1:length(ChangeVect)
    params{ChangeVect(k)}=ChangeVals(k);
end
%ensure that total enzyme concentration is kept the same a substrate
%concentration
params{10}=params{8};