function [value,isterminal,direction]=odeEvents_Scaffold(t,y)
global yold told t0val tstable tchecker

tol=1e-9;
% colval=1;

if t==t0val
    value=1;
%     yold=y(1)+y(2);
    yold=sum(y(1:3));    
    told=t;
    tchecker=1;
    tstable=100000;
else
    yval=sum(y(1:3));  
    slope=(yval-yold)/(t-told);
    
    testval=slope/yval;
    if testval<tol && tchecker==1
        tstable=t;
        tchecker=0;
        value=1;
    elseif tstable+2*60<=t
        value=0;
    else
        value=1;
    end
    yold=yval;
    told=t;
end
isterminal=1;
direction=0;