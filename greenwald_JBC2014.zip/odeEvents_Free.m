function [value,isterminal,direction]=odeEvents_Free(t,y)
global yold told t0val tstable tchecker colval

tol=1e-8;
% colval=1;

if t==t0val
    value=1;
    yold=sum(y(colval));
    told=t;
    tchecker=1;
    tstable=100000;
else
    slope=(sum(y(colval))-yold)/(t-told);
    
    testval=abs(slope/sum(y(colval)));
    if testval<tol && tchecker==1
        tstable=t;
        tchecker=0;
        value=1;
    elseif tstable+2*60<=t
        value=0;
    else
        value=1;
    end
    yold=sum(y(colval));
    told=t;
end
isterminal=1;
direction=0;