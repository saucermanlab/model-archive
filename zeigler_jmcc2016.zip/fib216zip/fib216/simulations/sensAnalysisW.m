function [colScore] = sensAnalysisW(paramName,modelName,perturb,infname,colName)
% Sensitivity analysis

%parameters and initial conditions
eval(strcat('[params,y0] = ',paramName,';'));
tspan = [0 700]; 
options = [];

%pull parameters out in order to alter them in the loop without negating
%the previous alteration
[rpar,tau,ymax,speciesNames]=params{:}; 
w = rpar(1,:);
n = rpar(2,:);
EC50 = rpar(3,:);

%perturbations above the control conditions
wNew = w;
eval(perturb)
rpar = [wNew;n;EC50];
params = {rpar,tau,ymax,speciesNames};


%default simulation creating a vector showing steady state activation of
%all species
eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
yEnd0(:,1) = y(end,:);


%preturbed simulations
yEnd1 = zeros(length(y0));
sens = zeros(length(y0));
deltaP = -1; %complete knockout



%full sensitivity analysis of full KO
for i = 1:length(ymax);
    disp(['KD # ',num2str(i),' of ', num2str(length(ymax))])
    
    ymaxNew = ymax;
    ymaxNew(i) = (1+deltaP)*ymax(i);  
    params = {rpar,tau,ymaxNew,speciesNames};

    tspan = [0 700]; 
    options = []; 
    eval(['[~,y2] = ode15s(@',modelName,', tspan, yEnd0, options, params);']);
    yEnd1(:,i) = y2(end,:)';
    sens(:,i) = (yEnd1(:,i) - yEnd0)/(ymaxNew(i) - ymax(i))*ymax(i)./ymax'; %expressing sensitivity as the difference in activity
    sens(:,i) = yEnd1(:,i) - yEnd0;
    
    colScore(i) = yEnd1(90,i)/yEnd0(90);
end

figure
cmaprange = [0.5:0.01:1];
blank = [zeros(1,length(cmaprange) - 20), 0.01:0.05:1];
myrgbcmap = [blank',blank',cmaprange';1 1 1; flipud(cmaprange'),flipud(blank'),flipud(blank')];
colormap(myrgbcmap);
sens = real(sens);
maxVal = max(max(sens));
caxis([-maxVal, maxVal]);
imagesc(sens,[-maxVal,maxVal]);
set(gca,'XAxisLocation','bottom');
set(gca,'XTick',1:length(speciesNames));
set(gca,'XTickLabel',speciesNames,'fontsize',8);
xticklabel_rotate;
xlabel('Perturbation');
set(gca,'YTick',1:length(speciesNames));
set(gca,'YTickLabel',speciesNames,'fontsize',7);
ylabel('Sensitivity of Outputs');
title(['Sensitivity Analysis']);
colorbar;
 

%%
% this section writes node attributes based on three different metrics. 
t = 0.25;
    for i = 1:size(sens,2)
        num(i) = sum(abs(sens(:,i))>t*yEnd0);
    end
    exportNodeAttributes(infname, 'Influence', speciesNames, num);
    
%         colScore = sum(real(sens(88:89,:)),1);
    colScore = real(colScore);
    exportNodeAttributes(colName, 'Collagen', speciesNames, colScore');

%%
% section that evaluates the most sensitive and most influential nodes
% based on the sum of changes in activity across all KOs or nodes
% respectively%
% Diminished Sensitivity Matrix


% %finds the 10 most changed rows in the sensitivity matrix
% R = sum(abs(sens),2);
% N = sort(R);
% Row = find(R>N((end-10),1));

%uses the most changed columns to generate a new diminished matrix
% Col = [6 7 17 18 19 20 21 57 72 76];
Row = [73 82 83 84 88 89 90 91];

%  %finds the 10 most changed columns in the sensitivity matrix
S = sum(abs(sens(Row,:)));
M = sort(S);
Col = find(S>M(1,(end-10)));

%generates a diminished sensitivity matrix based on the 10 most changed
%rows found in line 55
for i = 1:length(Row);
    for j = 1:length(Col);
        DimSens(i,j) = sens(Row(i),Col(j));
    end
end

for i = 1:length(Row)
    Resp(1,i) = speciesNames(Row(i));
end
for i = 1:length(Col)
    KO(1,i) = speciesNames(Col(i));
end



% makes a figure of the abbreviated snesitivity matrix
figure
cmaprange = [0.5:0.01:1];
blank = [zeros(1,length(cmaprange) - 20), 0.01:0.05:1];
myrgbcmap = [blank',blank',cmaprange';1 1 1; flipud(cmaprange'),flipud(blank'),flipud(blank')];
colormap(myrgbcmap);
DimSens = real(DimSens);
maxVal = max(max(DimSens));
caxis([-0.25, 0.25]);
imagesc(DimSens,[-0.25,0.25]);
set(gca,'XAxisLocation','bottom');
set(gca,'XTick',1:length(KO));
set(gca,'XTickLabel',KO,'fontsize',8);
xticklabel_rotate;
xlabel('Perturbation');
set(gca,'YTick',1:length(Resp));
set(gca,'YTickLabel',Resp,'fontsize',7);
ylabel('Sensitivity of Outputs');
title('Diminished Sensitivity Matrix');
colorbar;



figure
cmaprange = [0.5:0.01:1];
blank = [zeros(1,length(cmaprange) - 20), 0.01:0.05:1];
myrgbcmap = [blank',blank',cmaprange';1 1 1; flipud(cmaprange'),flipud(blank'),flipud(blank')];
colormap(myrgbcmap);
DimSens = real(DimSens);
maxVal = max(max(DimSens));
caxis([-0.25, 0.25]);
imagesc(sens(Row,:),[-0.25,0.25]);
set(gca,'XAxisLocation','bottom');
set(gca,'XTick',1:length(speciesNames));
set(gca,'XTickLabel',speciesNames,'fontsize',8);
xticklabel_rotate;
xlabel('Perturbation');
set(gca,'YTick',1:length(Resp));
set(gca,'YTickLabel',Resp,'fontsize',7);
ylabel('Sensitivity of Outputs');
title('Diminished Sensitivity Matrix');
colorbar;
end