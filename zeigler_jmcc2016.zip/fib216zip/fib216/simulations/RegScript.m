% Script to Find regulators
% uses experimental data from 3T3 cell dose response to identify the input
% level that matches the data most closely quantitatively, then uses that
% input value to simulate the end activity and collagen sensitivity in the
% single and combined inputs

% This data represents the response at the dose used in the subsequent
% combined experiments. Those inputs with a value of 1 are ones which had
% no data
exp_data = [1.230,2.555,1,1.298,1.006,1.181,1.048,1,1.171,1.176,1];
pIn = {'1','2','3','4','5','6','7','8','9','10','11'};
pAll = {'1','2','3','4','5','6','7','8','9','10','11','[1,2,7,9,10]','[4,5,6]'};


% [q,s] = RegFinder(exp_data,pIn,pAll);


%%
% %create a bar graph comparing MMP9 and collagen 1 with control
% paramName = 'modelParams';
% modelName = 'modelODE';
% 
% eval(strcat('[params,y0] = ',paramName,';'));
% tspan = [0 700]; 
% options = [];
% eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
% 
% con = real(y(end,[84,88,90]));
% 
% 
% % extract parameters
%     [rpar,tau,ymax,speciesNames]=params{:}; 
%     w = rpar(1,:);
%     n = rpar(2,:);
%     EC50 = rpar(3,:);
% 
% %Inflammatory
% wNew = w;
% perturb = str2num(pAll{end});
% wNew(perturb) = 0.6;
% 
% rpar = [wNew;n;EC50];
% params = {rpar,tau,ymax,speciesNames};
% 
% eval(['[~,y2] = ode15s(@',modelName,', tspan, y0, options, params);']);
% 
% Inf = real(y2(end,[84,88,90]));
% 
% 
% %proliferative
% wNew = w;
% perturb = str2num(pAll{end-1});
% wNew(perturb) = 0.6;
% 
% rpar = [wNew;n;EC50];
% params = {rpar,tau,ymax,speciesNames};
% 
% eval(['[~,y3] = ode15s(@',modelName,', tspan, y0, options, params);']);
% 
% Pro = real(y3(end,[84,88,90]));
% 
% 
% g1 = [con;Inf];
% g2 = [con;Pro];
% 
% figure
% bar(g1)
% title('inflammatory vs control');
% legend({'control','inflammatory'});
% ylabel('% activity at steady state');
% 
% figure
% bar(g1)
% title('proliferative vs control');
% legend({'control','proliferative'});
% ylabel('% activity at steady state');


%%
%create a bar graph comparing collagen 1 with control in all conditions
%with experimental data
paramName = 'modelParams';
modelName = 'modelODE';
inpt = 0.4;

eval(strcat('[params,y0] = ',paramName,';'));
tspan = [0 700]; 
options = [];
eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);


con = real(y(end,[88,90]));
% conP = real(y(end,[88,90]))./con; %normalized to control

% extract parameters
    [rpar,tau,ymax,speciesNames]=params{:}; 
    w = rpar(1,:);
    n = rpar(2,:);
    EC50 = rpar(3,:);

%TGFB
wNew = w;
perturb = str2num(pAll{end});
wNew(2) = inpt;

rpar = [wNew;n;EC50];
params = {rpar,tau,ymax,speciesNames};

eval(['[~,y2] = ode15s(@',modelName,', tspan, y0, options, params);']);



%IL1
wNew = w;
perturb = str2num(pAll{end});
wNew(5) = inpt;

rpar = [wNew;n;EC50];
params = {rpar,tau,ymax,speciesNames};

eval(['[~,y3] = ode15s(@',modelName,', tspan, y0, options, params);']);

  
%tnfa
wNew = w;
perturb = str2num(pAll{end});
wNew(6) = inpt;

rpar = [wNew;n;EC50];
params = {rpar,tau,ymax,speciesNames};

eval(['[~,y4] = ode15s(@',modelName,', tspan, y0, options, params);']);


%Inflammatory
wNew = w;
perturb = str2num(pAll{end});
wNew(perturb) = inpt;

rpar = [wNew;n;EC50];
params = {rpar,tau,ymax,speciesNames};

eval(['[~,y5] = ode15s(@',modelName,', tspan, y0, options, params);']);



%proliferative
wNew = w;
perturb = str2num(pAll{end-1});
wNew(perturb) = inpt;

rpar = [wNew;n;EC50];
params = {rpar,tau,ymax,speciesNames};

eval(['[~,y6] = ode15s(@',modelName,', tspan, y0, options, params);']);

%normalized to control
con = real(y(end,[88,90]));
conP = real(y(end,[88,90]))./con; %normalized to control
tgfb = real(y2(end,[88,90]))./con; %normalized to control
il1 = real(y3(end,[88,90]))./con; %normalized to control
tnfa = real(y4(end,[88,90]))./con; %normalized to control
Inf = real(y5(end,[88,90]))./con;  %normalized to control
Pro = real(y6(end,[88,90]))./con;  %normalized to control
g1 = [conP;tgfb;Pro;il1;tnfa;Inf];
g2 = [conP(1);tgfb(1);Pro(1);il1(1);tnfa(1);Inf(1)];
g3 = [conP(2);tgfb(2);Pro(2);il1(2);tnfa(2);Inf(2)];
err = [0;0;0;0;0;0];


%normalized to max stimulus
% tgfb = real(y2(end,[88,90]));
% tgfbT = real(y2(end,[88,90]))./tgfb; %normalized to max stimulus
% conT = con./tgfb; %normalized to max stimulus
% il1 = real(y3(end,[88,90]))./tgfb; %normalized to max stimulus
% tnfa = real(y4(end,[88,90]))./tgfb; %normalized to max stimulus
% Inf = real(y5(end,[88,90]))./tgfb;  %normalized to max stimulus
% Pro = real(y6(end,[88,90]))./tgfb; %normalized to max stimulus
% g1 = [conT;tgfbT;Pro;il1;tnfa;Inf];
% g2 = [conT(1);tgfbT(1);Pro(1);il1(1);tnfa(1);Inf(1)];
% g3 = [conT(2);tgfbT(2);Pro(2);il1(2);tnfa(2);Inf(2)];


lab = {'Control','TGFB','Proliferative','IL1','TNFa','Inflammatory'};
% 
% figure
% bar(g1)
% title('Model Prediction of Collagen Output');
% legend({'Collagen I mRNA','Mature Collagen I'});
% ylabel('Fold Change in Activity at Steady State','FontSize',30);
% set(gca,'XTickLabels',lab,'FontSize',30)

% figure
% % bar([g2,data(:,1)])
% barwitherr([err,data(:,2)],[g2,data(:,1)])
% title('Model Prediction of Collagen mRNA Output');
% ylabel('Fold Change in Activity at Steady State','FontSize',30);
% set(gca,'XTickLabels',lab,'FontSize',30)

% figure with data
% figure
% barwitherr([err,data(:,2)],[g3,data(:,1)])
% hold on
% plot([0 6],1,'r--')
% title('Collagen Protein Output');
% ylabel('Fold Change in Activity at Steady State','FontSize',30);
% legend('Model Prediction','Experimental Data');
% set(gca,'XTickLabels',lab,'FontSize',30)

figure
bar(g3)
title('Collagen Protein Output');
ylabel('Fold Change in Activity at Steady State','FontSize',30);
set(gca,'XTickLabels',lab,'FontSize',30)
