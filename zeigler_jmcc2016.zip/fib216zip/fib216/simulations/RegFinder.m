function [q,s] = RegFinder(exp_data,pIn,pAll)

% simulates all single inputs and finds the input level that most
% correlates with the experimental data

paramName = 'modelParams';
modelName = 'modelODE';

%generate control simulation
eval(strcat('[params,y0] = ',paramName,';'));
tspan = [0 700]; 
options = [];

eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
con = real(y(end,90));

    for j = 1:length(pIn)
        disp(['Input # ',num2str(j),' of ', num2str(length(pIn))])
        ws = [0.30:0.05:0.85];
        for i = 1:length(ws)  
            disp(['Input Strength # ',num2str(i),' of ', num2str(length(ws))])
            %perturbed simulation with added input
            eval(strcat('[params,y0] = ',paramName,';'));
            [rpar,tau,ymax,speciesNames]=params{:}; 
            w = rpar(1,:);
            n = rpar(2,:);
            EC50 = rpar(3,:);
            wNew = w;

            perturb = strcat('wNew(',pIn{j},') = ',num2str(ws(i)),';');
            eval(perturb)
            rpar = [wNew;n;EC50];
            params = {rpar,tau,ymax,speciesNames};
            
            eval(['[~,y2] = ode15s(@',modelName,', tspan, y0, options, params);']);
            
            stim(i,j) = round(real(y2(end,90)),3);
            
            fc(i) = stim(i,j)/con;
            err(i) = abs(fc(i) - exp_data(j)); 

        end
        
          m = ws(find(err == min(err)));
        l(j) = m(1);
        d(j) = fc(find(ws==l(j)));
        coll(j) = stim(find(ws==l(j)),j);
        
    end
    
    ins = {'AngII';'TGFb';'mechanical';'IL6';'IL1';'TNFa';'NE';'PDGF';'ET1';'NP';'Forskolin'};
    
    q = table(ins,exp_data',coll',d',l','VariableNames',{'Inputs','ExpFoldChange','ModelCollagen','ModelFoldChange','OptimalInput'});
    s = table(stim(:,1),stim(:,2),stim(:,3),stim(:,4),stim(:,5),stim(:,6),stim(:,7),stim(:,8),stim(:,9),stim(:,10),stim(:,11),...
        'VariableNames',{'Ang','TGFB','mechanical','IL6','IL1','TNFa','NE','PDGF','ET1','NP','forskolin'});
    
    for i = 1:length(pAll)
        eval(strcat('l_all{i}=num2str(l(',pAll{i},'));'))
    end
    
    
    pPro = str2num(pAll{end-1});
    pInf = str2num(pAll{end});
    
    contxtSim(l_all,pIn,pPro,pInf);
    
end
