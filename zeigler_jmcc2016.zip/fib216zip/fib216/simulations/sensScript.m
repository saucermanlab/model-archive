

ProScore = sensAnalysisW('modelParams','modelODE','wNew([1,2,7,9,10]) = 0.4;','proInf','proCol');
InfScore = sensAnalysisW('modelParams','modelODE','wNew([4,5,6]) = 0.4;','infInf','infCol');

