function [] = contxtSim(l,p,p2,p3)
% simulates each individual input and the inflammatory/proliferative
% contexts then performs a sensitivity analysis and writes both the change
% in activity with input and the sensitivity of each node given that
% context

contxt = {'AngII','TGFB','mechanical','IL6','IL1','TNFa','NE','PDGF','ET1','NP','Forskolin'};
paramName = 'modelParams';
modelName = 'modelODE';


% control simulation
eval(strcat('[params,y0] = ',paramName,';'));
tspan = [0 700]; 
options = [];
eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);

con = real(y(end,[84,88,90]));


%%
% single input simulations 
for i = 1:length(p)
    disp(['Simulation # ',num2str(i),' of ', num2str(length(p))])
%     perturb = strcat('wNew(',p{i},') = ',num2str(l{i}),';');
    perturb = strcat('wNew(',p{i},') = 0.4;');
    
    %parameters and initial conditions
    eval(strcat('[params,y0] = ',paramName,';'));
    tspan = [0 700]; 
    options = [];

    [rpar,tau,ymax,speciesNames]=params{:}; 
    w = rpar(1,:);
    n = rpar(2,:);
    EC50 = rpar(3,:);

    wNew = w;
    eval(perturb)
    rpar = [wNew;n;EC50];
    params = {rpar,tau,ymax,speciesNames};

    eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
    
    o = real(y(end,:));
    eName = strcat('endActivity',contxt{i},'.txt');
    exportNodeAttributes(eName, 'Activity', speciesNames, o);
    
    iName = strcat('inf',contxt{i},'.txt');
    cName = strcat('col',contxt{i},'.txt');
    sensAnalysisW(paramName,modelName,perturb,iName,cName);
end

%% proliferative simulation
disp('Proliferative Simulation')
p2 = str2num(p2{1});

%set up parameters
eval(strcat('[params,y0] = ',paramName,';'));
tspan = [0 700]; 
options = [];

[rpar,tau,ymax,speciesNames]=params{:}; 
w = rpar(1,:);
n = rpar(2,:);
EC50 = rpar(3,:);

%set up perturbation
% act = str2num(l{end-1});
wNew = w;
perturb2 = ' ';
for i = 1:length(p2)
%     perturb2 = [perturb2,strcat('wNew(',num2str(p2(i)),') = ',num2str(act(i)),';')];
    perturb2 = [perturb2,strcat('wNew(',num2str(p2(i)),') = 0.4;')]; 
end
eval(perturb2);
rpar = [wNew;n;EC50];
params = {rpar,tau,ymax,speciesNames};

eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
o = real(y(end,:));
eName = strcat('endActivity','Proliferative','.txt');
exportNodeAttributes(eName, 'Activity', speciesNames, o);

% write node attributes
iName = strcat('inf','Proliferative','.txt');
cName = strcat('col','Proliferative','.txt');
colPro = sensAnalysisW(paramName,modelName,perturb2,iName,cName);

% create bar graph compare to control
Pro = o([84,88,90]);
g2 = [con;Pro];
figure
bar(g2')
title('proliferative vs control');
legend({'control','proliferative'});
ylabel('% activity at steady state');
set(gca,'XTickLabel',{'MMP9','collagen I mRNA','collagen I protein'})

% bar plot of drivers of collagen
l = ones(1,length(colPro));
[scolPro,I2] = sort(colPro);
figure
bar(scolPro)
hold on
plot(l,'--r');
title('drivers of collagen in proliferative context');
ylabel('fold change of collagen I');
xlabel('knocked down node');
set(gca,'XTick',1:length(colPro));
set(gca,'XTickLabel',speciesNames(I2));
ylim([0.9 2]);
xticklabel_rotate;

    

%% Inflammatory Simulation
disp('Inflammatory Simulation')
p3 = str2num(p3{1});

%set up parameters
eval(strcat('[params,y0] = ',paramName,';'));
tspan = [0 700]; 
options = [];

[rpar,tau,ymax,speciesNames]=params{:}; 
w = rpar(1,:);
n = rpar(2,:);
EC50 = rpar(3,:);

%set up perturbation
% act = str2num(l{end});
wNew = w;
perturb3 = ' ';
for i = 1:length(p3)
%     perturb3 = [perturb3,strcat('wNew(',num2str(p3(i)),') = ',num2str(act(i)),';')];
    perturb3 = [perturb3,strcat('wNew(',num2str(p3(i)),') = 0.4;')];
end
    eval(perturb3);

rpar = [wNew;n;EC50];
params = {rpar,tau,ymax,speciesNames};

eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
o = real(y(end,:));
eName = strcat('endActivity','Inflammatory','.txt');
exportNodeAttributes(eName, 'Activity', speciesNames, o);

% write node attributes for .cys file
iName = strcat('inf','Inflammatory','.txt');
cName = strcat('col','Inflammatory','.txt');
colInf = sensAnalysisW(paramName,modelName,perturb3,iName,cName);

%create bar graph compare to control
Inf = o([84,88,90]);

g1 = [con;Inf];
figure
bar(g1')
title('inflammatory vs control');
legend({'control','inflammatory'});
ylabel('% activity at steady state');
set(gca,'XTickLabel',{'MMP9','collagen I mRNA','collagen I protein'})

% bar plot of drivers of collagen
l = ones(1,length(colInf));
% [scolInf,I3] = sort(colInf);
scolInf = colInf(I2);
figure
bar(scolInf)
hold on
plot(l,'--r');
title('drivers of collagen in inflammatory context');
ylabel('fold change of collagen I');
xlabel('knocked down node');
set(gca,'XTick',1:length(colInf));
set(gca,'XTickLabel',speciesNames(I2));
ylim([0.9 1.2]);
xticklabel_rotate;


end








