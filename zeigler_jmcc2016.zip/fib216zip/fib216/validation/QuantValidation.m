function [percentMatch,activityChange,resultChart] = QuantValidation(validationfname,paramName,modelName,perturb,thresh)
%calculates the validation percentage and generates a result chart for a given model and validation worksheet
% Inputs
% validationfname = string name of the excel spreadsheet with validation data,
% must be formatted correctly
% paramName = string name of the .m file with model parameters
% modelName = string name of the .m file with the model ODE
% perturb = any perturbation to the standard model parameters
% thresh = threshold for no change (0.1 is typical)

    tspan = [0 500];
    options = [];     

% read the validation sheet
    [~, txt, raw] = xlsread(validationfname);
    % remove rows without data
%     noData = cellfun(@(x)isequal(x,'No Data'), txt(1:end, 7));
%     txt(noData, :) = []; 
%     noData = cellfun(@isempty, txt(1:end, 7));
%     txt(noData, :) = [];
%     assignin('base', 'txt', txt);
    input1 = txt(2:end, 2); %second column, if 2 inputs used will need to alter this code
    inputCode = txt(2:end, 3); % this is the column with the code that will alter the input
    measurement = txt(2:end,6); % this is the column with the qualitative measurement
    outputSpec = txt(2:end, 4);
    validationIDs = txt(2:end, 1);
  
    % set validation threshold change
 % threshold, Ryall et al., 2012 set to 0.001 for sensitivity analysis
    inc = {'Increase'};
    dec = {'Decrease'};
    noc = {'No Change'};
    
        % determination of number of predictions matching references
    numMatching = 0; % number of predictions consistent with the qualitative literature species behavior

    % find indices of output species
    eval(strcat('[params,y0] = ',paramName,';')); %reset the model parameters
    [rpar,tau,ymax,speciesNames]=params{:}; 
    outputSpeciesIndex = zeros(1, length(measurement));
    for k = 1:length(outputSpec)
        [~,outputSpeciesIndex(k)] = ismember(outputSpec{k},speciesNames);
    end
    
    % loop over all validation simulations read in from the excel sheet
    for i = 1:length(inputCode)
        %disp(['Validation # ', num2str(i), ' of ',num2str(length(inputCode))]) % write the simulation number to the command line to track loop progress
        
        eval(strcat('[params,y0] = ',paramName,';')); %reset the model parameters
        [rpar,tau,ymax,speciesNames]=params{:}; 
        w = rpar(1,:);  
        n = rpar(2,:); 
        EC50 = rpar(3,:);
        
        % evaluate alternate baseline inputs
            eval(perturb);

        rpar = [w;n;EC50];
        params = {rpar,tau,ymax,speciesNames};
        eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
        yStart = y(end,:)';
        
        eval(inputCode{i});
        
        rpar = [w;n;EC50];
        params = {rpar,tau,ymax,speciesNames};
        eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
        yEnd = y(end,:)';
        
        activityChange(i,1) = real(yEnd(outputSpeciesIndex(i)))/real(yStart(outputSpeciesIndex(i)));
        
        
        if activityChange(i) > 1 + thresh % increase
            prediction{i} = 'Increase';
            predChange{i} = num2str(activityChange(i));
            if isequal(inc,measurement(i))
                numMatching = numMatching + 1;
                match{i} = 'yes'; %if the simulation matches the experimental validation put a 1 in the vector
            else
                match{i} = 'no'; %if the simulation does not match put a 0 in the matrix
            end

        elseif activityChange(i) < 1 - thresh % decrease
            prediction{i} = 'Decrease';
            predChange{i} = num2str(activityChange(i));
            if isequal(dec,measurement(i))
                numMatching = numMatching + 1;
                match{i} = 'yes';
            else
                match{i} = 'no';
            end
        else % no change
            prediction{i} = 'No Change';
            predChange{i} = num2str(activityChange(i));
            if isequal(noc,measurement(i))
                numMatching = numMatching + 1;
                match{i} = 'yes';
            else
                match{i} = 'no';
            end
        end
    end
    
    
    
    percentMatch = numMatching/length(measurement)*100;
    resultChart = {input1,outputSpec,measurement,prediction',predChange',match'};
    resultChart = horzcat(resultChart{:});
    header = { 'input' , 'output', 'measurement', 'prediction','predictedChange', 'match'};
    resultChart = vertcat(header, resultChart);
end
        
        
        
        