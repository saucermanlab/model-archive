function [percentMatch,scramblMatch,scramblAve,scramblStd] = ScrambleValidation(validationfname,paramName,modelName,thresh)
    tspan = [0 700];
    options = [];       

% read the validation sheet
    [~, txt, raw] = xlsread(validationfname);
    % remove rows without data
%     noData = cellfun(@(x)isequal(x,'No Data'), txt(1:end, 7));
%     txt(noData, :) = []; 
%     noData = cellfun(@isempty, txt(1:end, 7));
%     txt(noData, :) = [];
%     assignin('base', 'txt', txt);
    input1 = txt(2:end, 2); %second column, if 2 inputs used will need to alter this code
    inputCode = txt(2:end, 3); % this is the column with the code that will alter the input
    measurement = txt(2:end,6); % this is the column with the qualitative measurement
    outputSpec = txt(2:end, 4);
    validationIDs = txt(2:end, 1);
  
    % set validation threshold change
 % threshold, Ryall et al., 2012 set to 0.001 for sensitivity analysis
    inc = {'Increase'};
    dec = {'Decrease'};
    noc = {'No Change'};
    
        % determination of number of predictions matching references
    numMatching = 0; % number of predictions consistent with the qualitative literature species behavior

    % find indices of output species
    eval(strcat('[params,y0] = ',paramName,';')); %reset the model parameters
    [rpar,tau,ymax,speciesNames]=params{:}; 
    outputSpeciesIndex = zeros(1, length(measurement));
    for k = 1:length(outputSpec)
        [~,outputSpeciesIndex(k)] = ismember(outputSpec{k},speciesNames);
    end
    
    % loop over all validation simulations read in from the excel sheet
    for i = 1:length(inputCode)
        disp(['Validation # ', num2str(i), ' of ',num2str(length(inputCode))]) % write the simulation number to the command line to track loop progress
        
        eval(strcat('[params,y0] = ',paramName,';')); %reset the model parameters
        [rpar,tau,ymax,speciesNames]=params{:}; 
        w = rpar(1,:);  
        n = rpar(2,:); 
        EC50 = rpar(3,:);

        rpar = [w;n;EC50];
        params = {rpar,tau,ymax,speciesNames};
        eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
        yStart = y(end,:)';
        
        eval(inputCode{i});
        
        rpar = [w;n;EC50];
        params = {rpar,tau,ymax,speciesNames};
        eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
        yEnd = y(end,:)';
        
        activityChange(i,1) = real(yEnd(outputSpeciesIndex(i)))/real(yStart(outputSpeciesIndex(i)));
        
        
        if activityChange(i) > 1 + thresh % increase
            prediction{i} = 'Increase';
            predChange{i} = num2str(activityChange(i));
            if isequal(inc,measurement(i))
                numMatching = numMatching + 1;
                match{i} = 'yes'; %if the simulation matches the experimental validation put a 1 in the vector
            else
                match{i} = 'no'; %if the simulation does not match put a 0 in the matrix
            end

        elseif activityChange(i) < 1 - thresh % decrease
            prediction{i} = 'Decrease';
            predChange{i} = num2str(activityChange(i));
            if isequal(dec,measurement(i))
                numMatching = numMatching + 1;
                match{i} = 'yes';
            else
                match{i} = 'no';
            end
        else % no change
            prediction{i} = 'No Change';
            predChange{i} = num2str(activityChange(i));
            if isequal(noc,measurement(i))
                numMatching = numMatching + 1;
                match{i} = 'yes';
            else
                match{i} = 'no';
            end
        end
    end
    
    
    
    percentMatch = numMatching/length(inputCode)*100;
    
     %% loop through random permutations in node location (except for inputs)
     
    numMatching2 = zeros(1,100); % number of predictions consistent with the qualitative literature species behavior
    
    
     % generate a randomly permuted node label array
     for j = 1:100
         disp(['Simulation # ',num2str(j),' of 100'])
         nodes = speciesNames;
         indx = randperm(length(nodes));
         scrambl = nodes(indx);
         
         % find indices of output species
        outputSpeciesIndex = zeros(1, length(measurement));
        for k = 1:length(outputSpec)
            [~,outputSpeciesIndex(k)] = ismember(outputSpec{k},scrambl);
        end

        for i = 1:length(inputCode)
            disp(['Validation # ', num2str(i), ' of ',num2str(length(inputCode))]) % write the simulation number to the command line to track loop progress

            eval(strcat('[params,y0] = ',paramName)); %reset the model parameters
            [rpar,tau,ymax,speciesNames]=params{:}; 
            w = rpar(1,:);  
            n = rpar(2,:); 
            EC50 = rpar(3,:);

            rpar = [w;n;EC50];
            params = {rpar,tau,ymax,scrambl};
            eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
            yStart = y(end,:)';

            eval(inputCode{i});

            rpar = [w;n;EC50];
            params = {rpar,tau,ymax,scrambl};
            eval(['[~,y] = ode15s(@',modelName,', tspan, y0, options, params);']);
            yEnd = y(end,:)';

            activityChange(i,1) = real(yEnd(outputSpeciesIndex(i)))/real(yStart(outputSpeciesIndex(i)));


            if activityChange(i) > 1 + thresh % increase
                prediction{i} = 'Increase';
                predChange{i} = num2str(activityChange(i));
                if isequal(inc,measurement(i))
                    numMatching2(j) = numMatching2(j) + 1;
                    match{i} = 'yes'; %if the simulation matches the experimental validation put a 1 in the vector
                else
                    match{i} = 'no'; %if the simulation does not match put a 0 in the matrix
                end

            elseif activityChange(i) < 1 - thresh % decrease
                prediction{i} = 'Decrease';
                predChange{i} = num2str(activityChange(i));
                if isequal(dec,measurement(i))
                    numMatching2(j) = numMatching2(j) + 1;
                    match{i} = 'yes';
                else
                    match{i} = 'no';
                end
            else % no change
                prediction{i} = 'No Change';
                predChange{i} = num2str(activityChange(i));
                if isequal(noc,measurement(i))
                    numMatching2(j) = numMatching2(j) + 1;
                    match{i} = 'yes';
                else
                    match{i} = 'no';
                end
            end
        end
        
        scramblMatch(j) = numMatching2(j)/length(measurement)*100;
     end
        scramblAve = mean(scramblMatch);
        scramblStd = std(scramblMatch);
        
        
        figure
        UnivarScatter(scramblMatch')
        hold on
        line([0 100],[percentMatch percentMatch]);
        title('Random Validation vs Real Validation');
end
        
        
        
        