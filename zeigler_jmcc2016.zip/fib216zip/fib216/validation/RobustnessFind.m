function [Val,ValQ,SensPC,SensDiff,timeVal] = RobustnessFind(validationfname,param)
paramName = 'modelParams';
modelName = 'modelODE';

eval(strcat('[params,y0] = ',paramName,';'));
[rpar,tau,ymax,speciesNames]=params{:}; 

% calculate normal validation values and a normal sensitivity analysis at
% the original parameter values
% [OrigPercent,OrigChange,~] = QuantValidation(validationfname,'clc',0.1);

[OrigSens,~,~] = sensAnalysis('clc');
[m,n] = size(OrigSens);
OrigSensR = reshape(OrigSens,[1,m*n]);

%%
% % values that define a window of change allowed in the parameter values
% % r = [5:5:50];
% r = [5:5:30];
% 
% %creates a pool of workers for parallelization
% parpool('local',4);
% 
% %iterates through different allowed percent changes in parameter value.`
% %Repeats each simulation with a random permutation in the altered parameter
% %within the window of allowed values 100x then averages the following:
% % the validation percentage (Val)
% % the fold change in collagen 1 mRNA with TGFB (ValQ)
% % the pearson correlation coefficient between the original sensitivity matrix (OrigSens) and the new sensitivity analysis with random parameters(sensPC)
% % the average difference between the original sensitivity matrix and the new sensitivity matrix (sensDiff)
% for i = 1:length(r)
%     perturb = strcat(param,' = ',param,' + ',param,'.*(randi([-',num2str(r(i)),',',num2str(r(i)),'],1,length(',param,'))/100);');
%     parfor j = 1:100
% %     for j = 1:100
%         
%         disp(['Percent Window ',num2str(i),' of ', num2str(length(r)),'. Random Simulation ',num2str(j),' of 100']) 
%        
%         [percentMatch,activityChange,~] = QuantValidation(validationfname,paramName,modelName,perturb,0.1);
%         PM(j) = percentMatch; 
%         AC(j) = activityChange(1);
% 
%         [sens,~,~] = sensAnalysis(perturb);
%         sens = real(sens);
%         [m,n] = size(sens);
%         sensR = reshape(sens,[1,m*n]);
%         
%         SPC(j) = corr(OrigSensR',sensR');
%         SDiff(j) = mean(abs(OrigSensR - sensR));
%     end
%     
%         Val(i,:) = PM';
%         ValQ(i,:) = AC';
%         SensPC(i,:) = SPC';
%         SensDiff(i,:) = SDiff';
%     Val_m(i,:) = [mean(PM),std(PM)];
%     ValQ_m(i,:) = [mean(AC),std(AC)];
%     SensPC_m(i,:) = real([mean(SPC),std(SPC)]);
%     SensDiff_m(i,:) = real([mean(SDiff),std(SDiff)]);
%         
% end
% 
% %close the local pool
% delete(gcp);
% 
%% Plots for all points - Univariate Scatter
% figure
% % UnivarScatter(Val','Label',{'5%','10%','15%','20%','25%','30%','35%','40%','45%','50%'});
% UnivarScatter(Val','Label',{'5%','10%','15%','20%','25%','30%'});
% title(strcat('Validation Accuracy with Varying Ranges',param))
% 
% figure
% %UnivarScatter(ValQ','Label',{'5%','10%','15%','20%','25%','30%','35%','40%','45%','50%'});
% UnivarScatter(ValQ','Label',{'5%','10%','15%','20%','25%','30%'});
% title(strcat('Quantitative Collagen Output with Varying Ranges',param));
% 
% figure
% %UnivarScatter(SensPC','Label',{'5%','10%','15%','20%','25%','30%','35%','40%','45%','50%'});
% UnivarScatter(SensPC','Label',{'5%','10%','15%','20%','25%','30%'});
% title(strcat('Qualitative Sensitivity Change with Varying Ranges',param))
% 
% figure
% %UnivarScatter(SensDiff','Label',{'5%','10%','15%','20%','25%','30%','35%','40%','45%','50%'});
% UnivarScatter(SensDiff','Label',{'5%','10%','15%','20%','25%','30%'});
% title(strcat('Quantitative Sensitivity Change with Varying Ranges',param))
% 
%% Plots for averages
% %plots the average +/- the standard deviation of all model features versus
% %the allowed window of random parameters
% figure
% subplot(2,2,1);
% errorbar(r,Val_m(:,1),Val_m(:,2),'o');
% axis([0 60 0 100]);
% title(strcat('Percent Validation Robustness',param))
% xlabel('Percent Change Allowed')
% ylabel('Ave Percent Validation')
% 
% subplot(2,2,2);
% errorbar(r,ValQ_m(:,1),ValQ_m(:,2),'o');
% axis([0 60 0 40]);
% title(strcat('Fold Change in Collagen I mRNA Robustness',param));
% xlabel('Percent Change Allowed');
% ylabel('Ave Change CollI mRNA');
% 
% subplot(2,2,3);
% errorbar(r,SensPC_m(:,1),SensPC_m(:,2),'o');
% axis([0 60 0 1.5]);
% title(strcat('Sensitivity Robustness',param));
% xlabel('Percent Change Allowed');
% ylabel('Ave Sens PCC');
% 
% subplot(2,2,4);
% errorbar(r,SensDiff_m(:,1),SensDiff_m(:,2),'o');
% axis([0 60 0 .001]);
% title(strcat('Quantitative Sensitivity Robustness',param));
% xlabel('Percent Change Allowed');
% ylabel('Ave Quant Sens Diff');



%% Vary all parameters
% r = [-0.25:0.05:0.25];
r = [-0.1:0.05:0.1];

tic
for i = 1:length(r)
    perturb = strcat(param,'=',param,'+',num2str(r(i)),';');
    disp(['Percent Window ',num2str(i),' of ', num2str(length(r))]) 
       
        [percentMatch,activityChange,~] = QuantValidation(validationfname,paramName,modelName,perturb,0.1);
        PM(i) = percentMatch; 
        AC(i) = activityChange(1);

        [sens,~,~] = sensAnalysis(perturb);
        sens = real(sens);
        [m,n] = size(sens);
        sensR = reshape(sens,[1,m*n]);
        
        SPC(i) = corr(OrigSensR',sensR');
        SDiff(i) = mean(abs(OrigSensR - sensR));
        
end

timeVal = tic;
toc;

Val = PM;
ValQ = AC;
SensPC = SPC;
SensDiff = SDiff;

figure
title(param)
subplot(2,1,1)
plot(r,PM)
title('validation')

subplot(2,1,2)
plot(r,SPC)
title('sensitivity pearson correlation')

                
        
end
    



