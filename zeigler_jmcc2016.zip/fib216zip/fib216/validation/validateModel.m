function [percentMatch, resultChart, BMatch, byClass] = validateModel(modelfname, validationfname,alts)
% Calculates the percent agreement and writes resultChart variable to
% "Validation Results.xlsx". Also writes node attributes file for every
% unique validation that contains the steady state activation of each
% species for visualization in Cytoscape. 
%   
%   inputs: 
%   - modelfname = model file name (.xlsx)
%   - validationfname = validation file name (.xlsx)
%   - dataName = name given to data file created line 186
%   - alts = alterations in one or series of reactions, used in
%   iterative changes in the model 
%   
%   outputs:
%   - percentMatch = percent agreement
%   - resultChart = chart containing results of each individual validation
%     simulation. 
%   - BMatch = boolean vector containing the result of each validation (1 =
%     correct, 0 = incorrect)
%   - byClass = percent match by validation class

% delete the previously formed ODE to make sure it's rewritten
pwd = cd;
if exist([pwd '\ODEfun.m'],'file') == 2
    delete('ODEfun.m');
end


% parse out model name (xls2Netflux needs it as an arg)
namepos = findstr('.xls', modelfname);
namestr = modelfname(1:namepos-1);
namestr = cellstr(namestr);
% 
% %adds the desktop as a general path
% addpath(genpath('C:\Users\acz4nr\Desktop'))

% generate ODE from model spreadsheet
[specID,reactionIDs,~,paramList,ODElist,~, error] = util.xls2Netflux(namestr,modelfname);
% 
% % mix up internal and output node names
% p = randperm(length(specID) - 11)+11;
% specID = [specID(1:11);specID(p)];

commandLine = util.exportODE2(specID,paramList,ODElist);
util.textwrite('ODEfun.m',commandLine);


% set up simulation params
tspan = [0 300]; % run out to ss
options = [];
[w,n,EC50,tau,ymax,y0] = paramList{:};
eval(alts)

% read the validation sheet
[~, txt, raw] = xlsread(validationfname);
% remove rows without data
noData = cellfun(@(x)isequal(x,'No Data'), txt(1:end, 7));
txt(noData, :) = []; 
noData = cellfun(@isempty, txt(1:end, 7));
txt(noData, :) = [];
assignin('base', 'txt', txt);
input1 = txt(2:end, 2);
% input2 = txt(2:end, 3);
inputCode = txt(2:end, 3); % 3rd column, row 2 to end
measurement = txt(2:end,6); % 6th column, row 2 to end
outputSpec = txt(2:end, 4);
control = txt(2:end, 5);
validationIDs = txt(2:end, 1);
validationTags = txt(2:end, 8);

% convert species and rxn names to integer values to map name and reaction
% ID's to numerical integers, allowing the input code to be evaluated
% directly
for k = 1:length(specID)
    eval([specID{k},' = ',num2str(k),';']);
end
for i = 1:length(reactionIDs)
    eval([reactionIDs{i},' = ',num2str(i),';']);
end
for i = 1:length(validationIDs)
    if ~isempty(validationIDs{i}) 
        eval([validationIDs{i}, ' = ', num2str(i), ';']);
    end
end

% set validation threshold change
thresh = .001; % threshold, Ryall et al., 2012 set to 0.001 for sensitivity analysis
inc = {'Increase'};
dec = {'Decrease'};
noc = {'No Change'};

% determination of number of predictions matching references
numMatching = 0; % number of predictions consistent with the qualitative literature species behavior

% find indices of output species
outputSpeciesIndex = zeros(1, length(measurement));
for k = 1:length(outputSpec)
    [~,outputSpeciesIndex(k)] = ismember(outputSpec{k},specID);
end

% loop over all validation simulations read in from the excel sheet
for i = 1:length(inputCode)
    disp(['Simulation # ', num2str(i), ' of ',num2str(length(inputCode))]) % write the simulation number to the command line to track loop progress
    [w,n,EC50,tau,ymax,y0] = paramList{:}; % reset params
    
    
%     % evaluate alternate parameters
%     eval(alts);

    rpar = [w;n;EC50];
    params = {rpar,tau,ymax,specID};
    [~,y] = ode15s(@ODEfun, tspan, y0, options, params);
    yStart = y(end,:)'; % use the "no input" steady state as control 
    
    
    % evaluate validation conditions from excel sheet
    eval(inputCode{i});
    
    rpar = [w;n;EC50];
    params = {rpar,tau,ymax,specID};
    [~,y] = ode15s(@ODEfun, tspan, y0, options, params);
    yEnd = y(end,:)'; % final species activation state
    % subtract final species activation from initial to determine the effect
    % the validation simulation has had on the species' activation with
    % respect to the defined threshold, then write out the qualitative
    % change of the species' activation state to the excel file
    yStartL{i} = yStart;
    yEndL{i} = yEnd;

    
%     
%     if isempty(control{i}) % if control validation defined
        activityChange = real(yEndL{i}(outputSpeciesIndex(i)))-real(yStartL{i}(outputSpeciesIndex(i)));
%     else
%         indexControl = eval(control{i});
%         assignin('base', 'indexControl',indexControl);
%         activityChange = real(yEndL{i}(outputSpeciesIndex(i))) - real(yEndL{indexControl}(outputSpeciesIndex(i)));
%     end
%     
%     % writes node attributes file with steady state activation for each
%     % species for every validation condition. used for visualization in
%     % cytoscape.
%     if strcmp(input2{i},'')
%         s = sprintf('%s Node Attributes.txt', input1{i});
%     else % more than one input
%         s = sprintf('%s + %s Node Attributes.txt', input1{i}, input2{i});
%     end
%     util.exportNodeAttributes(s, 'DeltaActivation', specID, real(yEndL{i})-real(yStartL{i}));
%     
    
    if activityChange > thresh % increase
        prediction{i} = 'Increase';
        predChange{i} = num2str(activityChange);
        if isequal(inc,measurement(i))
            numMatching = numMatching + 1;
            match(i) = 1; %if the simulation matches the experimental validation put a 1 in the vector
        else
            match(i) = 0; %if the simulation does not match put a 0 in the matrix
        end
    elseif activityChange < -thresh % decrease
        prediction{i} = 'Decrease';
        predChange{i} = num2str(activityChange);
        if isequal(dec,measurement(i))
            numMatching = numMatching + 1;
            match(i) = 1;
        else
            match(i) = 0;
        end
    else % no change
        prediction{i} = 'No Change';
        predChange{i} = num2str(activityChange);
        if isequal(noc,measurement(i))
            numMatching = numMatching + 1;
            match(i) = 1;
        else
            match(i) = 0;
        end
    end
end

for j = 1:length(match)
    if match(j) == 1;
        match2{j} = 'yes';
        match3(j) = 1;
    else
        match2{j} = 'no';
        match3(j) = 0;
    end
end
match = match2;

BMatch = match3';
ind = find(strcmp('In-Int', validationTags));
byClass.inint = sum(BMatch(ind))/length(BMatch(ind))*100;

ind = find(strcmp('comb-out', validationTags));
byClass.comb = sum(BMatch(ind))/length(BMatch(ind))*100;

ind = find(strcmp('in-out', validationTags));
byClass.inout = sum(BMatch(ind))/length(BMatch(ind))*100;

ind = find(strcmp('KO Int', validationTags));
byClass.KO = sum(BMatch(ind))/length(BMatch(ind))*100;

% output the KO'd rxn indices and the percent agreement
resultChart = {validationIDs, input1, outputSpec, measurement, prediction', predChange', match', validationTags}; %create a cell array showing input, output, and whether they matched validation
header = {'ID', 'input' , 'output', 'measurement', 'prediction', 'predicted change', 'match', 'tag'};
resultChart = horzcat(resultChart{:});
resultChart = vertcat(header, resultChart);
% delete(dataName);
% xlswrite(dataName, resultChart);
% disp(['wrote ', which('Validation Results.xlsx')]);
percentMatch = numMatching/length(measurement)*100;
delete('ODEfun.m');