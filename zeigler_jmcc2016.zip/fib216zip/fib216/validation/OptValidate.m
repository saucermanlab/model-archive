function [vals,M,optIn,optFB] = OptValidate(In,FB,modelfname,validationfname)

for i = 1:length(In)
    for j = 1:length(FB)
        alts = strcat('w(1:11) = ',num2str(In(i)),';','w(14:20) = ',num2str(FB(j)),';');
        disp(['Index # ', num2str(i), ' and ',num2str(j)])
        [~,~,~,byClass] = validateModel(modelfname,validationfname,'data',alts);
        vals(i,j) = byClass.inout;
    end
end

[M,I] = max(vals(:));
[optIn,optFB] = ind2sub(size(vals),I);
end