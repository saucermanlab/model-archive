% generates figure 4 Sensitivity analysis
% 
paramName = 'modelParams';
modelName = 'modelODE';
eval(strcat('[params,y0] = ',paramName));
[rpar,tau,ymax,speciesNames]=params{:};  

% generates the bar graph figure for panel c
[sens,sensTGFB,~] = altSensFigures(paramName,modelName,'clc','w(2) = 0.9',6,'ROS');
Col = [73,79,80,81,82,83,84,88,89,90,91];

% generate the context specific figure for KO of TGFBR
ctxSens = contextSens(21,Col);
