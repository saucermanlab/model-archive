function [names, values] = getAttributes(fname)

string = textread(fname, '%s', 'delimiter', '\n');

names = {};
values = [];

for i = 2:length(string) % skip first header line
    split = strsplit(string{i});
    names{end+1} = split{1};
    values(end+1) = str2num(split{3});
end
