function [nodes,tops,influence,R] = structFunction(fileName,opt,fnct)

%This function will pull in toplogy attributes and match them to the nodes
%within the network to generate scatter plots of a functional metric from
%model simulation vs a toplogy measurement
% input: fileName = name of function text file
% output: values = an array of topology values that match with each node
%         nodes = names of the nodes that correspond to each value

% generate a cell with the names of the topological features
topology = {'AverageShortestPathLength';'BetweennessCentrality';'ClosenessCentrality';
    'ClusteringCoefficient';'Eccentricity';'Degree';'Indegree';
    'NeighborhoodConnectivity';'Outdegree';
    'PartnerOfMultiEdgedNodePairs'};

% Generate an array and matrix with values and names of the node which has
% that value
for i = 1:length(topology);
    a = strcat(topology(i),'.NA');
    [names,x] = getAttributes(a{1});
    values(:,i) = x';
end

% name the functional metric from the model and generate a cell array with
% the names and values



[nodes,influence] = getAttributes(fileName);
nodes = lower(nodes);
lnames = lower(names);
% string match the nodes with the names and
% use the indx vector to pull only the indices of values that match the
% nodes in "nodes" array from the model
missed = ['none'];
for i = 1:length(nodes)
    a = strmatch(nodes(i),lnames,'exact');
    if isempty(a)
        missed = [missed,nodes(i)];
    else
        if size(a,1) > 1
            if values(a(1),6) > values(a(2),6)
                indx = a(1);
            else
                indx = a(2);
            end
        else
            indx = a;
        end
    tops(i,:) = values(indx,:);
    end
end
assignin('base','missed',missed);



figure
% plot each topological feature against the functional metric
for i = 1:length(topology)
    mdl = fitlm(tops(:,i),influence);
    R(i) = sqrt(mdl.Rsquared.Ordinary);
    
    if strcmp(opt,'yes')
        
        subplot(3,4,i);
        plot(tops(:,i),influence,'o');
        xlabel(topology(i));
        ylabel('influence');
        title(strcat(fnct,'_vs_ ',topology(i),': R2 = ',num2str(R(i))));
    end
end

[M,I] = max(R);
figure
plot(tops(:,I),influence,'o');
xlabel('Betweenness Centrality');
ylabel('Influence');
title(fnct);

end