% Generates Figure 6 Structure vs Function
% Before running this code use Cytoscape to visualize the network, collapse
% all AND relationships into their target nodes, then run network analysis
% (plugin) for both directed and undirected graphs. Export the node
% attributes listed below in the topology array

% Dependencies:
%   - text files for the topology metrics below
%   - modelparams and modelODE files
%   - the following functions: sensAnalysisW, structFunction,
%   xticklabel_rotate, exportNodeAttributes, textwrite

% creates a bar graph of structure vs different functions of the network
topology = {'AverageShortestPathLength';'BetweennessCentrality';'ClosenessCentrality';
    'ClusteringCoefficient';'Eccentricity';'Degree';'Indegree';
    'NeighborhoodConnectivity';'Outdegree';
    'PartnerOfMultiEdgedNodePairs'};
paramName = 'modelParams';
modelName = 'modelODE';

[num,sen] = sensAnalysisW(paramName,modelName,'clc','inf.txt','sens.txt','col.txt','sma.txt');

[nodes,tops,influence,inf_Rsq] = structFunction('inf.txt','yes','influence');
bcInf = [influence',tops(:,2)]; 
[~,~,~,sens_Rsq] = structFunction('sens.txt','yes','sensitivity');
[~,~,~,col_Rsq] = structFunction('col.txt','yes','collagen score');
[~,~,~,sma_Rsq] = structFunction('sma.txt','yes','aSMA score');


Rsq = sqrt([inf_Rsq',sens_Rsq',col_Rsq',sma_Rsq']);

[R,index] = sortrows(Rsq,1);
topology = topology(index);
xm = length(topology)+1;

figure
subplot(1,4,1);
barh(R(:,1));
title('Influence');
axis([0 1 0 xm]);
set(gca,'YTickLabel',topology);

subplot(1,4,2);
barh(R(:,2));
title('Sensitivity');
axis([0 1 0 xm]);

subplot(1,4,3);
barh(R(:,3));
title('Collagen Score');
axis([0 1 0 xm]);

subplot(1,4,4);
barh(R(:,4));
title('aSMA Score');
axis([0 1 0 xm]);

