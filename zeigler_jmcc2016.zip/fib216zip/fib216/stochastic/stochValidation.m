function [numMatchingD,numMatchingS,activityChangeD,activityChangeS] = stochValidation(validationfname,thresh)
paramName = 'modelParams';  %name of the parameter file
modelName = 'modelODE';

eval(strcat('[params,y0] = ',paramName,';'));
[rpar,tau,ymax,speciesNames]=params{:}; 
w = rpar(1,:);  
n = rpar(2,:); 
EC50 = rpar(3,:);

params = {rpar,tau,ymax,speciesNames};
tspan = [1:300];
options = [];

%standard deterministic simulation
eval(['[t1,y1] = ode15s(@',modelName,',tspan,y0,options,params);']);



for i = 1:100
    disp(['Simulation # ', num2str(i), ' of 100'])
    wNew1 = w;
    wNew1(1:11) = normrnd(w(1:11),0.125.*(w(1:11))); %normal distribution with 98% of it within a range where there was no observable validation difference based on the robustness analysis
    ymaxNew1 = normrnd(ymax,0.075.*ymax);

    rpar = [wNew1;n;EC50];
    params = {rpar,tau,ymaxNew1,speciesNames};
    
    eval(['[t,y] = ode15s(@',modelName,',tspan,y0,options,params);']);
    yss(i,:) = y(end,:);
    

end

yconAve = mean(yss,1);
yconD = y1(end,:);


for j = 1:11
    wNew = w;
    perturbD = strcat('wNew(',num2str(j),')=0.9;');
    eval(perturbD)
    rpar = [wNew;n;EC50];
     params = {rpar,tau,ymax,speciesNames};
    eval(['[t,y] = ode15s(@',modelName,',tspan,y0,options,params);']);
    
    ystimD(j,:) = y(end,:);
    
    perturb = strcat('wNew2(',num2str(j),')=0.9;');
    
    for i = 1:100
        disp(['Perturb #',num2str(j),'Simulation # ', num2str(i), ' of 100'])
        wNew2 = w;
        wNew2(1:11) = normrnd(w(1:11),0.125.*(w(1:11))); %normal distribution with 98% of it within a range where there was no observable validation difference based on the robustness analysis
        ymaxNew2 = normrnd(ymax,0.075.*ymax);   
        
        eval(perturb)
        rpar = [wNew2;n;EC50];
        params = {rpar,tau,ymax,speciesNames};
        
        eval(['[t,y] = ode15s(@',modelName,',tspan,y0,options,params);']);
        ystim(i,:) = y(end,:);
        
    end
    
    ystimAve(j,:) = mean(ystim,1);
end


%% comparing simulations to experimental data
    [num, txt, raw] = xlsread(validationfname);
    input1 = txt(2:end, 2); %second column, if 2 inputs used will need to alter this code
    inputCode = num(:,1); % this is the column with the code that will alter the input
    measurement = txt(2:end,6); % this is the column with the qualitative measurement
    outputSpec = txt(2:end, 4);
    validationIDs = txt(2:end, 1);
    
    
    inc = {'Increase'};
    dec = {'Decrease'};
    noc = {'No Change'};
    
    numMatchingD = 0;
    numMatchingS = 0;
    
     % find indices of output species
    [rpar,tau,ymax,speciesNames]=params{:}; 
    outputSpeciesIndex = zeros(1, length(measurement));
    for k = 1:length(outputSpec)
        [~,outputSpeciesIndex(k)] = ismember(outputSpec{k},speciesNames);
    end
    
    for i = 1:length(inputCode)
        disp(['Validation # ', num2str(i), ' of ',num2str(length(inputCode))])
        
        activityChangeD(i) = real(ystimD(inputCode(i),outputSpeciesIndex(i)))/real(yconD(outputSpeciesIndex(i)));
        activityChangeS(i) = real(ystimAve(inputCode(i),outputSpeciesIndex(i)))/real(yconAve(outputSpeciesIndex(i)));
        
        if activityChangeD(i) > 1 + thresh % increase
            prediction{i} = 'Increase';
            predChange{i} = num2str(activityChangeD(i));
            if isequal(inc,measurement(i))
                numMatchingD = numMatchingD + 1;
                match{i} = 'yes'; %if the simulation matches the experimental validation put a 1 in the vector
            else
                match{i} = 'no'; %if the simulation does not match put a 0 in the matrix
            end

        elseif activityChangeD(i) < 1 - thresh % decrease
            prediction{i} = 'Decrease';
            predChange{i} = num2str(activityChangeD(i));
            if isequal(dec,measurement(i))
                numMatchingD = numMatchingD + 1;
                match{i} = 'yes';
            else
                match{i} = 'no';
            end
        else % no change
            prediction{i} = 'No Change';
            predChange{i} = num2str(activityChangeD(i));
            if isequal(noc,measurement(i))
                numMatchingD = numMatchingD + 1;
                match{i} = 'yes';
            else
                match{i} = 'no';
            end
        end
            
            
            if activityChangeS(i) > 1 + thresh % increase
            prediction{i} = 'Increase';
            predChange{i} = num2str(activityChangeS(i));
            if isequal(inc,measurement(i))
                numMatchingS = numMatchingS + 1;
                match{i} = 'yes'; %if the simulation matches the experimental validation put a 1 in the vector
            else
                match{i} = 'no'; %if the simulation does not match put a 0 in the matrix
            end

        elseif activityChangeS(i) < 1 - thresh % decrease
            prediction{i} = 'Decrease';
            predChange{i} = num2str(activityChangeS(i));
            if isequal(dec,measurement(i))
                numMatchingS = numMatchingS + 1;
                match{i} = 'yes';
            else
                match{i} = 'no';
            end
        else % no change
            prediction{i} = 'No Change';
            predChange{i} = num2str(activityChangeS(i));
            if isequal(noc,measurement(i))
                numMatchingS = numMatchingS + 1;
                match{i} = 'yes';
            else
                match{i} = 'no';
            end
            end


end
    
    