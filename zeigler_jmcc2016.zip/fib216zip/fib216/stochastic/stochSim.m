function [colmRNA,colProtein,aSMA,s] = stochSim(perturb)
paramName = 'modelParams';  %name of the parameter file
ODEname = 'modelODE';

eval(strcat('[params,y0] = ',paramName));
[rpar,tau,ymax,speciesNames]=params{:}; 
w = rpar(1,:);  
n = rpar(2,:); 
EC50 = rpar(3,:);

params = {rpar,tau,ymax,speciesNames};

%standard deterministic simulation
[y1,t1] = TimeSim(params,y0,ODEname,perturb,perturb);



for i = 1:100
    disp(['Simulation # ', num2str(i), ' of 100'])
    wNew = w;
    wNew(1:11) = normrnd(w(1:11),0.125.*(w(1:11)));
    ymaxNew = normrnd(ymax,0.075.*ymax);

    rpar = [wNew;n;EC50];
    params = {rpar,tau,ymaxNew,speciesNames};
    
    [y,t2] = TimeSim(params,y0,ODEname,perturb,perturb);
    ycol(i,:) = y(88,:);
    ysmad(i,:) = y(22,:);
    yerk(i,:) = y(59,:);
    ycolT(i,:) = y(90,:);
    ysma(i,:) = y(73,:);
    

end

sColmRNA = y1(88,end);
sASMA = y1(73,end);
sERK = y1(59,end);
sCol = y1(90,end);
s = [sColmRNA,sASMA,sERK,sCol];

figure
plot(t1,y1(88,:),'-')
hold on
plot(t2,ycol,'--')
title('collagen I mRNA')


figure
plot(t1,y1(73,:),'-')
hold on
plot(t2,ysmad,'--')
title('alpha sma')
    
figure
plot(t1,y1(59,:),'-')
hold on
plot(t2,yerk,'--')
title('erk')

    
figure
plot(t1,y1(90,:),'-')
hold on
plot(t2,yerk,'--')
title('Collagen Protein')


colmRNA = ycol;
colProtein = ycolT;
aSMA = ysma;
end
    
    