function [y,t] = TimeSim(params,y0,odeName,p1,p2)

%parameters and initial conditions
tspan1 = [0 50]; 
options = []; 

%pull parameters out in order to alter them in the loop without negating
%the previous alteration
[rpar,tau,ymax,speciesNames]=params{:}; 
w = rpar(1,:);
n = rpar(2,:);
EC50 = rpar(3,:);


% Initial Simulation
params = {rpar,tau,ymax,speciesNames};
eval(['[t1,y1] = ode23(@',odeName,',tspan1,y0,options,params);']);
tInt1 = [0:1:50];
yInt1 = interp1(t1,y1,tInt1);

% Application of Drug #1
eval(p1)
rpar = [w;n;EC50];
params = {rpar,tau,ymax,speciesNames};

y02 = yInt1(end,:); 
tspan2 = [0:1:48];
options = []; 
eval(strcat('[t2,y2] = ode23(@',odeName,',tspan2,y02,options,params);'));
% tInt2 = [0:1:96];
tInt2 = [0:1:48];
yInt2 = interp1(t2,y2,tInt2);

% Addition of Drug #2
eval(p2);
rpar = [w;n;EC50];
params = {rpar,tau,ymax,speciesNames};

y03 = yInt2(end,:);
tspan3 = [0:1:49];
options = []; 
eval(strcat('[t3,y3] = ode23(@',odeName,',tspan3,y03,options,params);'));
tInt3 = [0:1:48];
yInt3 = interp1(t3,y3,tInt3);


y = real([yInt1' yInt2' yInt3']);
t = 1:1:length(y);

end
