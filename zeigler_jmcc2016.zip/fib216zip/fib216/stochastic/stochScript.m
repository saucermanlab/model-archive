% script to try to use stochastic validation for experimental relativity. 

[matchD,matchS,activityD,activityS] = stochValidation('fib_validationIO.xlsx',0.1);

inpt = 2;
p1 = strcat('w(',num2str(inpt),') = 0.25;');
% the s matrix has the deterministic values in the order of: coll_mRNA,
% asma, erk, collagen protein
[con_mRNA,con_protein,con_sma,con_d] = stochSim(p1);

p2 = strcat('w(',num2str(inpt),') = 0.4;');
[stimL_mRNA,stimL_protein,stimL_sma,stimL_d] = stochSim(p2);

p3 = strcat('w(',num2str(inpt),') = 0.6;');
[stimH_mRNA,stimH_protein,stimH_sma,stimH_d] = stochSim(p3);

mRNA = [con_mRNA(:,end),stimL_mRNA(:,end),stimH_mRNA(:,end)];
prot = [con_protein(:,end),stimL_protein(:,end),stimH_protein(:,end)];
sma = [con_sma(:,end),stimL_sma(:,end),stimH_sma(:,end)];


lab = {'control', 'Stretch Low', 'stretch High'};
figure
UnivarScatter(mRNA,'Label',lab);
title('Collagen mRNA');
hold on
scatter([1,2,3],[con_d(1),stimL_d(1),stimH_d(1)],'*');

figure
UnivarScatter(prot,'Label',lab);
title('Collagen Protein');
hold on
scatter([1,2,3],[con_d(4),stimL_d(4),stimH_d(4)],'*');

figure
UnivarScatter(sma,'Label',lab);
title('aSMA');
hold on
scatter([1,2,3],[con_d(2),stimL_d(2),stimH_d(2)],'*');