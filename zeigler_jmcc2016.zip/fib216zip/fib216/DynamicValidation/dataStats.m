function [] = dataStats(aves,conds,sem_aves,ylab)
% bar plot with error bars and significance bridge
% subplot(2,2,1);
% x = [1:length(mn)];
% b = bar(mn);

x = [1:length(aves)];
b = bar(aves);

% formatting
b.FaceColor = [0.5 0.5 0.5];
b.EdgeColor = 'none';
ax = gca;
ax.XTick = [1:length(aves)];
ax.XTickLabel = conds;
ax.XTickLabelRotation = 40;
ax.Box = 'off';
ylabel('Relative activity');

% error bars
hold on;
err = 0.5*ones(size(aves));
er = errorbar(1:size(aves),aves,sem_aves);
er.Color = [0 0 0];                            % make the errorbars black
er.LineStyle = 'none'; 
hold off
uistack(b,'top'); % if you want the bars in front of error bars


% % stars
% starHeight = mn+1.5*stdv;
% text(x(2),starHeight(2),'*','HorizontalAlignment','center');
% text(x(3),starHeight(3),'**','HorizontalAlignment','center');
% 
% % significance bridge
% comp = [2 3];   % which points to compare
% bridgeHeight = 0.7;     % desired y location for bridge
% ax = gca;
% dh = 0.02*(max(ax.YLim)-min(ax.YLim));
% yBridge = bridgeHeight-[dh 0 0 dh];
% xBridge = [x(comp(1)),x(comp(1)),x(comp(2)),x(comp(2))];
% line(xBridge,yBridge,'Color','k');
% text(mean(x(comp)),bridgeHeight,'*','HorizontalAlignment','center');
% 
% comp = [4 3];   % which points to compare
% bridgeHeight = 0.75;     % desired y location for bridge
% ax = gca;
% dh = 0.02*(max(ax.YLim)-min(ax.YLim));
% yBridge = bridgeHeight-[dh 0 0 dh];
% xBridge = [x(comp(1)),x(comp(1)),x(comp(2)),x(comp(2))];
% line(xBridge,yBridge,'Color','k');
% text(mean(x(comp)),bridgeHeight,'*','HorizontalAlignment','center');
% 
% 
% comp = [3 6];   % which points to compare
% bridgeHeight = 0.8;     % desired y location for bridge
% ax = gca;
% dh = 0.02*(max(ax.YLim)-min(ax.YLim));
% yBridge = bridgeHeight-[dh 0 0 dh];
% xBridge = [x(comp(1)),x(comp(1)),x(comp(2)),x(comp(2))];
% line(xBridge,yBridge,'Color','k');
% text(mean(x(comp)),bridgeHeight,'*','HorizontalAlignment','center');

xlabel('Condition');
ylabel(ylab);


% figure
% 
% bar(num)
% set(gca,'XTick',1:length(num))
% set(gca,'XTickLabel',cond1)
% xlabel('condition')
% ylabel('percent cells above threshold')
% title('by well percent cells above threshold')
% 
% 
% handles = barweb(mn1,stdv1,[],[],'first experiment','condition','average percent cells above threshold',bone,[],cond,2,'axis');