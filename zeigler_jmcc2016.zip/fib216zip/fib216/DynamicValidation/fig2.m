% Generates figure 2: Dynamic validation of data from Lu et al 2013
% Dependencies:
%    - luFig.dat = a file with the mean and standard deviation digitized
%    from the relevent figure from Lu et al 2013
%    - modelParams and modelODE file
%    - the following matlab functions: exportNodeAttributes, drugTime


% setup: define the index of the outputs and collagen1 and name the
% modelParam file and modelODE file
col1 = 88; %index for collagen output
outindx = [73,80,81,88,89];  %index for aSMA, proMMP2, proMMP9, col1 mRNA, col3 mRNA

paramName = 'modelParams';  %name of the parameter file
ODEname = 'modelODE';


eval(strcat('[params,y0] = ',paramName))
[rpar,tau,ymax,speciesNames]=params{:}; 

% run simulations for the two different conditions
y1 = drugTime(paramName,ODEname,'w(2) = 0.9;', 'w(2) = 0.9; w(11) = 0.9;','TGF\beta + Forskolin',outindx);
y2 = drugTime(paramName,ODEname,'w(2) = 0.9;','w(2) = 0.9;','TGF\beta',outindx);

d = y1(:,end) - y2(:,end);

% export the node attributes for the difference figure
 exportNodeAttributes('diff.txt', 'Difference', speciesNames, d);

% make bar graph that matches the experimental data
% set up the model prediction
mdata = [y1(col1,1),y2(col1,end),y1(col1,end)];
% load the experimental data adapted from a figure
load('luFig.dat');
edata = luFig([1,3,5],1);
estd = [luFig(2,1) - luFig(1,1); luFig(4,1) - luFig(3,1); luFig(6,1) - luFig(5,1)];

conds = {'control','TGF\beta','TGF\beta + Forskolin'};


figure
subplot(2,1,1)
b = bar(mdata);
b.FaceColor = [0.5 0.5 0.5];
set(gca,'XTickLabel',conds);
ylabel('Collagen I mRNA (%Activity)');
title('Model Prediction');
box off

subplot(2,1,2)
dataStats(edata,conds,estd,'Relative Collagen I mRNA');
title ('Experimental Data');
box off