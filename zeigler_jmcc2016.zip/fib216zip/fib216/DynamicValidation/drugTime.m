function [y] = drugTime(paramName,odeName,p1,p2,ptitle,outindx)

%parameters and initial conditions
eval(strcat('[params,y0] = ',paramName))
tspan = [0 5]; 
options = []; 

%pull parameters out in order to alter them in the loop without negating
%the previous alteration
[rpar,tau,ymax,speciesNames]=params{:}; 
w = rpar(1,:);
n = rpar(2,:);
EC50 = rpar(3,:);


% Initial Simulation
params = {rpar,tau,ymax,speciesNames};
eval(['[t1,y1] = ode23(@',odeName,',tspan,y0,options,params);']);
tInt1 = [0:1:5];
yInt1 = interp1(t1,y1,tInt1);

% Application of Drug #1
eval(p1)
rpar = [w;n;EC50];
params = {rpar,tau,ymax,speciesNames};

y0 = yInt1(end,:);
% tspan = [0:1:97]; 
tspan = [0:1:48];
options = []; 
eval(strcat('[t2,y2] = ode23(@',odeName,',tspan,y0,options,params);'));
% tInt2 = [0:1:96];
tInt2 = [0:1:48];
yInt2 = interp1(t2,y2,tInt2);

% Addition of Drug #2
eval(p2);
rpar = [w;n;EC50];
params = {rpar,tau,ymax,speciesNames};

y0 = yInt2(end,:);
tspan = [0:1:49];
options = []; 
eval(strcat('[t3,y3] = ode23(@',odeName,',tspan,y0,options,params);'));
tInt3 = [0:1:48];
yInt3 = interp1(t3,y3,tInt3);


time1 = length(tInt1);
time2 = length(tInt2)/2 + time1 + 1;
time3 = length(tInt2) + time1 + 1;
time4 = length(tInt3) + time3 - 1;
y = real([yInt1' yInt2' yInt3']);
% y = real([yInt1' yInt2']);

% setting up labels
timeTick = [time1 time2 time3 time4];
timeLabel = [0, 2, 4, 6];
% timeTick = [time1 time2 ];
% timeLabel = [0, 2];

% figure
% colormap(flipud(bone))
% imagesc(y)
% colorbar
% set(gca,'YTick',1:length(speciesNames));
% set(gca,'YTickLabel',speciesNames,'fontsize',5);
% set(gca,'XTick',timeTick);
% set(gca,'XTickLabel',timeLabel,'fontsize',8);
% title(ptitle);
% xlabel('Time (Days)');
% ylabel('Node');


outs = speciesNames(outindx);

figure
colormap(flipud(bone))
imagesc(y(outindx,:))
colorbar
set(gca,'YTick',1:length(outs));
set(gca,'YTickLabel',outs,'fontsize',5);
set(gca,'XTick',timeTick);
set(gca,'XTickLabel',timeLabel,'fontsize',8);
title(ptitle);
xlabel('Time (Days)');
ylabel('Node');


figure
colormap(flipud(bone))
imagesc(y)
colorbar
set(gca,'YTick',1:length(speciesNames));
set(gca,'YTickLabel',speciesNames,'fontsize',5);
set(gca,'XTick',timeTick);
set(gca,'XTickLabel',timeLabel,'fontsize',8);
title(ptitle);
xlabel('Time (Days)');
ylabel('Node');
end
